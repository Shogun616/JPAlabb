CREATE VIEW sys.dm_exec_query_transformation_stats AS
	SELECT *
	FROM OpenRowSet(TABLE SYSRULESTATS)
go

