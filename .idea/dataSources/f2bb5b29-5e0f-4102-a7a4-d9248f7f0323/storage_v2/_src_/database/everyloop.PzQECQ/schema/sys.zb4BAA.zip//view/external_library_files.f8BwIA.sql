CREATE VIEW sys.external_library_files AS
	SELECT 
		co.id AS external_library_id,
		ov1.imageval AS content,
		convert(tinyint, ov1.subobjid) AS platform,
		pv.name as platform_desc
	FROM
		sys.sysclsobjs co LEFT JOIN
		sys.sysobjvalues ov1 ON
		(
			co.id = ov1.objid AND
			ov1.valclass = 129 AND -- SVC_EXTERNAL_LIBRARY
			ov1.valnum = 3 -- EXTLIB_SOURCE
		) LEFT JOIN
		sys.syspalvalues pv ON
		(
			pv.class = 'ELP' AND
			pv.value = ov1.subobjid
		)
	WHERE
		co.class = 105 AND -- SOC_EXTERNAL_LIBRARY
		has_access('EL', co.id) = 1
go

grant select on sys.external_library_files to [public]
go

