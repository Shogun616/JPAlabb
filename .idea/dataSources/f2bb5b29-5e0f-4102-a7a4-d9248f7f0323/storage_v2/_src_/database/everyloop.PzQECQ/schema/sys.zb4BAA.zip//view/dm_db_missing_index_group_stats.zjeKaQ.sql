CREATE VIEW sys.dm_db_missing_index_group_stats AS

	SELECT
		-- key
		group_handle = index_id,
		
		-- number of compiles (same for all queries because stored at combo level)
		unique_compiles = MAX(unique_compiles),

		-- stats for user queries
		user_seeks = SUM(user_seeks),
		user_scans = SUM(user_scans),
		last_user_seek = NULLIF(MAX(ISNULL(last_user_seek, 0)), 0),
		last_user_scan = NULLIF(MAX(ISNULL(last_user_scan, 0)), 0),
		avg_total_user_cost =
			CASE 
				WHEN SUM(user_seeks + user_scans) > 0 
				THEN SUM(total_user_cost) / SUM(user_seeks + user_scans)
				ELSE 0 
			END,
		avg_user_impact =
			CASE 
				WHEN SUM(user_seeks + user_scans) > 0 AND SUM(total_user_improvement) > 0 AND SUM(total_user_cost) > 0
				THEN ROUND(100 * IIF(SUM(total_user_improvement) > SUM(total_user_cost), 1, SUM(total_user_improvement) / SUM(total_user_cost)), 2)
				ELSE 0 
			END,

		-- stats for system queries
		system_seeks = SUM(system_seeks),
		system_scans = SUM(system_scans),
		last_system_seek = NULLIF(MAX(ISNULL(last_system_seek, 0)), 0),
		last_system_scan = NULLIF(MAX(ISNULL(last_system_scan, 0)), 0),
		avg_total_system_cost =
			CASE 
				WHEN SUM(system_seeks + system_scans) > 0 
				THEN SUM(total_system_cost) / SUM(system_seeks + system_scans)
				ELSE 0 
			END,
		avg_system_impact =
			CASE 
				WHEN SUM(system_seeks + system_scans) > 0 AND SUM(total_system_improvement) > 0 AND SUM(total_system_cost) > 0
				THEN ROUND(100 * IIF(SUM(total_system_improvement) > SUM(total_system_cost), 1, SUM(total_system_improvement) / SUM(total_system_cost)), 2)
				ELSE 0 
			END
			
	FROM OpenRowset(TABLE LOGINDEXSTATS)
	WHERE status <> 0
	GROUP BY index_id
go

