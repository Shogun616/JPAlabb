CREATE VIEW sys.partition_schemes AS
	SELECT o.name AS name,
		o.id AS data_space_id,
		o.type AS type,
		c.name AS type_desc,
		sysconv(bit, o.status & 0x1) AS is_default,
		sysconv(bit, o.status & 0x4) AS is_system,
		r.indepid AS function_id
	FROM sys.sysclsobjs o
	JOIN sys.syssingleobjrefs r ON r.depid = o.id AND r.class = 31 AND r.depsubid = 0 -- SRC_PRTSCHFUNC
	LEFT JOIN sys.syspalnames c ON c.class = 'DSTY' AND c.value = o.type
	WHERE o.class = 31 AND o.type = 'PS'
go

grant select on sys.partition_schemes to [public]
go

