CREATE VIEW sys.database_filestream_options AS
	SELECT d.id_nonrepl as database_id, p.non_transacted_access, p.non_transacted_access_desc, p.directory_name
	FROM master.sys.sysdbreg$ d 
		CROSS APPLY OpenRowset(TABLE DATABASE_FILESTREAM_OPTIONS, d.id) p
	WHERE repl_sys_db_visible(d.id) = 1
	AND has_access('DB', d.id) = 1
go

