CREATE VIEW sys.system_columns AS
	SELECT object_id, name collate catalog_default AS name,
		column_id, system_type_id, user_type_id,
		max_length, precision, scale,
		convert(sysname, ColumnPropertyEx(object_id, name, 'collation')) AS collation_name,
		is_nullable, is_ansi_padded, is_rowguidcol,
		is_identity, is_computed, is_filestream,
		is_replicated, is_non_sql_subscribed,
		is_merge_published, is_dts_replicated,
		is_xml_document, xml_collection_id,
		default_object_id, rule_object_id,
		is_sparse, is_column_set,
		generated_always_type,
		generated_always_type_desc,
		encryption_type, encryption_type_desc, 
		encryption_algorithm_name, column_encryption_key_id,
		column_encryption_key_database_name collate catalog_default as column_encryption_key_database_name,
		is_hidden,
		is_masked,
		graph_type,
		graph_type_desc
	FROM sys.system_columns$
go

grant select on sys.system_columns to [public]
go

