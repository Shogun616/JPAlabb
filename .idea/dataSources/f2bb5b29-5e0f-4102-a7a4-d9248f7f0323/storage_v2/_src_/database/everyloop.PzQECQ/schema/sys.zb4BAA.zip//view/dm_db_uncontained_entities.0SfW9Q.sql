
CREATE VIEW sys.dm_db_uncontained_entities
AS
	-- The class values correspond to the UNC classes defined in sys.syspalvalues.
	SELECT V.class, U.name as class_desc, V.major_id, V.statement_line_number, V.statement_offset_begin, V.statement_offset_end, V.statement_type, V.feature_name, V.feature_type_name
	FROM
	(
		-- Check for breachings features in USER_TABLES (and its computed columns), CHECK_CONSTRAINTS, DEFAULT CONSTRAINTS (skipping old-style defaults) and TYPE_TABLE.
		-- class = 1: OBJECT_OR_COLUMN
		SELECT 1 AS class, X.object_id AS major_id, DMV.statement_line_number, DMV.statement_offset_begin, DMV.statement_offset_end, DMV.statement_type, DMV.feature_name, DMV.feature_type_name
		FROM
		(
			SELECT Obj.object_id FROM sys.objects Obj WHERE (Obj.type = 'U' OR Obj.type = 'C' OR ( Obj.type = 'D' AND Obj.parent_object_id <> 0) OR Obj.type ='TT')			
		) X
		CROSS APPLY OPENROWSET(TABLE DM_DB_MODULE_CONTAINMENT_BREACHING_FEATURES, X.object_id, 0, 0) DMV
	
		UNION ALL

		-- Add Hekaton tables and procs.
		-- Hekaton is only available on 64 bit versions of the server, and requires the processor to support the interlock_exchange_128 operation. 
		-- CDBs do not (yet) have a way to express the requirement that the server meets architectural requirements. Therefore, using Hekaton breaches 
		-- containment, and all Hekaton objects are marked as uncontained.
		SELECT 1 AS class, Tlb.object_id AS major_id, NULL, NULL, NULL, NULL, N'MemoryOptimizedTable' COLLATE Latin1_General_CI_AS_KS_WS, N'Memory optimized table' COLLATE Latin1_General_CI_AS_KS_WS
		FROM sys.tables Tlb INNER JOIN sys.objects Obj ON Tlb.object_id=Obj.object_id WHERE Tlb.is_memory_optimized=1
		UNION ALL
		SELECT 1 AS class, Tlb.object_id AS major_id, NULL, NULL, NULL, NULL, N'NativelyCompiledProc' COLLATE Latin1_General_CI_AS_KS_WS, N'Natively compiled stored procedure' COLLATE Latin1_General_CI_AS_KS_WS
		FROM sys.sql_modules Tlb INNER JOIN sys.objects Obj ON Tlb.object_id=Obj.object_id WHERE Tlb.uses_native_compilation=1
        
		UNION ALL

		-- modules, excluding database level DDL triggers
		-- Collation of the class_desc column follows collation of the name column in sys.syspalvalues table 
		-- since these class names are stored there.
		-- 
		SELECT 1 AS class, X.object_id AS major_id, DMV.statement_line_number, DMV.statement_offset_begin, DMV.statement_offset_end, DMV.statement_type, DMV.feature_name, DMV.feature_type_name
		FROM
		(
			-- Ignore database level DDL triggers by joining with sys.objects. We will handle them below
			-- since they are a different UNC class
			SELECT Mod.object_id, CASE Obj.type WHEN 'P ' THEN 1 ELSE 0 END AS subobjid 
			FROM sys.sql_modules Mod INNER JOIN sys.objects Obj ON Mod.object_id=Obj.object_id
		) X
		CROSS APPLY OPENROWSET(TABLE DM_DB_MODULE_CONTAINMENT_BREACHING_FEATURES, X.object_id, X.subobjid, 0) DMV

		UNION ALL

		-- Check for breaching features in non-schemabound security policy predicate definitions.
		SELECT 1 AS class, X.object_id AS major_id, DMV.statement_line_number, DMV.statement_offset_begin, DMV.statement_offset_end, DMV.statement_type, DMV.feature_name, DMV.feature_type_name
		FROM
		(
			SELECT Secpol.object_id, Secpreds.security_predicate_id as subobjid
			FROM sys.security_policies Secpol INNER JOIN sys.security_predicates Secpreds on Secpol.object_id = Secpreds.object_id where Secpol.is_schema_bound = 0
		) X
		CROSS APPLY OPENROWSET(TABLE DM_DB_MODULE_CONTAINMENT_BREACHING_FEATURES, X.object_id, X.subobjid, 0) DMV

		UNION ALL

		-- T-SQL DDL triggers
		-- class = 12: DATABASE_DDL_TRIGGER
		SELECT 12, T.object_id, DMV.statement_line_number, DMV.statement_offset_begin, DMV.statement_offset_end, DMV.statement_type, DMV.feature_name, DMV.feature_type_name
		FROM sys.triggers T 
		CROSS APPLY OPENROWSET(TABLE DM_DB_MODULE_CONTAINMENT_BREACHING_FEATURES, T.object_id, 0, 0) DMV
		WHERE T.parent_class = 0

		UNION ALL

		-- all CLR modules are currently considered uncontained for MinCDB (Ignore database-level DDL triggers by joining with sys.objects)
		SELECT 1, Mod.object_id, NULL, NULL, NULL, NULL, N'Assembly Module' COLLATE Latin1_General_CI_AS_KS_WS, N'Database Entity' COLLATE Latin1_General_CI_AS_KS_WS
		FROM sys.assembly_modules Mod INNER JOIN sys.objects Obj ON Mod.object_id=Obj.object_id

		UNION ALL

		-- all CLR DDL Triggers are currently considered uncontained for MinCDB
		SELECT 12, Mod.object_id, NULL, NULL, NULL, NULL, N'Assembly Module' COLLATE Latin1_General_CI_AS_KS_WS, N'Database Entity' COLLATE Latin1_General_CI_AS_KS_WS
		FROM sys.assembly_modules Mod INNER JOIN sys.triggers T ON Mod.object_id=T.object_id
		WHERE T.parent_class = 0

		UNION ALL

		-- all user-defined CLR UDTs are currently considered uncontained for MinCDB
		-- class = 6: TYPE
		SELECT 6, user_type_id, NULL, NULL, NULL, NULL, N'Assembly Type' COLLATE Latin1_General_CI_AS_KS_WS, N'Database Entity' COLLATE Latin1_General_CI_AS_KS_WS
		FROM sys.assembly_types
		WHERE is_user_defined = 1

		UNION ALL

		SELECT 1, object_id, NULL, NULL, NULL, NULL, DMV.feature_name, DMV.feature_type_name
		FROM sys.synonyms S
		CROSS APPLY OPENROWSET(TABLE DM_DB_MODULE_CONTAINMENT_BREACHING_FEATURES, S.object_id, 0, 0) DMV
		WHERE S.is_ms_shipped=0

		UNION ALL

		-- unsafe or external access CLR assemblies are uncontained
		-- class = 5: ASSEMBLY
		SELECT 5, assembly_id, NULL, NULL, NULL, NULL, N'Assembly' COLLATE Latin1_General_CI_AS_KS_WS, N'Database Entity' COLLATE Latin1_General_CI_AS_KS_WS
		FROM sys.assemblies
		WHERE (is_user_defined = 1 AND permission_set >= 2)

		UNION ALL

		-- users linked to instance logins including orphaned users are uncontained
		-- class = 4: DATABASE_PRINCIPAL
		SELECT 4, principal_id, NULL, NULL, NULL, NULL, N'Database Principal' COLLATE Latin1_General_CI_AS_KS_WS, N'Database Entity' COLLATE Latin1_General_CI_AS_KS_WS
		FROM sys.database_principals
		-- 'S' means SQL_USER and 1 means INSTANCE
		WHERE type='S' AND authentication_type=1

		UNION ALL

		-- certificate mapped users who dont have a matching certificate in this db are uncontained. The mapping between
		-- a certificate mapped user and a certificate is based on SID equality.
		SELECT 4, D.principal_id, NULL, NULL, NULL, NULL, N'Database Principal' COLLATE Latin1_General_CI_AS_KS_WS, N'Database Entity' COLLATE Latin1_General_CI_AS_KS_WS
		FROM sys.certificates C RIGHT OUTER JOIN sys.database_principals D ON C.sid = D.sid 
		WHERE D.type='C' AND C.name IS NULL

		UNION ALL

		-- asymmetric key mapped users who dont have a matching aymmetric key in this db are uncontained. The mapping between
		-- a asymmetric key mapped user and an asymmetric key is based on SID equality.
		SELECT 4, D.principal_id, NULL, NULL, NULL, NULL, N'Database Principal' COLLATE Latin1_General_CI_AS_KS_WS, N'Database Entity' COLLATE Latin1_General_CI_AS_KS_WS
		FROM sys.asymmetric_keys K RIGHT OUTER JOIN sys.database_principals D ON K.sid = D.sid 
		WHERE D.type='K' AND K.name IS NULL

		UNION ALL

		-- all full-text indexes are currently considered uncontained for MinCDB
		-- class = 7: INDEX
		SELECT 7, object_id, NULL, NULL, NULL, NULL, N'Full-text Index' COLLATE Latin1_General_CI_AS_KS_WS, N'Database Entity' COLLATE Latin1_General_CI_AS_KS_WS
		FROM sys.fulltext_indexes

		UNION ALL

		-- all routes are uncontained for MinCDB
		-- class = 19: ROUTE
		SELECT 19, route_id, NULL, NULL, NULL, NULL, N'Route' COLLATE Latin1_General_CI_AS_KS_WS, N'Database Entity' COLLATE Latin1_General_CI_AS_KS_WS
		FROM sys.routes

		UNION ALL

		-- class = 30: AUDIT_SPECIFICATION
		SELECT 30, database_specification_id, NULL, NULL, NULL, NULL, N'Database Audit Specification' COLLATE Latin1_General_CI_AS_KS_WS, N'Database Entity' COLLATE Latin1_General_CI_AS_KS_WS
		FROM sys.database_audit_specifications
	) V
	INNER JOIN sys.syspalvalues U ON V.class=U.value AND U.class = 'UNCL'
	WHERE dbprop(db_id(), 'issystemdb') != 1
go

