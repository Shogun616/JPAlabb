CREATE VIEW sys.all_parameters AS
 SELECT * FROM sys.parameters
 UNION ALL
 SELECT * FROM sys.system_parameters
go

grant select on sys.all_parameters to [public]
go

