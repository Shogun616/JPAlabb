CREATE VIEW sys.dm_db_xtp_checkpoint_files
AS
	SELECT	df.[file_id] as container_id,
			cf.[container_guid],
			cf.[file_id] as 'checkpoint_file_id',
			cf.[relative_path] as 'relative_file_path',
			cf.[file_type],
			pv.[name] as 'file_type_desc',
			cf.[storage_array_index] as 'internal_storage_slot',
			cf.[pair_file_id] as 'checkpoint_pair_file_id',
			cf.[allocated_bytes] as 'file_size_in_bytes',
			cf.[used_bytes] as 'file_size_used_in_bytes',
			cf.[logical_row_count],
			cf.[state],
			pv2.[name] as 'state_desc',
			cf.[min_transaction_id] as 'lower_bound_tsn',
			cf.[max_transaction_id] as 'upper_bound_tsn',
			cf.[begin_checkpoint_id],
			cf.[end_checkpoint_id],
			cf.[last_checkpoint_id] as 'last_updated_checkpoint_id',
			cf.[encryption_status],
			pv3.[name] as 'encryption_status_desc'
	FROM 
		OpenRowset(TABLE XTP_CKPT_FILESV2) cf JOIN
		sys.database_files df ON cf.[container_guid] = df.[file_guid] JOIN
		sys.syspalvalues pv ON pv.class = 'CFT2' and pv.value = cf.[file_type] JOIN
		sys.syspalvalues pv2 ON pv2.class = 'CFS2' and pv2.value = cf.[state] LEFT JOIN
		sys.syspalvalues pv3 ON pv3.class = 'CFES' and pv3.value = cf.[encryption_status]
go

