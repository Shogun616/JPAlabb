CREATE view sys.dm_hadr_cluster_networks
as
	SELECT *
	FROM OpenRowset(TABLE DM_HADR_CLUSTER_NETWORKS)
go

