
CREATE VIEW sys.database_automatic_tuning_mode AS
SELECT
	tun_opt.desired_state,
	spn_des.name AS desired_state_desc,
	tun_opt.actual_state,
	spn_act.name AS actual_state_desc
FROM
	OpenRowset(TABLE DATABASE_AUTOMATIC_TUNING_MODE) AS tun_opt
LEFT JOIN sys.syspalnames AS spn_des
	ON spn_des.class = 'ATAR' AND tun_opt.desired_state = spn_des.value
LEFT JOIN sys.syspalnames AS spn_act
	ON spn_act.class = 'ATAR' AND tun_opt.actual_state = spn_act.value
go

grant select on sys.database_automatic_tuning_mode to [public]
go

