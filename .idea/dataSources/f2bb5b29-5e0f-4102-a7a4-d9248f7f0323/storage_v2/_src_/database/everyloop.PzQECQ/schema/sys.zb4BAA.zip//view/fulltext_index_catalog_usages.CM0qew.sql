CREATE VIEW sys.fulltext_index_catalog_usages AS
	SELECT r.depid AS object_id,
		f.indid AS index_id,
		r.indepid AS fulltext_catalog_id
	FROM sys.syssingleobjrefs r
	LEFT JOIN sys.sysftinds f ON f.id = r.depid
	WHERE r.class = 39 AND r.depsubid = 0 -- SRC_FTITABTOCAT
go

grant select on sys.fulltext_index_catalog_usages to [public]
go

