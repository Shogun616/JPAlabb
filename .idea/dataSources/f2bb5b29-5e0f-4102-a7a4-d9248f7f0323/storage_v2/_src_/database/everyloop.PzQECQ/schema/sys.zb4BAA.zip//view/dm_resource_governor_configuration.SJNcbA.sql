CREATE VIEW sys.dm_resource_governor_configuration AS
	SELECT *
	FROM OpenRowSet(TABLE DM_RG_CONFIGURATION, 0)
go

