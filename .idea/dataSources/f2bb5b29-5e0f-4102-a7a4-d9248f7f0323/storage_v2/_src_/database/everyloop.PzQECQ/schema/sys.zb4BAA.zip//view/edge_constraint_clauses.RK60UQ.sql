CREATE VIEW sys.edge_constraint_clauses AS
	select f.depid as object_id, f.depsubid as clause_number, f.indepid as from_object_id, t.indepid as to_object_id
	FROM sys.sysmultiobjrefs f join sys.sysmultiobjrefs t ON f.depid = t.depid AND f.depsubid = t.depsubid
	WHERE f.class = 28 	--MRC_EDGE_CONSTRAINT
	AND f.indepsubid = 0 and t.indepsubid = 1 
		AND has_access('CO', f.indepid) = 1
		AND has_access('CO', t.indepid) = 1
go

grant select on sys.edge_constraint_clauses to [public]
go

