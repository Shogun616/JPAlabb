CREATE VIEW sys.sysfilegroups AS
	SELECT
		groupid = convert(smallint, data_space_id & 0x7fff),
		allocpolicy = convert(smallint, 0),
		status = convert(int, is_default * 16 + is_read_only * 8),
		groupname = name
	FROM sys.filegroups
go

grant select on sys.sysfilegroups to [public]
go

