CREATE VIEW sys.sql_feature_restrictions AS
	SELECT
		class = CASE objid
			WHEN 21333 THEN 'User'
			WHEN 20306 THEN 'Role'
			ELSE 'Unknown' END,
		object = USER_NAME(valnum),
		feature = CASE subobjid
			WHEN 18007 THEN 'WaitFor'
			WHEN 19781 THEN 'ErrorMessages'
			ELSE 'Unknown' END
	FROM sys.sysobjvalues
	WHERE valclass = 144 -- SVC_FEATURE_RESTRICTION
	    AND value = 1 -- true, has feature restriction
go

grant select on sys.sql_feature_restrictions to [public]
go

