CREATE VIEW sys.syslanguages AS
	SELECT langid, dateformat, datefirst,
		convert(int, 0) AS upgrade,
		name, alias,
		convert(nvarchar(372), month1+N',' COLLATE catalog_default +month2+N','+month3+N','+month4+N','+month5+N','+month6
			+N','+month7+N','+month8+N','+month9+N','+month10+N','+month11+N','+month12) AS months,
		convert(nvarchar(132), shortmonth1+N',' COLLATE catalog_default +shortmonth2+N','+shortmonth3+N','+shortmonth4+N','+shortmonth5+N','+shortmonth6
			+N','+shortmonth7+N','+shortmonth8+N','+shortmonth9+N','+shortmonth10+N','+shortmonth11+N','+shortmonth12) AS shortmonths,
		convert(nvarchar(217), day2+N',' COLLATE catalog_default +day3+N','+day4+N','+day5+N','+day6+N','+day7+N','+day1) AS days,
		lcid, msglangid
	FROM OpenRowset(TABLE SYSLANG)
go

