create view sys.dm_exec_compute_node_errors as
select 
	B.error_id	collate database_default error_id,
	B.source	collate database_default source,
	B.type	collate database_default type,
	B.create_time,
	B.compute_node_id,
	B.execution_id	collate database_default execution_id,
	B.spid,
	B.thread_id,
	B.details	collate database_default details,
	A.compute_pool_id
from (
	select 0
	union all
	select bdc_pool_id as compute_pool_id
	from OPENROWSET(TABLE DM_EXEC_COMPUTE_POOLS, 0)
	) as A(compute_pool_id)
cross apply
	sys.fn_polybase_compute_node_errors_per_pool(A.compute_pool_id) B
go

