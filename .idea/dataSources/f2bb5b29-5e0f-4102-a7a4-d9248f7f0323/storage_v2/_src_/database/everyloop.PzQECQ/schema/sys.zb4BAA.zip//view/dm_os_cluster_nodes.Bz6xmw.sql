create view sys.dm_os_cluster_nodes
as
	select
		[NodeName],
		[status] = convert (int, [state] & 0xffff),
		[status_description] =
			CASE convert(int, [state] & 0xffff)
				When 0 Then 'up'
				When 1 Then 'down'
				When 3 Then 'joining'
				When 2 Then 'paused'
				Else 'unknown'
			END,
		convert(bit, [state] & 0x10000) as is_current_owner
	from OpenRowset(TABLE VIRTUALSERVERNODES)
go

