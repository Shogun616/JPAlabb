CREATE VIEW sys.crypt_properties AS
	SELECT						-- objects
		k.class AS class,
		un.name AS class_desc,
		s.id AS major_id,
		k.thumbprint AS thumbprint,
		k.type AS crypt_type,
		ct.name AS crypt_type_desc,
		k.crypto AS crypt_property
	FROM sys.sysschobjs$ s
	JOIN sys.sysobjkeycrypts k ON k.class = 1 AND k.id = s.id
	LEFT JOIN sys.syspalvalues un ON un.class = 'UNCL' AND un.value = k.class
	LEFT JOIN sys.syspalnames ct ON ct.class = 'CRTY' AND ct.value = k.type
	WHERE s.nsclass = 0 -- x_eonc_Standard
		AND s.pclass = 1 -- x_eunc_Object
		AND k.type <> 'INCP'
		AND has_access('SQ', s.id, s.pid, 0) = 1
	UNION
	SELECT						-- assemblies
		k.class AS class,
		un.name AS class_desc,
		s.assembly_id AS major_id,
		k.thumbprint AS thumbprint,
		k.type AS crypt_type,
		ct.name AS crypt_type_desc,
		k.crypto AS crypt_property
	FROM sys.assemblies s
	JOIN sys.sysobjkeycrypts k ON k.class = 5 AND k.id = s.assembly_id
	LEFT JOIN sys.syspalvalues un ON un.class = 'UNCL' AND un.value = k.class
	LEFT JOIN sys.syspalnames ct ON ct.class = 'CRTY' AND ct.value = k.type
	WHERE k.type <> 'INCP'
go

grant select on sys.crypt_properties to [public]
go

