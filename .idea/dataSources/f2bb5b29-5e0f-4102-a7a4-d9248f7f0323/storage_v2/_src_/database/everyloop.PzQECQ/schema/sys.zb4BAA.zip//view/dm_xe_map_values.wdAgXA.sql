CREATE VIEW sys.dm_xe_map_values AS
	SELECT *
	FROM OpenRowset(TABLE DM_XE_MAP_VALUES)
go

