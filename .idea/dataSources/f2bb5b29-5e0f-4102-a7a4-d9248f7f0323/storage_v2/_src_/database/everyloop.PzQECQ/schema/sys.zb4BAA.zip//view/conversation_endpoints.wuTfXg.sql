CREATE VIEW sys.conversation_endpoints AS
	SELECT ce.conversation_handle,
		ce.conversation_id,
		ce.is_initiator,
		ce.service_contract_id,
		ce.conversation_group_id,
		ce.service_id,
		ce.lifetime,
		ce.state,
		ce.state_desc,
		ce.far_service,
		ce.far_broker_instance,
		ce.principal_id,
		ce.far_principal_id,
		ce.outbound_session_key_identifier,
		ce.inbound_session_key_identifier,
		ce.security_timestamp,
		ce.dialog_timer,
		ce.send_sequence,
		ce.last_send_tran_id,
		ce.end_dialog_sequence,
		ce.receive_sequence,
		ce.receive_sequence_frag,
		ce.system_sequence,
		ce.first_out_of_order_sequence,
		ce.last_out_of_order_sequence,
		ce.last_out_of_order_frag,
		ce.is_system,
		ce.priority
	FROM sys.conversation_endpoints$ ce
	LEFT JOIN sys.syssingleobjrefs f ON f.depid = ce.service_id AND f.class = 21 AND f.depsubid = 0 -- SRC_SVCTOQUEUE
	WHERE has_access('CO', f.indepid) = 1
go

grant select on sys.conversation_endpoints to [public]
go

