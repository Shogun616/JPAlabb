CREATE VIEW sys.dm_cryptographic_provider_properties AS
	SELECT *
	FROM OpenRowset(TABLE DM_CRYPTO_PROVIDER_PROPS)
go

