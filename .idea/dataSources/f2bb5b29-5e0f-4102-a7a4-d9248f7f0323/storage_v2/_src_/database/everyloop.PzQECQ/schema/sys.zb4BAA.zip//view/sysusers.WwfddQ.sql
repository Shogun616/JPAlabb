-- Note: gid (max group id) not maintained, shiloh logic not correct anyway
--
CREATE VIEW sys.sysusers AS
	SELECT uid = convert(smallint, u.id),
		status = convert(smallint, case u.type
			when 'U' then 12 when 'G' then 4 when 'A' then 32 else 0 end),
		u.name, u.sid,
		roles = convert(varbinary(2048), null),
		createdate = u.created,
		updatedate = u.modified,
		altuid = convert(smallint, r.indepid),
		password = convert(varbinary(256), null),
		gid = convert(smallint, case u.type when 'R' then u.id else 0 end),
		environ = convert(varchar(255), null),
		hasdbaccess = convert(int, case when p.state in ('G','W') then 1 else 0 end),
		islogin = convert(int, case u.type when 'A' then 0 when 'R' then 0 else 1 end),
		isntname = convert(int, case u.type when 'U' then 1 when 'G' then 1 else 0 end),	-- USR_SID_EXTERNAL
		isntgroup = convert(int, case u.type when 'G' then 1 else 0 end),
		isntuser = convert(int, case u.type when 'U' then 1 else 0 end),	-- USR_SID_EXTERNAL
		issqluser = convert(int, case u.type when 'S' then 1 else 0 end),
		isaliased = convert(int, 0),   -- Aliases were deprecated and removed
		issqlrole = convert(int, case u.type when 'R' then 1 else 0 end),
		isapprole = convert(int, case u.type when 'A' then 1 else 0 end)
	FROM sys.sysowners u
	LEFT JOIN sys.sysprivs p ON p.class = 0 AND p.id = 0 AND p.subid = 0 AND p.grantee = u.id AND p.grantor = 1 AND p.type = 'CO'
	LEFT JOIN sys.syssingleobjrefs r ON r.depid = u.id AND r.depsubid = 0 AND r.class = case u.type when 'R' then 51 end -- SRC_ROLEOWNER
	WHERE has_access('US', u.id) = 1
go

grant select on sys.sysusers to [public]
go

