CREATE VIEW sys.database_scoped_configurations AS
	SELECT id as configuration_id,
		name,
		convert(sql_variant, value) as value,
		convert(sql_variant, value_for_secondary) as value_for_secondary,
		is_value_default
	FROM OpenRowset(TABLE DB_SCOPED_CONFIG)
go

grant select on sys.database_scoped_configurations to [public]
go

