CREATE VIEW sys.security_predicates AS
	SELECT 
		mr.depid as object_id, 
		mr.depsubid as security_predicate_id, 
		mr.indepid as target_object_id, 
		object_definition(mr.depid, mr.depsubid) as predicate_definition,
		convert(int, mr.status % 0x10) as predicate_type,
		v1.name as predicate_type_desc,
		case when convert(int, mr.status / 0x10 % 0x10) = 0 then NULL else convert(int, mr.status / 0x10 % 0x10) end as operation,
		v2.name as operation_desc
	FROM sys.sysmultiobjrefs mr
	LEFT JOIN sys.syspalvalues v1 ON v1.class = 'SPT' AND v1.value = (mr.status % 0x10)
	LEFT JOIN sys.syspalvalues v2 ON v2.class = 'SPO' AND v2.value = (mr.status / 0x10 % 0x10)
	WHERE mr.class = 11 AND has_access('CO', mr.depid) = 1
go

grant select on sys.security_predicates to [public]
go

