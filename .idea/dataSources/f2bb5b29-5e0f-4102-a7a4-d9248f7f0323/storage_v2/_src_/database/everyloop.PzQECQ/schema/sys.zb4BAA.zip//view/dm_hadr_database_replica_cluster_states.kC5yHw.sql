CREATE VIEW sys.dm_hadr_database_replica_cluster_states AS
	SELECT
		*
	FROM
		OpenRowset(TABLE DM_HADR_DATABASE_REPLICA_CLUSTER_STATES) AS drcs
go

