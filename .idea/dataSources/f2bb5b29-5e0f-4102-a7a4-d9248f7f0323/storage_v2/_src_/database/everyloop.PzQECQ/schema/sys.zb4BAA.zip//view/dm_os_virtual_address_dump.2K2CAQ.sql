CREATE VIEW sys.dm_os_virtual_address_dump AS
	SELECT *
	FROM OpenRowset(TABLE SYSVADUMP)
go

