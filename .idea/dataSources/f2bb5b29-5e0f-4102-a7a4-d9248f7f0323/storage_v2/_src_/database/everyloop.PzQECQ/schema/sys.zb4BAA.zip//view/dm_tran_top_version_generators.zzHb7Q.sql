CREATE VIEW sys.dm_tran_top_version_generators AS
	SELECT TOP 256 database_id, rowset_id, SUM(record_length_first_part_in_bytes + record_length_second_part_in_bytes) aggregated_record_length_in_bytes
	FROM sys.dm_tran_version_store
	GROUP BY database_id, rowset_id
	ORDER BY aggregated_record_length_in_bytes desc
go

