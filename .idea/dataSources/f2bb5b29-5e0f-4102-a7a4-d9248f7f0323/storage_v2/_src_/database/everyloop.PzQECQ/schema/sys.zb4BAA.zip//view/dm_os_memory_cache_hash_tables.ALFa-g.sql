CREATE VIEW sys.dm_os_memory_cache_hash_tables AS
	SELECT *
	FROM OpenRowSet(TABLE SYSMEMORYCACHEHASHTABLES)
go

