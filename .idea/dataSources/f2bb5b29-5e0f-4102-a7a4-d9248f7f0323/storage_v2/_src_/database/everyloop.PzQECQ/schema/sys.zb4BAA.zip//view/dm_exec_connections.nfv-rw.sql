CREATE VIEW sys.dm_exec_connections AS
	SELECT *
	FROM OpenRowset(TABLE SYSCONNECTIONS)
go

