CREATE VIEW sys.dm_os_job_object AS
	SELECT *
	FROM OpenRowSet(TABLE DM_OS_JOB_OBJECT)
go

