CREATE VIEW sys.syscursortables AS
	SELECT *
	FROM OpenRowSet(TABLE SYSCURSORTBLS)
go

