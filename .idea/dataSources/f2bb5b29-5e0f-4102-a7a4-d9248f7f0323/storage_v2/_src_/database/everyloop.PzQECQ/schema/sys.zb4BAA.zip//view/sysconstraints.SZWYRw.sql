CREATE VIEW sys.sysconstraints AS
	SELECT constid = object_id,
		id = parent_object_id,
		colid = convert(smallint, property),
		spare1 = convert(tinyint, 0),
		status = convert(int,
				CASE type
					WHEN 'PK' THEN 1 WHEN 'UQ' THEN 2 WHEN 'F ' THEN 3
					WHEN 'C ' THEN 4 WHEN 'D ' THEN 5 ELSE 0 END
				+ CASE WHEN property <> 0 THEN (16) ELSE (32) END
				+ CASE WHEN ObjectProperty(object_id, 'CnstIsClustKey') <> 0
						THEN (512) ELSE 0 END
				+ CASE WHEN ObjectProperty(object_id, 'CnstIsNonclustKey') <> 0
						THEN (1024) ELSE 0 END
				+ (is_system_named * 131072)
				+ (2048)						-- CNST_NOTDEFERRABLE
				+ (is_disabled * 16384)
				+ (is_not_for_replication * 2097152)),
		actions = convert(int,  4096),
		error = convert(int, 0)
	FROM sys.objects$
	WHERE (parent_object_id > 0 OR 
		(parent_object_id & 0xe0000000 = 0xa0000000)) -- IsLocalTempObjectId
		AND type IN ('C ', 'F ', 'PK', 'UQ', 'D ')
go

grant select on sys.sysconstraints to [public]
go

