CREATE VIEW sys.dm_xtp_threads
AS
	SELECT
	*
	FROM OpenRowset(TABLE XTP_THREADS)
go

