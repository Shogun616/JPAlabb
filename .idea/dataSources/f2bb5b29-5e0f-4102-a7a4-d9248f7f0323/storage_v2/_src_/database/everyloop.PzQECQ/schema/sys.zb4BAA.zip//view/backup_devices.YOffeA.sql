CREATE VIEW sys.backup_devices AS
	SELECT o.name,
		convert(tinyint, o.intprop) AS type,
		i.name AS type_desc,
		convert(nvarchar(260),v.value) AS physical_name
	FROM master.sys.sysclsobjs o
	LEFT JOIN sys.sysobjvalues v ON v.valclass = 55 AND v.objid = o.id AND v.subobjid = 0 and v.valnum = 1	-- SVC_BACKUPDEVICE:VALNUM_PHYSNAME
	LEFT JOIN sys.syspalvalues i ON i.class = 'BDTY' AND i.value = o.intprop
	WHERE o.class = 55	-- SOC_BACKUPDEVICE
go

