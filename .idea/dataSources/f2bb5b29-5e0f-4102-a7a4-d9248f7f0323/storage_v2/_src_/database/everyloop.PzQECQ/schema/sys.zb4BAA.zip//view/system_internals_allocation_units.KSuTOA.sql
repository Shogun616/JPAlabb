CREATE VIEW sys.system_internals_allocation_units AS
	SELECT au.auid AS allocation_unit_id,
		au.type,
		ip.name AS type_desc,
		au.ownerid AS container_id,
		au.fgid AS filegroup_id,
		isnull(ct.reserved_pages, au.pcreserved) AS total_pages,
		isnull(ct.used_pages, au.pcused) AS used_pages,
		isnull(ct.data_pages, au.pcdata) AS data_pages,
		au.pgfirst AS first_page,
		au.pgroot AS root_page,
		au.pgfirstiam AS first_iam_page
	FROM sys.sysallocunits au OUTER APPLY OpenRowset(TABLE ALUCOUNT, au.ownerid, au.type, 0, 0) ct
	LEFT JOIN sys.syspalvalues ip ON ip.class = 'AUTY' AND ip.value = au.type
go

