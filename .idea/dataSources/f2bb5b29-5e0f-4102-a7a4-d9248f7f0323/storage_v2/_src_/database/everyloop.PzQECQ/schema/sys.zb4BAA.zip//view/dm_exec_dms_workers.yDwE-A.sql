
-- add it
create view sys.dm_exec_dms_workers as
select
	B.execution_id	collate database_default execution_id,
	B.step_index,
	B.dms_step_index,
	B.compute_node_id,
	B.distribution_id,
	B.type	collate database_default type,
	B.status	collate database_default status,
	B.bytes_per_sec,
	B.bytes_processed,
	B.rows_processed,
	B.start_time,
	B.end_time,
	B.total_elapsed_time,
	B.cpu_time,
	B.query_time,
	B.buffers_available,
	B.dms_cpid,
	B.sql_spid,
	B.error_id	collate database_default error_id,
	B.source_info	collate database_default source_info,
	B.destination_info	collate database_default destination_info,
	B.command	collate database_default command,
	A.compute_pool_id
from (
	select 0
	union all
	select bdc_pool_id as compute_pool_id
	from OPENROWSET(TABLE DM_EXEC_COMPUTE_POOLS, 0)
	) as A(compute_pool_id)
cross apply
	sys.fn_polybase_dms_workers_per_pool(A.compute_pool_id) B
go

