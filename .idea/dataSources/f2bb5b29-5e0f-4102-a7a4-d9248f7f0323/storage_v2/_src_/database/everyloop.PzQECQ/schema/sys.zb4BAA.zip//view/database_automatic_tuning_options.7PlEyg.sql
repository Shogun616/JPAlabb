
CREATE VIEW sys.database_automatic_tuning_options AS
SELECT
	adv_opt.advisor_name AS name,
	adv_opt.desired_state,
	spn_des.name AS desired_state_desc,
	adv_opt.actual_state,
	spn_act.name AS actual_state_desc,
	adv_opt.reason,
	spv.name AS reason_desc
FROM
	OpenRowset(TABLE DATABASE_AUTOMATIC_TUNING_ADVISOR_OPTIONS) AS adv_opt
LEFT JOIN sys.syspalnames AS spn_des
	ON spn_des.class = 'ATAT' AND adv_opt.desired_state = spn_des.value
LEFT JOIN sys.syspalnames AS spn_act
	ON spn_act.class = 'ATAT' AND adv_opt.actual_state = spn_act.value
LEFT JOIN sys.syspalvalues AS spv
	ON spv.class = 'ATDR' AND adv_opt.reason = spv.value
go

grant select on sys.database_automatic_tuning_options to [public]
go

