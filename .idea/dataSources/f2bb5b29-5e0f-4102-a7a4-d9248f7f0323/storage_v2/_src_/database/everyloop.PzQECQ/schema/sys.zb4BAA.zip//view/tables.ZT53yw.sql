CREATE VIEW sys.tables AS
	SELECT o.name, o.object_id, o.principal_id, o.schema_id, o.parent_object_id,
		o.type, o.type_desc, o.create_date, o.modify_date,
		o.is_ms_shipped, o.is_published, o.is_schema_published,
		isnull(ds.indepid, 0) AS lob_data_space_id,
		rfs.indepid AS filestream_data_space_id,
		o.property AS max_column_id_used,
		o.lock_on_bulk_load, o.uses_ansi_nulls, o.is_replicated, o.has_replication_filter,
		o.is_merge_published, o.is_sync_tran_subscribed, o.has_unchecked_assembly_data,
		lob.intprop AS text_in_row_limit,
		o.large_value_types_out_of_row,
		o.is_tracked_by_cdc,
		o.lock_escalation_option AS lock_escalation,
		ts.name AS lock_escalation_desc,
		o.is_filetable,
		o.is_memory_optimized,
		o.durability_option as durability,
		d.name as durability_desc,
		convert(tinyint, case when ct.indepid IS NOT NULL then 2 when ht.depid IS NOT NULL then 1 else 0 end) as temporal_type,
		convert(nvarchar(60), case when ct.indepid IS NOT NULL then 'SYSTEM_VERSIONED_TEMPORAL_TABLE' when ht.depid IS NOT NULL then 'HISTORY_TABLE' else 'NON_TEMPORAL_TABLE' end) collate Latin1_General_CI_AS_KS_WS as temporal_type_desc,
		ct.depid as history_table_id,
		convert(bit, CASE WHEN EXISTS (SELECT 1 FROM sys.sysmultiobjrefs WHERE depid = o.object_id AND class = 27 /*MRC_STRETCH_REMOTE_DATABASE*/) THEN 1 ELSE 0 END) AS is_remote_data_archive_enabled,
		o.is_external,
		convert(int,
			case when ct.indepid IS NOT NULL -- temporal system_versioned current table
				then ISNULL((select value from sys.sysobjvalues where valclass = 123 and objid = o.object_id and valnum = 0), -1)
			else NULL
				end
		) as history_retention_period,
		convert(int,
			case when ct.indepid IS NOT NULL -- temporal system_versioned current table
				then ISNULL((select value from sys.sysobjvalues where valclass = 123 and objid = o.object_id and valnum = 1), -1)
			else NULL
				end
		) as history_retention_period_unit,
		convert(nvarchar(10),
			case when ct.indepid IS NOT NULL -- temporal system_versioned current table
			then
				case when exists (select value from sys.sysobjvalues where valclass = 123 and objid = o.object_id and valnum = 1)
				then 
					case (select ISNULL(value, -1) from sys.sysobjvalues where valclass = 123 and objid = o.object_id and valnum = 1)
						when -1 then 'INFINITE'
						when 0 then 'SECOND'
						when 1 then 'MINUTE'
						when 2 then 'HOUR'
						when 3 then 'DAY'
						when 4 then 'WEEK'
						when 5 then 'MONTH'
						when 6 then 'YEAR'
						else 'UNDEFINED'
						end
				else
					'INFINITE'
				end
			else NULL
			end
			) collate Latin1_General_CI_AS_KS_WS as history_retention_period_unit_desc,
		o.is_node,
		o.is_edge
	FROM sys.objects$ o
	LEFT JOIN sys.sysidxstats lob ON lob.id = o.object_id AND lob.indid <= 1
	LEFT JOIN sys.syssingleobjrefs ds ON ds.depid = o.object_id AND ds.class = 8 AND ds.depsubid <= 1	-- SRC_INDEXTOLOBDS	
	LEFT JOIN sys.syssingleobjrefs rfs ON rfs.depid = o.object_id AND rfs.class = 42 AND rfs.depsubid = 0	-- SRC_OBJTOFSDS
	LEFT JOIN sys.syssingleobjrefs ct ON ct.indepid = o.object_id AND ct.class = 112 -- SRC_HISTORY_TABLE
	LEFT JOIN sys.syssingleobjrefs ht ON ht.depid = o.object_id AND ht.class = 112 -- SRC_HISTORY_TABLE
	LEFT JOIN sys.syspalvalues ts ON ts.class = 'LEOP' AND ts.value = o.lock_escalation_option
	LEFT JOIN sys.syspalvalues d ON d.class = 'DOPT' AND d.value = o.durability_option
	WHERE o.type = 'U'
go

grant select on sys.tables to [public]
go

