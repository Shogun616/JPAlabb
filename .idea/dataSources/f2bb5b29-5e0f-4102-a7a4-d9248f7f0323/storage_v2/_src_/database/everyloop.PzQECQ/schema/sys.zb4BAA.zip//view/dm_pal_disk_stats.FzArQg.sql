CREATE VIEW sys.dm_pal_disk_stats AS
	SELECT *
	FROM OpenRowset(TABLE DM_PAL_DISK_STATS)
go

