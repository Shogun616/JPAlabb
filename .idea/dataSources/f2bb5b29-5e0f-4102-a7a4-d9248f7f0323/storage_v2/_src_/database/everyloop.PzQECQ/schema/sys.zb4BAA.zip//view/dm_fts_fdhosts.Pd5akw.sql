CREATE view sys.dm_fts_fdhosts
AS
	SELECT * FROM OpenRowset(TABLE FTFDHOST)
go

