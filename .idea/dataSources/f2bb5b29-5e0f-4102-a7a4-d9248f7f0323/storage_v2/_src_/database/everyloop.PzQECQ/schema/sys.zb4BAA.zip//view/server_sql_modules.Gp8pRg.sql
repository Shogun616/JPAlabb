CREATE VIEW sys.server_sql_modules AS
	SELECT object_id = o.id,
		definition = object_definition(o.id),
		uses_ansi_nulls = sysconv(bit, o.status & 0x40000),				-- OBJMOD_ANSINULLS
		uses_quoted_identifier = sysconv(bit, o.status & 0x80000), 		-- OBJMOD_QUOTEDIDENT
		execute_as_principal_id = x.indepid
	FROM sys.sysschobjs$ o
	LEFT JOIN sys.syssingleobjrefs x ON x.depid = o.id AND x.class = 23 AND x.depsubid = 0	-- SRC_OBJEXECASLOGIN
	WHERE o.type = 'TR' AND o.nsclass = 20 AND o.pclass = 100	-- x_eonc_TrgOnServer:x_eunc_Server
		AND has_access('TR', o.id, 0, 20) = 1
go

