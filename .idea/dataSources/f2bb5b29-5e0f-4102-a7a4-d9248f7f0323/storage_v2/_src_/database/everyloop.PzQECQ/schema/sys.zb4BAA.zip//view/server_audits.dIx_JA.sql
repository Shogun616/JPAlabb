CREATE VIEW sys.server_audits AS
	SELECT
		audit_id,
		name,
		audit_guid,
		create_date,
		modify_date,
		principal_id,
		type,
		type_desc,	
		on_failure,
		on_failure_desc ,
		is_state_enabled,
		queue_delay,
		predicate
	FROM sys.server_audits$
go

