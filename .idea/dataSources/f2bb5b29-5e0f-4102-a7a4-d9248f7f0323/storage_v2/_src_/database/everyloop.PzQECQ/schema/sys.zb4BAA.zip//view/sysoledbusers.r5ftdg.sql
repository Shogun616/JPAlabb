CREATE VIEW sys.sysoledbusers AS
	SELECT
		rmtsrvid = convert(smallint, r.server_id),
		rmtloginame = r.remote_name,
		rmtpassword = convert(sysname, null),
		loginsid = p.sid,
		status = convert(smallint, r.uses_self_credential),
		changedate = r.modify_date
	FROM sys.linked_logins r
	LEFT JOIN sys.server_principals p ON r.local_principal_id = p.principal_id
go

