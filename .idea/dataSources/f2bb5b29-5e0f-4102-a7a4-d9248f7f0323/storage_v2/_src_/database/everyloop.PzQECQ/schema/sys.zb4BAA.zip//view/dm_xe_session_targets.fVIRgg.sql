CREATE VIEW sys.dm_xe_session_targets AS
	SELECT *
	FROM OpenRowset(TABLE DM_XE_SESSION_TARGETS, 0)
go

