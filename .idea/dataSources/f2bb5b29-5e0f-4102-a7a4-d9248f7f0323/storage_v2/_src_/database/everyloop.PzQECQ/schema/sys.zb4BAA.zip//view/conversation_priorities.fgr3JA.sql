CREATE VIEW sys.conversation_priorities AS
	SELECT
		priority_id,
		name,
		service_contract_id,
		local_service_id,
		remote_service_name,
		priority
	FROM sys.syspriorities
go

grant select on sys.conversation_priorities to [public]
go

