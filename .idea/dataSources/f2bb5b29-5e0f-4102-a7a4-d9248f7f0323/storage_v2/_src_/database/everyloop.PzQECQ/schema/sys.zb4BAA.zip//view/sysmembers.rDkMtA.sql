CREATE VIEW sys.sysmembers AS
	SELECT
		memberuid = convert(smallint, member_principal_id),
		groupuid = convert(smallint, role_principal_id)
	FROM sys.database_role_members
go

grant select on sys.sysmembers to [public]
go

