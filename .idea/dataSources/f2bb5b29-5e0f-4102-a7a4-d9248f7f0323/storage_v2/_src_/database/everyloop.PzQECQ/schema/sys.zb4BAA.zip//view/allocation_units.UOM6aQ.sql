CREATE VIEW sys.allocation_units AS
	SELECT au.auid AS allocation_unit_id,
		au.type,
		ip.name AS type_desc,
		au.ownerid AS container_id,
		convert(int, au.fgid) AS data_space_id,
		isnull(ct.reserved_pages, au.pcreserved) AS total_pages,
		isnull(ct.used_pages, au.pcused) AS used_pages,
		isnull(ct.data_pages, au.pcdata) AS data_pages
	FROM sys.sysallocunits au OUTER APPLY OpenRowset(TABLE ALUCOUNT, au.ownerid, au.type, 0, 0) ct
	LEFT JOIN sys.syspalvalues ip ON ip.class = 'AUTY' AND ip.value = au.type
go

grant select on sys.allocation_units to [public]
go

