CREATE VIEW sys.registered_search_properties AS
	SELECT 
		ftp.property_list_id AS property_list_id,
		ftp.property_id AS property_id,
		ftp.property_name AS property_name,
		ftp.guid_identifier AS property_set_guid,
		ftp.int_identifier AS property_int_id,
		ftp.string_description AS property_description
	FROM sys.sysftproperties ftp
	JOIN sys.sysclsobjs sc ON ftp.property_list_id = sc.id and sc.class = 66 and has_access ('FP', sc.id) = 1 -- join to filter property according to has_access() 
go

grant select on sys.registered_search_properties to [public]
go

