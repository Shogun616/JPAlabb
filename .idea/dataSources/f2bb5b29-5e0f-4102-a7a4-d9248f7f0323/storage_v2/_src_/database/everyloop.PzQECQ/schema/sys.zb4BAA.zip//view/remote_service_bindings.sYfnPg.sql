CREATE VIEW sys.remote_service_bindings AS
	SELECT name = r.name,
		remote_service_binding_id = r.id,
		principal_id = p.indepid,
		remote_service_name = r.remsvc,
		service_contract_id = r.scid,
		remote_principal_id = m.indepid,
		is_anonymous_on = sysconv(bit, r.status & 1)		--RSB_ANON_ACCESS
	FROM sys.sysremsvcbinds r
	LEFT JOIN sys.syssingleobjrefs p ON p.depid = r.id AND p.class = 48 AND p.depsubid = 0	-- SRC_RSBOWNER
	LEFT JOIN sys.syssingleobjrefs m ON m.depid = r.id AND m.class = 24 AND m.depsubid = 0	-- SRC_RSB_REMUSER
	WHERE has_access('RS', r.id) = 1
go

grant select on sys.remote_service_bindings to [public]
go

