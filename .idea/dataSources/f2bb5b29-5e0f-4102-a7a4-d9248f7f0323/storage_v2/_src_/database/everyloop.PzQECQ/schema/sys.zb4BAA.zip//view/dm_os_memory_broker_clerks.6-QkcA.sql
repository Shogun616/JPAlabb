CREATE VIEW sys.dm_os_memory_broker_clerks AS
	SELECT *
	FROM OpenRowSet(TABLE DM_OS_MEMORY_BROKER_CLERKS)
go

