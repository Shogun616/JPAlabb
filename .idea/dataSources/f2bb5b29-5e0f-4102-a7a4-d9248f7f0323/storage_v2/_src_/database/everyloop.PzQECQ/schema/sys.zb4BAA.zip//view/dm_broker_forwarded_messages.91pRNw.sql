CREATE VIEW sys.dm_broker_forwarded_messages AS
	SELECT * FROM OpenRowset (TABLE SBFORWARDEDMESSAGES)
go

