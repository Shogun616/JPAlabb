CREATE VIEW sys.dm_os_workers AS
	SELECT *
	FROM OpenRowSet(TABLE SYSWORKERS)
go

