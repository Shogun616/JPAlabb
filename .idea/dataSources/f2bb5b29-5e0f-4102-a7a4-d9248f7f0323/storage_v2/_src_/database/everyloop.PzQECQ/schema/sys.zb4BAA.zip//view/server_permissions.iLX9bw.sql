CREATE VIEW sys.server_permissions AS
	SELECT p.class, cn.name AS class_desc,
		p.id AS major_id,
		p.subid AS minor_id,
		p.grantee AS grantee_principal_id,
		p.grantor AS grantor_principal_id,
		p.type, permission_name(p.class, p.type) AS permission_name,
		p.state, sn.name AS state_desc
	FROM master.sys.sysprivs p
	LEFT JOIN sys.syspalvalues cn ON cn.class = 'UNCL' AND cn.value = p.class
	LEFT JOIN sys.syspalnames sn ON sn.class = 'PRST' AND sn.value = p.state
	WHERE p.class >= 100
		AND (has_access('LG', p.grantee, p.grantor) = 1 OR has_access('CT', p.class, p.id) = 1)
		AND p.type <> 'EXTR' -- exclude trusted execute permission
go

