CREATE VIEW sys.sysreferences AS
	SELECT
		constid = f.object_id,
		fkeyid = f.parent_object_id,
		rkeyid = f.referenced_object_id,
		rkeyindid = convert(smallint, f.key_index_id),
		keycnt = r.keycnt,
		forkeys = convert(varbinary(32), null),
		refkeys = convert(varbinary(32), null),
		fkeydbid = convert(smallint, 0),
		rkeydbid = convert(smallint, 0),
		r.fkey1, r.fkey2, r.fkey3, r.fkey4, r.fkey5, r.fkey6, r.fkey7, r.fkey8,
		r.fkey9, r.fkey10, r.fkey11, r.fkey12, r.fkey13, r.fkey14, r.fkey15, r.fkey16,
		r.rkey1, r.rkey2, r.rkey3, r.rkey4, r.rkey5, r.rkey6, r.rkey7, r.rkey8,
		r.rkey9, r.rkey10, r.rkey11, r.rkey12, r.rkey13, r.rkey14, r.rkey15, r.rkey16
	FROM sys.foreign_keys f OUTER APPLY OpenRowset(TABLE SYSREF, f.object_id) r
go

grant select on sys.sysreferences to [public]
go

