CREATE view sys.dm_fts_index_population
AS
	SELECT * FROM OpenRowset(TABLE FTCRAWLS)
go

