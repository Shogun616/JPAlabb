CREATE VIEW sys.fulltext_system_stopwords
AS
	SELECT convert(nvarchar(64), stopword) as stopword, language_id FROM OpenRowset(TABLE FTSYSSTPWD)
go

