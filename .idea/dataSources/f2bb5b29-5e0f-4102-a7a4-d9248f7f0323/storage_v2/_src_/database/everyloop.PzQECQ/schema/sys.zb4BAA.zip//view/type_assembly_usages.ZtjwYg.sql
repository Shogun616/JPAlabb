CREATE VIEW sys.type_assembly_usages AS
	SELECT depid AS user_type_id,
		indepid AS assembly_id
	FROM sys.syssingleobjrefs
	WHERE class = 38 AND depsubid = 0	-- SRC_TYPETOASM
go

grant select on sys.type_assembly_usages to [public]
go

