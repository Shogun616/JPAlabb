CREATE VIEW sys.dm_tran_active_snapshot_database_transactions AS
	SELECT
		transaction_id,
		transaction_sequence_num,
		commit_sequence_num,
		session_id,
		is_snapshot,
		first_snapshot_sequence_num,
		max_version_chain_traversed,
		average_version_chain_traversed,
		elapsed_time_seconds
	FROM OpenRowset(TABLE DM_TRAN_ACTIVE_SNAPSHOT_DATABASE_TRANSACTIONS)
go

