CREATE VIEW sys.query_store_query_text AS
	SELECT
		qt.query_text_id,
		qt.query_sql_text,
		CAST(qt.statement_sql_handle AS VARBINARY(44)) AS statement_sql_handle,
		qt.is_part_of_encrypted_module,
		qt.has_restricted_text
	FROM sys.plan_persist_query_text qt WITH (NOLOCK) -- NOTE - in order to prevent potential deadlock between QDS_STATEMENT_STABILITY LOCK and index locks
	LEFT OUTER JOIN (
		SELECT TOP 0 
			query_text_id,
			query_sql_text,
			CAST(statement_sql_handle AS VARBINARY(44)) AS statement_sql_handle,
			is_part_of_encrypted_module,
			has_restricted_text
		FROM sys.plan_persist_query_text_in_memory) qt_in_mem ON	-- NOTE - join with STVF will enable view to have same security definitions as STVF
	qt_in_mem.query_text_id = qt.query_text_id						--        but plan will remove it since it is empty table
go

grant select on sys.query_store_query_text to [public]
go

