CREATE VIEW sys.change_tracking_tables AS
	SELECT oUserTable.id AS object_id, 
		sysconv(bit, oUserTable.status & 134217728) AS is_track_columns_updated_on,	-- OBJTAB_TRACKCOLUMNS
		change_tracking_min_valid_version(oUserTable.id) as min_valid_version, 
		cast(ISNULL(csnlastinvalid.value, 0) as bigint) as begin_version,
		change_tracking_cleanup_version() as cleanup_version
	FROM sys.sysschobjs$ oIntlTable
	INNER JOIN sys.syssingleobjrefs par ON par.depid = oIntlTable.id AND par.class = 40 AND par.depsubid = 209 -- SRC_INTLTAB_PARENT, ITT_ChangeTrackingTable
	INNER JOIN sys.sysschobjs$ oUserTable ON par.indepid = oUserTable.id
	LEFT JOIN sys.sysobjvalues csnlastinvalid ON csnlastinvalid.objid = oUserTable.id and csnlastinvalid.valclass=95 and csnlastinvalid.valnum=1 -- SVC_CHANGE_TRACKING_SETTINGS 	= 95
	WHERE oIntlTable.nsclass = 0 -- x_eonc_Standard
		AND oIntlTable.nsid = 4 AND oIntlTable.pclass = 1 AND oIntlTable.type = 'IT' -- x_eunc_Object
		AND has_access('CO', oUserTable.id) = 1
go

grant select on sys.change_tracking_tables to [public]
go

