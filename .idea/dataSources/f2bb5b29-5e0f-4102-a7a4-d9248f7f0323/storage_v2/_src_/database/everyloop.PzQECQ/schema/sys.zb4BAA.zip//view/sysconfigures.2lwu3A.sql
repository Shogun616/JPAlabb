CREATE VIEW sys.sysconfigures AS
	SELECT
		convert(int, value) AS value,
		configuration_id AS config,
		description AS comment,
		convert(smallint, is_dynamic + is_advanced*2) AS status
	FROM sys.configurations
go

