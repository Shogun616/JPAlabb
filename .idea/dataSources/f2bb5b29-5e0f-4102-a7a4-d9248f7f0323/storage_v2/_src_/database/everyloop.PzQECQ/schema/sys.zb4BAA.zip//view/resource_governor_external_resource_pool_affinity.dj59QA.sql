CREATE VIEW sys.resource_governor_external_resource_pool_affinity
AS
	SELECT external_pool_id = pool_id, processor_group, cpu_mask
	FROM OpenRowSet(TABLE SYS_RG_EXTERNAL_POOL_AFFINITY)
go

