CREATE VIEW sys.via_endpoints AS
	SELECT e.name,
		e.id AS endpoint_id,
		o.indepid AS principal_id,
		e.protocol, p.name AS protocol_desc,
		e.type, t.name AS type_desc,
		convert(tinyint, e.bstat & 3) AS state,	-- BSTAT_STATEMASK
		s.name AS state_desc,
		sysconv(bit, case when e.affinity = -1 then 1 else 0 end) AS is_admin_endpoint, 
		e.site AS discriminator
	FROM master.sys.sysendpts e
	LEFT JOIN sys.syssingleobjrefs o ON o.depid = e.id AND o.class = 60 AND o.depsubid = 0	-- SRC_ENDPTLOGINOWNER
	LEFT JOIN sys.syspalvalues p ON p.class = 'EPPR' AND p.value = e.protocol
	LEFT JOIN sys.syspalvalues t ON t.class = 'EPTY' AND t.value = e.type
	LEFT JOIN sys.syspalvalues s ON s.class = 'EPST' AND s.value = e.bstat & 3
	WHERE e.protocol = 5
		AND has_access('HE', e.id) = 1
go

