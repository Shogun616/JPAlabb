CREATE VIEW sys.dm_db_missing_index_groups AS
	SELECT *
	FROM OpenRowset(TABLE MISSING_IDX_GROUPS)
go

