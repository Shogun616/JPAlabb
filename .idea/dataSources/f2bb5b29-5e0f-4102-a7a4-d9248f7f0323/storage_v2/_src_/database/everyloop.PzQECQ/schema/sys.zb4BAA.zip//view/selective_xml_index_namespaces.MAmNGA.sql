CREATE VIEW sys.selective_xml_index_namespaces AS
	SELECT s.objid AS object_id,
		s.subobjid AS index_id,
		convert(bit, case when s.value is null then 1 else 0 end) as is_default_uri,
		convert(nvarchar(4000), s.imageval) as uri,
		convert(sysname, s.value) as prefix
	FROM sys.sysobjvalues s
	WHERE s.valclass = 109	-- SVC_SXI_NAMESPACE
		AND has_access('CO', s.objid) = 1
go

grant select on sys.selective_xml_index_namespaces to [public]
go

