CREATE VIEW sys.dm_db_xtp_object_stats
AS
	SELECT
	*
	FROM OpenRowset(TABLE XTP_TABLE_STATS)
go

