
CREATE VIEW sys.dm_db_column_store_row_group_operational_stats AS
	SELECT * from OpenRowset (TABLE COLUMNSTORE_OPERATIONAL_STATS) rg WHERE has_access('CO', rg.object_id) = 1;
go

