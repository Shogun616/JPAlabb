
CREATE VIEW sys.dm_cache_hit_stats AS
	SELECT distribution_id,
		cache_read_hits as [cache_hit],
		remote_read_hits as [remote_hit],
		collection_start_time
	FROM
	OpenRowset(TABLE DM_PDW_DISTRIBUTION_CACHE_HIT_STATS)
go

