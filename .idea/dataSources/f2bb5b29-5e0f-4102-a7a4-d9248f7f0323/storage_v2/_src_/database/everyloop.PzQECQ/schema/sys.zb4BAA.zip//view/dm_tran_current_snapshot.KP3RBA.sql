CREATE VIEW sys.dm_tran_current_snapshot AS
	SELECT *
	FROM OpenRowset(TABLE DM_TRAN_CURRENT_SNAPSHOT)
go

