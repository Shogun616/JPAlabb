CREATE VIEW sys.cryptographic_providers AS
	SELECT
		co.id AS provider_id,
		co.name,
		g.guid as guid,	
		convert(nvarchar(10), co.intprop) + '.' + -- Major (MAX INT => 10 chars)
		convert(nvarchar(3), (convert(bigint,p2.value)/(power(2,24)))) + '.' + 	  -- Minor [p2.value >> 24] (1 byte => 3 chars)
		convert(nvarchar(5), (convert(bigint,p2.value)/power(2,8)) & 65535) + '.' + -- Build [p2.value >> 8 & 0x0000FFFF] (2 bytes => 5 chars)
		convert(nvarchar(3), (convert(bigint,p2.value) & 255)) as version,		  -- Revision [p2.value & 0x000000FF] (1 byte => 3 chars)
		convert(nvarchar(520), p.value) as dll_path, 
		sysconv(bit, co.status & 1) AS is_enabled
	FROM master.sys.sysclsobjs co
	LEFT JOIN master.sys.sysguidrefs g ON g.class = 4 AND g.id= co.id AND g.subid = 0  -- GRC_CPGUID
	LEFT JOIN master.sys.sysobjvalues p ON p.valclass = 47 AND p.objid = co.id AND p.subobjid = 0 AND p.valnum = 1 -- SVC_CRYPTOPROVIDER/PROV_DLLPATH_PROP
	LEFT JOIN master.sys.sysobjvalues p2 ON p2.valclass = 47 AND p2.objid = co.id AND p2.subobjid = 0 AND p2.valnum = 2 -- SVC_CRYPTOPROVIDER/PROV_DLLPATH_VER
	WHERE co.class = 63 -- SOC_CRYPTOPROVIDER
go

