CREATE VIEW sys.message_type_xml_schema_collection_usages AS
	SELECT depid AS message_type_id,
		indepid AS xml_collection_id
	FROM sys.syssingleobjrefs
	WHERE class = 92 AND depsubid = 0	-- SRC_MSGTYPE_XSDTYPE
go

grant select on sys.message_type_xml_schema_collection_usages to [public]
go

