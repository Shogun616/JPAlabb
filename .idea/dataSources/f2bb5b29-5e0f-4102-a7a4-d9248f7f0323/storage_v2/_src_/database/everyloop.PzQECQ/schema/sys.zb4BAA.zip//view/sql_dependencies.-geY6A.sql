CREATE VIEW sys.sql_dependencies AS
	SELECT dp.class,
		i.name AS class_desc,
		dp.depid AS object_id,
		dp.depsubid AS column_id,
		dp.indepid AS referenced_major_id,
		dp.indepsubid AS referenced_minor_id,
		sysconv(bit, dp.status & 4) AS is_selected,		-- OBJDEP_READCS
		sysconv(bit, dp.status & 2) AS is_updated,		-- OBJDEP_RESULT
		sysconv(bit, dp.status & 1) AS is_select_all	-- OBJDEP_SELECT
	FROM sys.sysmultiobjrefs dp LEFT JOIN sys.syspalvalues i ON i.class = 'DPCL' AND i.value = dp.class
	WHERE dp.class <= 4	-- MRC_OLDDEPENDS,MRC_EXPRTOOBJ,MRC_EXPRTOTYPE,MRC_EXPRTOXMLNS,MRC_EXPRTOPRTFUNC
go

grant select on sys.sql_dependencies to [public]
go

