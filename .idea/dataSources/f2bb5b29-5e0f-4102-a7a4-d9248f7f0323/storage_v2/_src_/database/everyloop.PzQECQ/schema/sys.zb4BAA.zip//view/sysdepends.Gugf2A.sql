CREATE VIEW sys.sysdepends AS
	SELECT
		id = object_id,
		depid = referenced_major_id,
		number = convert(smallint,
			case when objectproperty(object_id, 'isprocedure') = 1 then 1 else column_id end),
		depnumber = convert(smallint, referenced_minor_id),
		status = convert(smallint, is_select_all * 2 + is_updated * 4 + is_selected * 8),
		deptype = class,
		depdbid = convert(smallint, 0),
		depsiteid = convert(smallint, 0),
		selall = is_select_all,
		resultobj = is_updated,
		readobj = is_selected
	FROM sys.sql_dependencies
	WHERE class < 2
	UNION ALL
	SELECT		-- blobtype dependencies
		id = object_id, depid = object_id,
		number = convert(smallint, column_id), depnumber = convert(smallint, type_column_id),
		status = convert(smallint, 0), deptype = sysconv(tinyint, 1),
		depdbid = convert(smallint, 0), depsiteid = convert(smallint, 0),
		selall = sysconv(bit, 0), resultobj = sysconv(bit, 0), readobj = sysconv(bit, 0)
	FROM sys.fulltext_index_columns
	WHERE type_column_id IS NOT NULL
go

grant select on sys.sysdepends to [public]
go

