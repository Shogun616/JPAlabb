CREATE VIEW sys.dm_exec_background_job_queue AS
	SELECT *
	FROM OpenRowSet(TABLE DM_EXEC_BACKGROUND_JOB_QUEUE)
go

