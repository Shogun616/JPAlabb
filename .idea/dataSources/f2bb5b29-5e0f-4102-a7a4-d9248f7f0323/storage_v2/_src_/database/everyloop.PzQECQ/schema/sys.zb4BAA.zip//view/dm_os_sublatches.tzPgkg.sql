CREATE VIEW sys.dm_os_sublatches AS
	SELECT *
	FROM OpenRowSet(TABLE DM_OS_SUBLATCHES)
go

