CREATE VIEW sys.spatial_reference_systems AS
SELECT
	spatial_reference_id, 
	authority_name,
	authorized_spatial_reference_id,
	well_known_text,
	unit_of_measure,
	unit_conversion_factor
FROM	sys.spatial_reference_systems_tvf()
go

