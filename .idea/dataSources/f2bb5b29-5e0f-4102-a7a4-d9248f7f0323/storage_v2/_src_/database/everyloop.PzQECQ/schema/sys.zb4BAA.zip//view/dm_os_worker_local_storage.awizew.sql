CREATE VIEW sys.dm_os_worker_local_storage AS
	SELECT *
	FROM OpenRowSet(TABLE SYSWORKERTLS)
go

