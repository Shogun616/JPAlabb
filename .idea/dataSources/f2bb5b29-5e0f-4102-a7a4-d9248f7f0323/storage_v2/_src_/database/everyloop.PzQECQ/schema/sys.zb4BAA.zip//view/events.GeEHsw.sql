CREATE VIEW sys.events AS
	SELECT ee.object_id AS object_id,
		ee.event_id AS type,
		ee.event_desc AS type_desc,
		sysconv(bit, 71 - e.valclass) AS is_trigger_event,
		ee.group_id AS event_group_type,
		ee.group_desc AS event_group_type_desc
	FROM sys.sysobjvalues e
	CROSS APPLY openrowset( TABLE EXPAND_EVENTS, e.objid, e.subobjid, 
		case when (e.valclass = 70 AND convert(int, e.value) & 4 != 4) OR e.valclass = 71  -- is user created trigger?
			then 1 else 0 end) ee
	WHERE e.valclass in (70,71) AND e.valnum <> 100	-- x_eunc_Server
		AND has_access('CO', e.objid) = 1	-- SVC_EXTTRIGEVT, SVC_ASYNTRGEVT
go

grant select on sys.events to [public]
go

