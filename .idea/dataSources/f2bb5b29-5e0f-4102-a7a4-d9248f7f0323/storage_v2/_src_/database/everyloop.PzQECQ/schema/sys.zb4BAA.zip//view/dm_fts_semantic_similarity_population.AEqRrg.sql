CREATE view sys.dm_fts_semantic_similarity_population
AS
	SELECT * FROM OpenRowset(TABLE DSIPOP)
go

