CREATE VIEW sys.indexes AS
	SELECT i.id AS object_id,
		i.name AS name,
		i.indid AS index_id,
		i.type,
		n.name AS type_desc,
		sysconv(bit, i.status & 0x8) AS is_unique,			-- IS_IND_UNIQUE
		case when obj.status2 & 0x00000008 != 0 			-- OBJTAB2_HEKATON
 		  then 0 
 		  else isnull(ds.indepid, 1 - (i.status & 0x100)/0x100) 
		end AS data_space_id,	-- IS_IND_ITWINDEX
		sysconv(bit, i.status & 0x4) AS ignore_dup_key,			-- IS_IND_DPKEYS
		sysconv(bit, i.status & 0x20) AS is_primary_key,		-- IS_IND_PRIMARY
		sysconv(bit, i.status & 0x40) AS is_unique_constraint,		-- IS_IND_UNIQUE_CO
		i.fillfact AS fill_factor,
		sysconv(bit, i.status & 0x10) AS is_padded,			-- IS_IND_PADINDEX
		sysconv(bit, i.status & 0x80) AS is_disabled,			-- IS_IND_OFFLINE
		sysconv(bit, i.status & 0x100) AS is_hypothetical,		-- IS_IND_ITWINDEX
		sysconv(bit, i.status & 0x02000000) AS is_ignored_in_optimization,	-- IS_IND_IGNORE_IN_OPTIMIZATION
		case when obj.status2 & 0x00000008 != 0 			-- OBJTAB2_HEKATON
 		  then sysconv(bit, 0) 
		  else sysconv(bit, 1 - (i.status & 512)/512)			-- IS_IND_NO_ROWLOCK
		end as allow_row_locks,
		case when obj.status2 & 0x00000008 != 0 			-- OBJTAB2_HEKATON
 		  then sysconv(bit, 0)
		  else sysconv(bit, 1 - (i.status & 1024)/1024)			-- IS_IND_NO_PAGELOCK
		end AS allow_page_locks,
		sysconv(bit, i.status & 0x20000) AS has_filter,			-- IS_HAS_FILTER
		case when (i.status & 0x20000) != 0 then object_definition(i.id, i.indid, 7) else NULL end AS filter_definition, -- x_euncIndex
		case when (i.type = 5 or i.type = 6) and objval.value is null
			then 
				case when obj.status2 & 0x00000008 != 0 -- OBJTAB2_HEKATON
					then 60 -- default for HEKATON
					else 0 -- default for disk based columnstore indexes
				end
			else cast(objval.value as int) 
		end as compression_delay, -- compression_delay
		sysconv(bit, i.status & 0x1000000) AS suppress_dup_key_messages,	-- IS_IND_DPKEYMSG
		sysconv(bit, i.status & 0x08000000) AS auto_created,				-- IS_IND_AUTO_CREATED
		sysconv(bit, i.status & 0x00000800) AS optimize_for_sequential_key	-- IS_IND_OPTIMIZE_FOR_SEQ_KEY
	FROM sys.sysidxstats i
	LEFT JOIN sys.syssingleobjrefs ds ON ds.depid = i.id AND ds.class = 7 AND ds.depsubid = i.indid	-- SRC_INDEXTODS
	LEFT JOIN sys.syspalvalues n ON n.class = 'IDXT' and n.value = i.type
	INNER JOIN sys.sysschobjs$ obj ON obj.id = i.id
	LEFT JOIN sys.sysobjvalues objval ON objval.valclass = 124 AND i.id = objval.objid AND i.indid = objval.subobjid AND objval.valnum = 0 -- SVC_COLUMNSTORE_INDEX_ATTRIBUTES = 124; VALNUM_COMPRESSION_DELAY = 0
	WHERE (i.status & 1) <> 0
		AND has_access('CO', i.id) = 1		-- IS_INDEX
		AND (i.status & 0x04000000) = 0		-- !IS_IND_RESUMABLE
go

grant select on sys.indexes to [public]
go

