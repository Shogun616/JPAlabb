CREATE VIEW sys.server_principal_credentials AS
	SELECT indepid AS principal_id,
		depid AS credential_id
	FROM master.sys.sysmultiobjrefs
	WHERE class = 24 AND depsubid = 0 AND indepsubid = 0
		AND has_access('LG', indepid) = 1
	UNION	-- Adding results similar to sys.credentials view for creds added using WITH clause
	SELECT depid AS principal_id,
		indepid AS credential_id
	FROM master.sys.syssingleobjrefs
	WHERE class = 63 AND depsubid = 0 AND indepsubid = 0
		AND has_access('LG', depid) = 1
go

