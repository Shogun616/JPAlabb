CREATE VIEW sys.dm_exec_query_resource_semaphores AS
	SELECT convert(smallint, ~convert(bit, isnull(max_target_memory_kb, -1) +1)) as resource_semaphore_id,
	target_memory_kb, max_target_memory_kb, total_memory_kb, available_memory_kb, granted_memory_kb,
	used_memory_kb, grantee_count, waiter_count, timeout_error_count, forced_grant_count,
	pool_id
	FROM OpenRowset(TABLE DM_EXEC_QE_RESSEM)
go

