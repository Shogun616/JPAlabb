CREATE VIEW sys.dm_broker_activated_tasks AS
    SELECT * FROM OpenRowset (TABLE SBACTIVATEDTASKS)
go

