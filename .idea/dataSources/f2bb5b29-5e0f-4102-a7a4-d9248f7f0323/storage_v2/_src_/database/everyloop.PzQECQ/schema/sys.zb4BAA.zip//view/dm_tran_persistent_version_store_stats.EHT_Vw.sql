CREATE VIEW sys.dm_tran_persistent_version_store_stats AS
	SELECT *
	FROM OpenRowset(TABLE PERSISTENT_VERSION_STORE_STATS)
go

