CREATE VIEW sys.sysaltfiles AS
	SELECT fileid = convert(smallint, f.fileid & 0x7fff),
		groupid = convert(smallint, f.grpid),
		f.size, f.maxsize, f.growth,
		status = convert(int,
					case f.filetype when 1 then 66 else 2 end   -- x_eft_SQLLog, FCB_LOG_DEVICE, FCB_DSK_DEVICE
					+ (f.status & 8) * 2 -- FCB_READONLY_MEDIA
					+ (f. status & 16) * 256 -- FCB_READONLY
					+ case when f.filestate in (1, 2, 3, 6) then 268435456 else 0 end -- OFFLINE, FCB_OFFLINE
					+ (f.status & 256) * 2097152 -- FCB_SPARSE_FILE
					+ (f.status & 32) * 32768 -- FCB_PERCENT_GROWTH
					+ (f.status & 2048) / 2048), -- FCB_PMM_METADATA
		perf = convert(int, 0),
		dbid = convert(smallint, f.dbid_nonrepl),
		name = f.lname,
		CASE WHEN SERVERPROPERTY('pathseparator') = '/' THEN CAST (replace(f.pname,'C:\binn\', '') AS nvarchar(260)) 
		ELSE f.pname END AS filename
	FROM sys.sysbrickfiles$ f
	WHERE f.filetype IN (0, 1) AND repl_sys_db_visible(f.dbid) = 1 AND has_access('MF', 1) = 1 -- x_eft_SQLData, x_eft_SQLLog (bwkcmpt types)
go

