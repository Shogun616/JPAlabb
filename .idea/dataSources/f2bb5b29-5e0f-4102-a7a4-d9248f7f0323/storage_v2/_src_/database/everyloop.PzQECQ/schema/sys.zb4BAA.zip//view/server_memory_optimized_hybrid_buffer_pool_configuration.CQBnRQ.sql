CREATE VIEW sys.server_memory_optimized_hybrid_buffer_pool_configuration AS
	SELECT value as is_configured, value_in_use as is_enabled
	  FROM sys.configurations$
	  WHERE name = N'hybrid_buffer_pool'
go

