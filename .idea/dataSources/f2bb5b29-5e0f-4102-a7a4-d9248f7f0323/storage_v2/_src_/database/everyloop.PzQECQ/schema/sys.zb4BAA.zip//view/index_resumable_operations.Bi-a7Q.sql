CREATE VIEW sys.index_resumable_operations AS
	SELECT 
		r.object_id,
		r.index_id,
		r.name,
		r.sql_text,
		r.last_max_dop_used,
		r.partition_number,
		r.state,
		val.name as state_desc,
		r.start_time,
		r.last_pause_time,
		r.total_execution_time,
		r.percent_complete,
		r.page_count
	FROM sys.sysidxstats i
			CROSS APPLY OpenRowset(TABLE INDEX_RESUMABLE_OPERATIONS, i.id, i.indid) r
			LEFT JOIN sys.syspalvalues val ON val.class = 'RIBS' AND val.value = r.state
	WHERE (i.status & 1) = 1 -- IS_INDEX
		AND has_access('CO', i.id) = 1 -- IS_INDEX
		AND (i.status & 0x04000000) = 0x04000000 -- IS_IND_RESUMABLE
		AND i.indid != 254 -- exclude mapping index
		AND i.indid != 896254 -- exclude resumable mapping index
go

grant select on sys.index_resumable_operations to [public]
go

