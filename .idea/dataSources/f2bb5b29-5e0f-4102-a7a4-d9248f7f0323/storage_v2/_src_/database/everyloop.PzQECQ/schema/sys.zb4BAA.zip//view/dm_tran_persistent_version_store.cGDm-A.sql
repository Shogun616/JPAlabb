CREATE VIEW sys.dm_tran_persistent_version_store AS 
	SELECT *
	FROM sys.persistent_version_store WHERE has_access('DB',NULL) = 1
go

