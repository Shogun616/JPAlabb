CREATE VIEW sys.memory_optimized_tables_internal_attributes AS
	SELECT 
		CASE 
			WHEN depr.class IS NULL THEN r.indepid
			ELSE depr.indepid
			END
		AS object_id,
			-- depr.class is NULL for tables that are not internal history tables. In that case we return the table's ID.
			-- If it's null, we return the current table's ID (retrieved in the JOIN).
		r.depid AS xtp_object_id,
		CASE 
			WHEN depr.class IS NULL THEN 
				CASE
					WHEN r.class = 119 /* SRC_OFFROW_DATA_HKTABLEID */ THEN 5 /* Off-row table type */
					ELSE r.indepsubid 
					END
			ELSE depr.indepsubid
			END
		AS type,
		pv.name AS type_desc,
		CASE
			WHEN r.class = 119 /* SRC_OFFROW_DATA_HKTABLEID */ THEN r.indepsubid
			ELSE 0
			END
		AS minor_id
	FROM sys.syssingleobjrefs r	
		-- A specific case for this view is to show internal in memory history tables for Hekaton-Temporal tables.
		-- This relation is preserved as a link in sys.syssingleobjrefs that has class 118 - SRC_TEMPORAL_IN_MEMORY_HISTORY_INTERNAL_TABLE;
		-- the self join below is retrieving the information for internal in memory history tables.
	LEFT JOIN sys.syssingleobjrefs depr ON depr.depid = r.indepid AND depr.class = 118 /* SRC_TEMPORAL_IN_MEMORY_HISTORY_INTERNAL_TABLE */
	JOIN sys.syspalvalues pv ON 
		   (r.class = 85 /* SRC_HKTABLEID_TO_OBJECTID */ AND depr.class IS NULL AND pv.class = 'HKCS' AND pv.value = r.indepsubid)
		OR (r.class = 119 /* SRC_OFFROW_DATA_HKTABLEID */ AND depr.class IS NULL AND pv.class = 'HKOD' AND pv.value = 0)
		OR (depr.class = 118 /* SRC_TEMPORAL_IN_MEMORY_HISTORY_INTERNAL_TABLE */ AND pv.class = 'ITTY' AND pv.value = depr.indepsubid)
	WHERE r.class = 85 /* SRC_HKTABLEID_TO_OBJECTID */ or r.class = 119 /* SRC_OFFROW_DATA_HKTABLEID */
go

grant select on sys.memory_optimized_tables_internal_attributes to [public]
go

