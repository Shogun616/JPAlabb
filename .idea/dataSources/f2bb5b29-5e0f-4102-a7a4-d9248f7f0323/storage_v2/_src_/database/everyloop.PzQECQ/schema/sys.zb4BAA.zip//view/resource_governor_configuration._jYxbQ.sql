CREATE VIEW sys.resource_governor_configuration
AS
    SELECT
        classifier_function_id          = sor.indepid,
        is_enabled                      = sysconv(bit, sor.status & 1), -- 0-Disabled / 1-Enabled
        max_outstanding_io_per_volume   = isnull(convert(int, ov.value), 0)
        FROM
        master.sys.syssingleobjrefs sor LEFT JOIN
        master.sys.sysobjvalues ov ON
        (
            ov.objid = 0 AND
            ov.valclass = 111 AND -- SVC_RG_CONFIGURATION
            ov.subobjid = 0 AND
            ov.valnum = 0
        )
    WHERE
        sor.class = 12 AND -- SRC_RG_CONFIGURATION
        sor.depsubid = 0 AND
        sor.depid = 0 AND
        sor.indepsubid = 0 AND
        has_access('RG', 0) = 1
go

