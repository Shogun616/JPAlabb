CREATE VIEW sys.stats_columns AS
	SELECT s.idmajor AS object_id,
		s.idminor AS stats_id,
		s.subid AS stats_column_id,
		s.intprop AS column_id
	FROM sys.sysiscols s
	WHERE (s.status & 1)  = 1			-- ISC_STATS_COL
		AND has_access('CO', s.idmajor) = 1 
		AND s.idminor NOT IN 
        (
            SELECT t.valnum as stats_id
            FROM tempstatvals t
            WHERE t.valnum < 0x40000
                AND t.subobjid = s.idmajor
        )
    UNION ALL
    SELECT	t.subobjid as object_id,
    		t.valnum as stats_id,
    		v.stats_column_id,
    		v.column_id
    FROM	tempstatvals t   
    		outer apply 
    		OpenRowset(TABLE TEMPSTATS, t.objid, t.subobjid, t.valnum, convert(bit, 1)) v
    WHERE 	has_access('CO', t.subobjid) = 1
go

grant select on sys.stats_columns to [public]
go

