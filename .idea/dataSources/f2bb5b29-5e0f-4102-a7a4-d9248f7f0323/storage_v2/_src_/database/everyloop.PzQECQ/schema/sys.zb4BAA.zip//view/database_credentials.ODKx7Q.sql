CREATE VIEW sys.database_credentials AS
    SELECT
        co.name,
        ISNULL(p.indepid, 1) AS principal_id, -- 1: Default DBO owner
        co.id AS credential_id,
        convert(nvarchar(4000), ov.value) as credential_identity,
        co.created as create_date,
        co.modified as modify_date,
        n.name as target_type,
        r.indepid AS target_id
    FROM sys.sysclsobjs co
    LEFT JOIN sys.sysobjvalues ov ON ov.valclass = 28 AND ov.objid = co.id AND ov.subobjid = 0 AND ov.valnum = 1
    LEFT JOIN sys.syssingleobjrefs r ON r.depid = co.id AND r.class = co.intprop AND r.depsubid = 0  
    LEFT JOIN sys.syssingleobjrefs p ON p.depid = co.id AND p.class = 121 AND p.depsubid = 0 -- SRC_DB_SCOPED_CRED_OWNER
    LEFT JOIN sys.syspalvalues n ON n.class = 'SRCL' AND n.value = co.intprop
    WHERE co.class = 57
        AND co.type = '1' -- Database Scope Credentials
		AND has_access('DC', co.id) = 1 -- View Database Scoped Credential permission.
go

grant select on sys.database_credentials to [public]
go

