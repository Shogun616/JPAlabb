CREATE VIEW sys.dm_os_buffer_descriptors AS
	SELECT
		database_id,
		file_id,
		page_id,
		page_level,
		allocation_unit_id,
		page_type,
		row_count,
		free_space_in_bytes,
		is_modified,
		numa_node,
		read_microsec,
		is_in_bpool_extension,
		error_code,
		op_history
	FROM OpenRowset(TABLE SYSBUFFERDESCRIPTORS)
go

