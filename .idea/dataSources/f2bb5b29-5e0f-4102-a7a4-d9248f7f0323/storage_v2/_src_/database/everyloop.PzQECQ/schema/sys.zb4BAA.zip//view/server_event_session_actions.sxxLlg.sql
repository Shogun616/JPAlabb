CREATE VIEW sys.server_event_session_actions AS
	SELECT 
		event_session_id = v.objid,
		event_id		 = v.subobjid,
		name			 = convert(sysname, v.value) collate catalog_default,
		package			 = convert(sysname, p.name) collate catalog_default,
		module			 = convert(sysname, m.name) collate catalog_default
	FROM master.sys.sysobjvalues v
	LEFT JOIN master.sys.sysqnames p ON p.nid =
		((((substring( v.imageval, 4, 1 ) * 256 ) +
			substring( v.imageval, 3, 1 ) * 256 ) +
			substring( v.imageval, 2, 1 ) * 256 ) +
			substring( v.imageval, 1, 1 ))
	LEFT JOIN master.sys.sysqnames m ON m.nid = p.qid
	WHERE v.valclass = 58			-- SVC_XE_SESSION_ACTION
	AND has_access ('ES', 0) = 1
go

