CREATE VIEW sys.dm_db_external_language_stats AS
 	SELECT
		external_language_id,
		is_installed
	FROM OpenRowSet(TABLE DM_DB_EXTERNAL_LANGUAGE_STATS)
go

