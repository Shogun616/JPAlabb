CREATE VIEW sys.foreign_key_columns AS
	SELECT constraint_object_id = p.depid,
		constraint_column_id = p.depsubid,
		parent_object_id = p.indepid,
		parent_column_id = p.indepsubid,
		referenced_object_id = r.indepid,
		referenced_column_id = r.indepsubid
	FROM sys.syssingleobjrefs p
	JOIN sys.syssingleobjrefs r ON r.depid = p.depid AND r.class = 29 AND r.depsubid = p.depsubid	-- SRC_FK_REFERD_COL
	WHERE p.class = 28 	-- SRC_FK_PARENT_COL
		AND has_access('CO', p.indepid) = 1
go

grant select on sys.foreign_key_columns to [public]
go

