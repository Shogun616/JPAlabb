CREATE VIEW sys.sysdatabases AS
	SELECT convert(sysname, ISNULL(p.cl_logical_database_name, d.name)) as name,
		dbid = convert(smallint, d.id_nonrepl),
		sid,
		mode = convert(smallint, 0),
		status = convert(int, dbprop((case when serverproperty('EngineEdition') = 5 then DB_ID() else d.id end), 'status80')),
		status2 = convert(int,status2 & 0x77937C00),
		crdate,
		reserved = convert(datetime, 0),
		category = convert(int,category & 0x37),
		cmptlevel,
		filename = convert(nvarchar(260), case when serverproperty('EngineEdition') = 5 then NULL else dbprop(d.id, 'primaryfilename') end),
		version = convert(smallint, dbprop((case when serverproperty('EngineEdition') = 5 then DB_ID() else d.id end), 'Version'))
	FROM sys.sysdbreg$ d OUTER APPLY OpenRowset(TABLE DBPROP, (case when serverproperty('EngineEdition') = 5 then DB_ID() else d.id end)) p
	WHERE id < 0x7fff AND repl_sys_db_visible(id) = 1
	AND has_access('DB', (case when serverproperty('EngineEdition') = 5 then DB_ID() else id end)) = 1
go

