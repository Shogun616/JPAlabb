CREATE VIEW sys.user_token AS
	SELECT * FROM OpenRowset(TABLE USERROLES)
go

