CREATE VIEW sys.dm_database_encryption_keys AS
	SELECT * FROM OpenRowset(TABLE DATABASEENCRYPTIONKEYS)
go

