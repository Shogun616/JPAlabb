CREATE VIEW sys.service_message_types AS
	SELECT name,
		message_type_id,
		principal_id,
		validation,
		validation_desc,
		xml_collection_id
	FROM sys.service_message_types$
	WHERE has_access('MT', message_type_id) = 1
go

grant select on sys.service_message_types to [public]
go

