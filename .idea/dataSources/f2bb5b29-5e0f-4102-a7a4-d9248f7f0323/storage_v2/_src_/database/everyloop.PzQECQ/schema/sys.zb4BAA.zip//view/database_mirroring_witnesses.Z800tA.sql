CREATE VIEW sys.database_mirroring_witnesses AS
	SELECT database_name = w.name,
		principal_server_name = w.psrv,
		mirror_server_name = w.ssrv,
		safety_level = w.safety,
		safety_level_desc = s.name,
		safety_sequence_number = w.safetysequence,
		role_sequence_number = w.rolesequence,
		mirroring_guid = w.logshippingid,
		family_guid = w.familyid,
		is_suspended = sysconv(bit, 1 - w.status & 1),
		is_suspended_sequence_number = w.statussequence,
		partner_sync_state = dbmw.sync_state,
		partner_sync_state_desc = dbmw.sync_state_desc
	FROM master.sys.syslogshippers w
	LEFT JOIN sys.syspalvalues s ON s.class = 'DBSL' AND s.value = w.safety
	OUTER APPLY OpenRowset(TABLE DBMIRROR_WITNESS, w.logshippingid) dbmw
go

