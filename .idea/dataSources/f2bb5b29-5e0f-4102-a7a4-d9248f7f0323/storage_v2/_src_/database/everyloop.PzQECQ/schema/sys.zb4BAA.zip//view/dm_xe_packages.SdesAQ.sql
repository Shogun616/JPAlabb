CREATE VIEW sys.dm_xe_packages AS
	SELECT *
	FROM OpenRowset(TABLE DM_XE_PACKAGES)
go

