CREATE VIEW sys.sql_expression_dependencies AS
	SELECT referencing_id, referencing_minor_id, referencing_class, referencing_class_desc,
			is_schema_bound_reference, referenced_class, referenced_class_desc,
			referenced_server_name, referenced_database_name, referenced_schema_name, referenced_entity_name,
			referenced_id, referenced_minor_id, is_caller_dependent, is_ambiguous
	FROM sys.sql_expression_dependencies$
	WHERE has_perms_by_name(quotename(db_name()), 'DATABASE', 'VIEW DEFINITION') = 1
go

