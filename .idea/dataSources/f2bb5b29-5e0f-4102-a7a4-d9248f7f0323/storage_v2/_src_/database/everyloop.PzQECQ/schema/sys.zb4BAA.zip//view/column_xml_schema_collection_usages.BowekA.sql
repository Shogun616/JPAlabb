CREATE VIEW sys.column_xml_schema_collection_usages AS
	SELECT id AS object_id,
		colid AS column_id,
		xmlns AS xml_collection_id
	FROM sys.syscolpars
	WHERE number = 0 AND xmlns > 0
go

grant select on sys.column_xml_schema_collection_usages to [public]
go

