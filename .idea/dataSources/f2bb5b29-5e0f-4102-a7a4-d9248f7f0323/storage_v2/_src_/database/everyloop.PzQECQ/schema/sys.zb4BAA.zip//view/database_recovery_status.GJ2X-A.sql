CREATE VIEW sys.database_recovery_status AS
	SELECT d.id AS database_id,
		p.database_guid,
		p.family_guid,
		p.last_log_backup_lsn,
		p.recovery_fork_guid,
		p.first_recovery_fork_guid,
		p.fork_point_lsn
	FROM master.sys.sysdbreg$ d OUTER APPLY OpenRowset(TABLE DBRECOVER, d.id) p
	WHERE d.id < 0x7fff AND repl_sys_db_visible(d.id) = 1
		AND has_access('DB', d.id) = 1
go

