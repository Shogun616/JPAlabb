CREATE VIEW sys.dm_os_sys_memory AS
	SELECT *
	FROM OpenRowSet(TABLE DM_OS_SYS_MEMORY)
go

