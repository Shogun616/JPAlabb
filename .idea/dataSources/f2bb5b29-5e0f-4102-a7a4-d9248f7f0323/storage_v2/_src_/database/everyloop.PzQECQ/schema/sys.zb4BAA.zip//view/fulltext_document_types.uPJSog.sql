CREATE VIEW sys.fulltext_document_types AS
	select componentname as [document_type], 
		   clsid as [class_id], 
		   (case when is_srvrolemember('serveradmin') = 1 then fullpath else NULL end) AS [path], 
	         version, 
	         manufacturer
	from sys.fn_ftcatcomponents(1, 0, 0)
	where componenttype = 'filter'
go

