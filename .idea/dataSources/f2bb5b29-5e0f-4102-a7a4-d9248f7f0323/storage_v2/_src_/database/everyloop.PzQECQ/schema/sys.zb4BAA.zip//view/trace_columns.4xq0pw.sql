create view sys.trace_columns as select * from OpenRowset(TABLE SYSTRACECOLUMNS)
go

