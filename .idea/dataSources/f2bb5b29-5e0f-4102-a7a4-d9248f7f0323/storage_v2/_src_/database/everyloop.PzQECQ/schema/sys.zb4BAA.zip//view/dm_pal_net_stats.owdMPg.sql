CREATE VIEW sys.dm_pal_net_stats AS
	SELECT *
	FROM OpenRowset(TABLE DM_PAL_NET_STATS)
go

