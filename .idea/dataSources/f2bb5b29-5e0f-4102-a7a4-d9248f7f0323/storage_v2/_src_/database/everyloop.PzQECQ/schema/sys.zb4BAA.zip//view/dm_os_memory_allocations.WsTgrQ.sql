CREATE VIEW sys.dm_os_memory_allocations AS
	SELECT *
	FROM OpenRowSet(TABLE SYSMEMALLOCS)
go

