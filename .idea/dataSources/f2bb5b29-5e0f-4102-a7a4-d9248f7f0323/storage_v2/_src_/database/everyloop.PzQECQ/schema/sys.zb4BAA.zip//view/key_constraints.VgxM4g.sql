
CREATE VIEW sys.key_constraints AS
	SELECT o.name, o.object_id, o.principal_id, o.schema_id, o.parent_object_id,
		o.type, o.type_desc, o.create_date, o.modify_date,
		o.is_ms_shipped, o.is_published, o.is_schema_published,
		r.indepid AS unique_index_id,
		o.is_system_named,
		CAST(1 AS BIT) AS is_enforced
	FROM sys.objects$ o
	LEFT JOIN sys.syssingleobjrefs r ON r.depid = o.object_id
	WHERE o.type IN ('PK', 'UQ')
go

grant select on sys.key_constraints to [public]
go

