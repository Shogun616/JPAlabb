CREATE VIEW sys.event_notifications AS
	SELECT o.name,
		object_id = o.id,
		parent_class = o.pclass,
		parent_class_desc = pc.name,
		parent_id = o.pid,
		create_date = o.created,
		modify_date = o.modified,
		service_name = convert(nvarchar(256), v.value) COLLATE Latin1_General_BIN,
		broker_instance = convert(sysname, sb.value) COLLATE Latin1_General_BIN,
		creator_sid = convert(varbinary(85), cs.value),
		principal_id = r.indepid
	FROM sys.sysschobjs$ o
	LEFT JOIN sys.syssingleobjrefs r ON r.depid = o.id AND r.class = 97 AND r.depsubid = 0	-- SRC_OBJOWNER
	LEFT JOIN sys.sysobjvalues v ON v.valclass = 72 AND v.objid = o.id AND v.subobjid = 0 AND v.valnum = 0		-- SVC_ASYNTRGSVCNAME
	LEFT JOIN sys.sysobjvalues sb ON sb.valclass = 74 AND sb.objid = o.id AND sb.subobjid = 0 AND sb.valnum = 0	-- SVC_ASYNTRGBRKRINST
	LEFT JOIN sys.sysobjvalues cs ON cs.valclass = 75 AND cs.objid = o.id AND cs.subobjid = 0 AND cs.valnum = 0	-- SVC_ASYNTRGCTRSID
	LEFT JOIN sys.syspalvalues pc ON pc.class = 'UNCL' AND pc.value = o.pclass
	WHERE o.type = 'EN' AND o.pclass <> 100 -- x_eunc_Server
		AND has_access('TR', o.id, o.pid, o.nsclass) = 1
go

grant select on sys.event_notifications to [public]
go

