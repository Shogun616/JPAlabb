CREATE VIEW sys.service_contract_message_usages AS
	SELECT service_contract_id = depid,
		message_type_id = indepid,
		is_sent_by_initiator = sysconv(bit, status & 1),
		is_sent_by_target = sysconv(bit, status & 2)
	FROM sys.sysmultiobjrefs
	WHERE class = 20 AND depsubid = 0 AND indepsubid = 0 -- MRC_SVCCONTRACTMSG
go

grant select on sys.service_contract_message_usages to [public]
go

