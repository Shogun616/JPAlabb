CREATE VIEW sys.dm_tcp_listener_states AS
	SELECT *
	FROM OpenRowset(TABLE SYSTCPLISTENER)
go

