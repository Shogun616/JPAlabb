CREATE VIEW sys.extended_procedures AS
	SELECT o.name, o.object_id, o.principal_id, o.schema_id, o.parent_object_id,
		o.type, o.type_desc, o.create_date, o.modify_date,
		o.is_ms_shipped, o.is_published, o.is_schema_published,
		dll_name = convert(nvarchar(260), v.value)
	FROM sys.objects$ o
	LEFT JOIN sys.sysobjvalues v ON v.valclass = 5 AND v.objid = o.object_id AND v.subobjid = 0 AND v.valnum = 0	-- SVC_XPDLLNAME
	WHERE o.type = 'X '
go

grant select on sys.extended_procedures to [public]
go

