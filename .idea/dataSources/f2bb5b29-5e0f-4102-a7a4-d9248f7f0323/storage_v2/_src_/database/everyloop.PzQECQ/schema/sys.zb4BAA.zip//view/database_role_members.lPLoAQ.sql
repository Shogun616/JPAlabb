CREATE VIEW sys.database_role_members AS
	SELECT indepid AS role_principal_id,
		depid AS member_principal_id
	FROM sys.sysmultiobjrefs
	WHERE class = 25 AND depsubid = 0 AND indepsubid = 0
		AND has_access('RL', depid, indepid) = 1	-- MRC_DBROLEMEMBER
go

grant select on sys.database_role_members to [public]
go

