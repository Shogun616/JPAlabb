CREATE VIEW sys.dm_os_latch_stats AS
	SELECT *
	FROM OpenRowset(TABLE SYSLATCHSTATS)
go

