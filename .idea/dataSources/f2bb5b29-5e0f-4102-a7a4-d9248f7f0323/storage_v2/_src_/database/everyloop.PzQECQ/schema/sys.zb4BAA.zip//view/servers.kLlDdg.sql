CREATE VIEW sys.servers AS
	SELECT s.id AS server_id,
		s.name, s.product, s.provider,
		data_source = convert(nvarchar(4000), v.value),
		location = convert(nvarchar(4000), l.value),
		provider_string = convert(nvarchar(4000), LinkedServerProperty(s.name, 'ProviderString')),
		s.catalog,
		s.connecttimeout AS connect_timeout,
		s.querytimeout AS query_timeout,
		sysconv(bit, s.status & 4) AS is_linked,				-- SRV_NORPCMAP
		sysconv(bit, s.status & 1) AS is_remote_login_enabled,	-- SRV_RPCIN
		sysconv(bit, s.status & 2) AS is_rpc_out_enabled,		-- SRV_RPCOUT
		sysconv(bit, s.status & 8) AS is_data_access_enabled,	-- SRV_DATA
		sysconv(bit, s.status & 16) AS is_collation_compatible,	-- SRV_COLLATECOMPAT
		sysconv(bit, s.status & 64) AS uses_remote_collation,	-- SRV_USERMTCOLLATE
		convert(sysname, collationpropertyfromid(s.cid,'name')) AS collation_name,
		sysconv(bit, s.status & 128) AS lazy_schema_validation,	-- SRV_LAZYSCHCHECK
		sysconv(bit, s.status & 32) AS is_system,				-- SRV_SYSTEM
		sysconv(bit, s.status & 256) AS is_publisher,			-- SRV_PUB
		sysconv(bit, s.status & 0x200) AS is_subscriber,		-- SRV_SUB
		sysconv(bit, s.status & 0x400) AS is_distributor,		-- SRV_DIST
		sysconv(bit, s.status & 0x800) AS is_nonsql_subscriber,	-- SRV_NONSQLSUB
		~(sysconv(bit, s.status & 0x1000)) AS is_remote_proc_transaction_promotion_enabled,	-- SRV_NODTCPROMOFORRPC
		s.modate AS modify_date,							-- SRV80_USERMTCOLLATE
		sysconv(bit, s.status & 0x2000) AS is_rda_server        -- SRV_REMOTEDATAARCHIVE
	FROM master.sys.sysxsrvs s
	LEFT JOIN sys.sysobjvalues v ON v.valclass = 25 AND v.objid = s.id AND v.subobjid = 1 AND v.valnum = 0	-- SRV_DATASRC
	LEFT JOIN sys.sysobjvalues l ON l.valclass = 25 AND l.objid = s.id AND l.subobjid = 2 AND l.valnum = 0	-- SRV_LOCATION
	WHERE s.id = 0 OR has_access('SR', s.id) = 1
go

