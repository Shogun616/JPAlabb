CREATE VIEW sys.server_event_session_fields AS
	SELECT 
		event_session_id = v.objid,
		object_id		 = v.subobjid,
		name			 = convert(sysname, v.imageval) collate catalog_default,
		value			 = v.value
	FROM master.sys.sysobjvalues v
	WHERE v.valclass = 59 		 -- SVC_XE_SESSION_FIELD
	AND has_access ('ES', 0) = 1
go

