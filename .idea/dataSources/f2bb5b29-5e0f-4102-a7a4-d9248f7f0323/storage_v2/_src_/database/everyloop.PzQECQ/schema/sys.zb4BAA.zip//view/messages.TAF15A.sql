CREATE VIEW sys.messages AS
	SELECT id AS message_id,
		msglangid AS language_id,
		convert(tinyint, severity) AS severity,
		sysconv(bit, status & 128) AS is_event_logged,	-- MSG80_EVENTLOG
		text
	FROM master.sys.sysusermsgs
	WHERE id > 50000	-- x_MDMessageIdUsrFmt
	UNION ALL
	SELECT message_id,
		language_id,
		severity,
		is_event_logged,
		text
	FROM OpenRowset(TABLE SYSERRORS)
go

