CREATE VIEW sys.dm_os_enumerate_fixed_drives
AS
	SELECT *
	FROM OpenRowset(TABLE DM_OS_ENUM_FIXED_DRIVES)
go

