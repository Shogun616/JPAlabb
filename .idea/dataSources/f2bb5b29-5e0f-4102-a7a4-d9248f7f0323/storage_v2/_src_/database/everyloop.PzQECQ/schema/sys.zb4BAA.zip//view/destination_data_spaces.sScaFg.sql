CREATE VIEW sys.destination_data_spaces AS
	SELECT depid AS partition_scheme_id,
		depsubid AS destination_id,
		indepid AS data_space_id
	FROM sys.syssingleobjrefs
	WHERE class = 30 AND indepsubid = 0 -- SRC_PRTSCHDSLIST
go

grant select on sys.destination_data_spaces to [public]
go

