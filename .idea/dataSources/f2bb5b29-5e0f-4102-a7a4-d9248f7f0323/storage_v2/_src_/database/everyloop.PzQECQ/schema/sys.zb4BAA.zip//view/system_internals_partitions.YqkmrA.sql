CREATE VIEW sys.system_internals_partitions AS
	SELECT rs.rowsetid AS partition_id,
		rs.idmajor AS object_id,
		rs.idminor AS index_id,
		rs.numpart AS partition_number,
		isnull(ct.rows, rs.rcrows) AS rows,
		rs.fgidfs AS filestream_filegroup_id,
		convert(bit, 1-rs.ownertype) AS is_orphaned,
		convert(tinyint, rs.status & 3) AS dropped_lob_column_state,	--RS_LOBSTAT_*
		convert(bit, rs.status & 4) AS is_unique,					--RS_UNIQUE
		convert(bit, rs.status & 8) AS is_replicated,					--RS_REPLICATED
		convert(bit, rs.status & 16) AS is_logged_for_replication,		--RS_LOG_OFFROW_FOR_REPL
		sysconv(bit, rs.status & 1073741824) AS is_sereplicated,				--RS_SEREPLICATED
		rs.maxnullbit AS max_null_bit_used,
		rs.maxleaf AS max_leaf_length,
		rs.minleaf AS min_leaf_length,
		rs.maxint AS max_internal_length,
		rs.minint AS min_internal_length,
		convert(bit, rs.status & 64) AS allows_nullable_keys,			--RS_NULLABLE_KEYS
		convert(bit, 1-(rs.status & 128)/128) AS allow_row_locks,	--RS_NO_ROWLOCK
		convert(bit, 1-(rs.status & 256)/256) AS allow_page_locks,	--RS_NO_PAGELOCK
		convert(bit, rs.status & 512) AS is_data_row_format,			--RS_DATAROW_FRMT
		convert(bit, rs.status & 2048) AS is_not_versioned,			--RS_NOTVERSIONED
		convert(uniqueidentifier, rs.rsguid) AS filestream_guid,
		rs.ownertype as ownertype,
		sysconv(bit, rs.status & 0x00010000) AS is_columnstore,
		sysconv(bit, rs.status & 0x01000000) AS optimize_for_sequential_key --RS_OPTIMIZE_FOR_SEQ_KEY
	FROM sys.sysrowsets rs OUTER APPLY OpenRowset(TABLE ALUCOUNT, rs.rowsetid, 0, 0, rs.idmajor) ct
go

