CREATE VIEW sys.dm_hadr_ag_threads AS
	SELECT group_id,
		name,
		num_databases,
		num_capture_threads,
		num_redo_threads,
		num_parallel_redo_threads,
		num_hadr_threads
	FROM OpenRowset(TABLE DM_HADR_AG_THREADS)
go

