CREATE VIEW sys.system_views AS
	SELECT name, object_id, principal_id, schema_id, parent_object_id,
		type, type_desc, create_date, modify_date,
		is_ms_shipped, is_published, is_schema_published,
		sysconv(bit, 0) AS is_replicated,
		sysconv(bit, 0) AS has_replication_filter,
		sysconv(bit, 0) AS has_opaque_metadata,
		sysconv(bit, 0) AS has_unchecked_assembly_data,
		sysconv(bit, 0) AS with_check_option,
		sysconv(bit, 0) as is_date_correlation_view,
		sysconv(bit, 0) as is_tracked_by_cdc,
		sysconv(bit, 0) as has_snapshot
	FROM sys.system_objects
	WHERE type = 'V'
go

grant select on sys.system_views to [public]
go

