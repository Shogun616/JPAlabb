CREATE VIEW sys.dm_db_xtp_memory_consumers
AS
	SELECT
	memory_consumer_id,
	memory_consumer_type,
	memory_consumer_type_desc,
	memory_consumer_desc,
	object_id,
	xtp_object_id,
	index_id,
	allocated_bytes,
	used_bytes,
	allocation_count,
	partition_count,
	sizeclass_count,
	min_sizeclass,
	max_sizeclass,
	memory_consumer_address
	FROM sys.dm_xtp_consumer_memory_usage
	WHERE database_id = db_id()
go

