CREATE VIEW sys.dm_db_xtp_checkpoint_stats
AS
	SELECT	*
	FROM OpenRowset(TABLE XTP_CKPTV2)
go

