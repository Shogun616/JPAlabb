CREATE VIEW sys.filetables AS
	SELECT p.*
	FROM sys.objects$ o WITH (NOLOCK)
		CROSS APPLY OpenRowset(TABLE FILETABLES, o.object_id) p
	WHERE o.is_filetable = 1
	AND has_access('CO', o.object_id) = 1
go

grant select on sys.filetables to [public]
go

