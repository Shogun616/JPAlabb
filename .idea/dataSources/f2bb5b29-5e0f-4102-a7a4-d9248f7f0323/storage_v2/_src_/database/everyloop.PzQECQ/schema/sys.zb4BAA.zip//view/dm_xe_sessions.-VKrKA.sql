CREATE VIEW sys.dm_xe_sessions AS
	SELECT *
	FROM OpenRowset(TABLE DM_XE_SESSIONS, 0)
go

