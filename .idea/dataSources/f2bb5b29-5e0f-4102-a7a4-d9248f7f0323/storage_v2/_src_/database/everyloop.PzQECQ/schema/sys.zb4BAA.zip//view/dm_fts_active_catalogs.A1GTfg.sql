CREATE view sys.dm_fts_active_catalogs
AS
	SELECT * FROM OpenRowset(TABLE FTCATALOGS)
go

