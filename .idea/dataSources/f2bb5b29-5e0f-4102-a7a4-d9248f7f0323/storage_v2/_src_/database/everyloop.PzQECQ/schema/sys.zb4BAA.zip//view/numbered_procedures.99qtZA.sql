CREATE VIEW sys.numbered_procedures AS
	SELECT object_id = v.objid,
		procedure_number = convert(smallint, v.subobjid),
		definition = object_definition(v.objid, v.subobjid)
	FROM sys.sysobjvalues v
	WHERE v.valclass = 1 AND v.subobjid > 1 AND v.valnum = 0 	-- SVC_OBJECTSQLEXPR
		AND has_access('CO', v.objid) = 1
go

grant select on sys.numbered_procedures to [public]
go

