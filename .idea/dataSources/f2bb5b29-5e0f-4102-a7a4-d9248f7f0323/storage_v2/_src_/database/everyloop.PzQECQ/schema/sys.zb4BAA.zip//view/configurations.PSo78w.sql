CREATE VIEW sys.configurations AS
		SELECT configuration_id,
			name,
			value,
			minimum,
			maximum,
			value_in_use,
			description,
			is_dynamic,
			is_advanced
		FROM sys.configurations$
		WHERE is_not_use = 0 AND name <> N'hybrid_buffer_pool'
go

