CREATE VIEW sys.remote_data_archive_databases AS
	SELECT 
		sc.id as remote_database_id,
		sc.name as remote_database_name,
		sc.intprop as data_source_id,
		convert(bit, case when eds.credential_id = 0 then 1 else 0 end) as federated_service_account
	FROM sys.sysclsobjs sc LEFT OUTER JOIN sys.external_data_sources eds
		ON sc.intprop = eds.data_source_id
	WHERE sc.class = 103 -- SOC_STRETCH_REMOTE_DATABASE
	 AND has_access('DB', DB_ID()) = 1
go

grant select on sys.remote_data_archive_databases to [public]
go

