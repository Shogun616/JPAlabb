CREATE VIEW sys.database_query_store_options AS
	SELECT
		desired_state,
		d.name as desired_state_desc,
		actual_state,
		a.name as actual_state_desc,
		readonly_reason,
		current_storage_size_mb,
		flush_interval_seconds,
		interval_length_minutes,
		max_storage_size_mb,
		stale_query_threshold_days,
		max_plans_per_query,
		query_capture_mode,
		c.name as query_capture_mode_desc,
		capture_policy_execution_count,
		capture_policy_total_compile_cpu_time_ms,
		capture_policy_total_execution_cpu_time_ms,
		capture_policy_stale_threshold_hours,
		size_based_cleanup_mode,
		r.name as size_based_cleanup_mode_desc,
		wait_stats_capture_mode,
		w.name as wait_stats_capture_mode_desc,
		convert(nvarchar(4000), N'') COLLATE Latin1_General_CI_AS_KS_WS  as actual_state_additional_info
	FROM OpenRowSet(TABLE QUERY_STORE_OPTIONS)
	LEFT JOIN  sys.syspalvalues a ON a.class = 'QDST' AND a.value = actual_state
	LEFT JOIN  sys.syspalvalues d ON d.class = 'QDST' AND d.value = desired_state
	LEFT JOIN  sys.syspalvalues c ON c.class = 'QDCM' AND c.value = query_capture_mode
	LEFT JOIN  sys.syspalvalues r ON r.class = 'QDRP' AND r.value = size_based_cleanup_mode
	LEFT JOIN  sys.syspalvalues w ON w.class = 'QDWS' AND w.value = wait_stats_capture_mode
go

