CREATE VIEW sys.dm_hadr_physical_seeding_stats
AS
	SELECT
		local_physical_seeding_id,
		remote_physical_seeding_id,
		local_database_id,
		local_database_name,
		remote_machine_name,
		role_desc,
		internal_state_desc,
		transfer_rate_bytes_per_second,
		transferred_size_bytes,
		database_size_bytes,
		start_time_utc,
		end_time_utc,
		estimate_time_complete_utc,
		total_disk_io_wait_time_ms,
		total_network_wait_time_ms,
		failure_code,
		failure_message,
		failure_time_utc,
		is_compression_enabled
	FROM OpenRowset(TABLE DM_CLOUD_PHYSICAL_SEEDING_STATS)
go

