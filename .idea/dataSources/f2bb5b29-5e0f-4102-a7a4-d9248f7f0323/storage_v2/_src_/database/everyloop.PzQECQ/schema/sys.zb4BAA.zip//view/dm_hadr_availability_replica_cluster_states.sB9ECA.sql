CREATE VIEW sys.dm_hadr_availability_replica_cluster_states AS
	SELECT
		replica_id = arcs.replica_id,
		replica_server_name = arcs.replica_server_name,
		group_id = arcs.group_id,
		join_state = arcs.join_state,
		join_state_desc = CASE
			WHEN (join_state = 0) THEN CAST ('NOT_JOINED' AS nvarchar(60))
			WHEN (join_state = 1) THEN CAST ('JOINED_STANDALONE' AS nvarchar(60))
			WHEN (join_state = 2) THEN CAST ('JOINED_FCI' AS nvarchar(60))
			ELSE CAST (NULL AS nvarchar(60)) END
	FROM OpenRowset(TABLE DM_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES) arcs
go

