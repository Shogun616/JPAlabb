CREATE VIEW sys.dm_db_xtp_transactions 
AS
	SELECT
	*
	FROM OpenRowset(TABLE XTP_TRANSACTIONS)
go

