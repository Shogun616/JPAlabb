CREATE VIEW sys.dm_db_partition_stats AS
	WITH partition_stats_rowstore(
		partition_id, object_id, index_id, partition_number,
		in_row_data_page_count, in_row_used_page_count, in_row_reserved_page_count,
		lob_used_page_count, lob_reserved_page_count,
		row_overflow_used_page_count, row_overflow_reserved_page_count,
		used_page_count, reserved_page_count, row_count)
	AS
	(
	SELECT
		c.partition_id,	i.object_id, i.index_id, c.partition_number,
		c.in_row_data_page_count, c.in_row_used_page_count, c.in_row_reserved_page_count,
		c.lob_used_page_count, c.lob_reserved_page_count,
		c.row_overflow_used_page_count, c.row_overflow_reserved_page_count,
		c.used_page_count, c.reserved_page_count, c.row_count
	FROM sys.indexes$ i CROSS APPLY OpenRowSet(TABLE PARTITIONCOUNTS, i.object_id, i.index_id, i.rowset) c
	WHERE i.type NOT IN (5, 6) -- Exclude columnstore indexes
		AND (i.index_id != 0
			OR OBJECTPROPERTY(i.[object_id], 'TableIsMemoryOptimized') = 0) -- Hiding heap index for hekaton tables
	)
	
	-- Result is a union of rowstore and columnstore partitions.
	
	SELECT * from partition_stats_rowstore
	
	UNION ALL

	-- For columnstore the total rows in a partition is sum of the rows in
	-- compressed row groups, deltastores, minus the rows in delete buffer and delete bitmap.
	SELECT
		MAX(CASE WHEN sip.ownertype = 1 THEN sip.partition_id ELSE CAST(0 AS bigint) END)
				AS partition_id,
		sip.object_id AS object_id,
		sip.index_id AS index_id,
		sip.partition_number AS partition_number,
		SUM(c.in_row_data_page_count) AS in_row_data_page_count,
		SUM(c.in_row_used_page_count) AS in_row_used_page_count,
		SUM(c.in_row_reserved_page_count) AS in_row_reserved_page_count,
		SUM(c.lob_used_page_count) AS lob_used_page_count,
		SUM(c.lob_reserved_page_count) AS lob_reserved_page_count,
		SUM(c.row_overflow_used_page_count) AS row_overflow_used_page_count,
		SUM(c.row_overflow_reserved_page_count) AS row_overflow_reserved_page_count,
		SUM(c.used_page_count) AS used_page_count,
		SUM(c.reserved_page_count) AS reserved_page_count,
		SUM(CASE -- ownertype 2 corresponds to delete bitmaps and 4 to delete buffers
			WHEN ownertype IN (2,4) THEN -(c.row_count) -- Flip sign of deleted bitmaps and delete buffers
			ELSE c.row_count -- delta stores are ownertype 3 and included here.
			END)
			AS row_count
		FROM sys.system_internals_partitions sip CROSS APPLY OpenRowSet(TABLE PARTITIONCOUNTS, sip.object_id, sip.index_id, sip.partition_id) c
		WHERE sip.ownertype IN (2,3,4) OR (sip.ownertype = 1 and sip.is_columnstore = 1)-- delete bitmaps, delta stores, delete buffers and compressed row groups
	GROUP BY sip.object_id, sip.index_id, sip.partition_number
go

