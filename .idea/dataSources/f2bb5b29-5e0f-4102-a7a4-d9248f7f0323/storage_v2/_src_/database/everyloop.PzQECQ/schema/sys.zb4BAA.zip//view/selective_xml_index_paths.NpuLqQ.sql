CREATE VIEW sys.selective_xml_index_paths AS
	SELECT i.id AS object_id,
		i.indid AS index_id,
		p.path_id,
		convert(nvarchar(4000), s.value) collate Latin1_General_BIN2 as path,
		p.name,
		p.path_type,
		p.path_type_desc,
		p.xml_component_id,
		convert(nvarchar(4000), s.imageval) collate Latin1_General_BIN2 as xquery_type_description,
		p.is_xquery_type_inferred,
		p.xquery_max_length,
		p.is_xquery_max_length_inferred,
		p.is_node,
		p.system_type_id,
		p.user_type_id,
		p.max_length,
		p.precision,
		p.scale,
		convert(sysname, CollationPropertyFromId(p.collationid, 'name')) AS collation_name,
		p.is_singleton
	FROM sys.sysidxstats i
	CROSS APPLY OPENROWSET(TABLE SELECTIVE_XML_INDEX_PATHS, i.id, i.indid) p
	LEFT JOIN sys.sysobjvalues s ON s.valclass = 108 and s.objid = i.id and s.subobjid = i.indid and s.valnum = p.path_id	-- SVC_SELECTIVE_DG
	WHERE (i.indid >= 256000 and i.indid < 257000) AND i.tinyprop = 76 -- is this selective XML index
		AND has_access('CO', i.id) = 1
go

grant select on sys.selective_xml_index_paths to [public]
go

