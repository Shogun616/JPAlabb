CREATE VIEW sys.dm_exec_function_stats AS
	SELECT
		database_id,
		object_id,
		type,
		n.name AS type_desc,
		sql_handle,
		plan_handle,
		cached_time,
		last_execution_time,
		execution_count,
		total_worker_time,
		last_worker_time,
		min_worker_time,
		max_worker_time,
		total_physical_reads,
		last_physical_reads,
		min_physical_reads,
		max_physical_reads,
		total_logical_writes,
		last_logical_writes,
		min_logical_writes,
		max_logical_writes,
		total_logical_reads,
		last_logical_reads,
		min_logical_reads,
		max_logical_reads,
		total_elapsed_time,
		last_elapsed_time,
		min_elapsed_time,
		max_elapsed_time,
		total_num_physical_reads, last_num_physical_reads, min_num_physical_reads, max_num_physical_reads,
		total_page_server_reads, last_page_server_reads, min_page_server_reads, max_page_server_reads,
		total_num_page_server_reads, last_num_page_server_reads, min_num_page_server_reads, max_num_page_server_reads
	FROM OpenRowset (TABLE FUNCTION_STATS) o
	LEFT JOIN sys.syspalnames n ON n.class = 'OBTY'
		AND n.value = o.type
	UNION ALL
	SELECT
		database_id,
		object_id,
		CAST ('FN' AS CHAR(2)),
		CAST ('SQL_SCALAR_FUNCTION' AS NVARCHAR(60)),
		sql_handle,
		plan_handle,
		cached_time,
		last_execution_time,
		execution_count,
		total_worker_time,
		last_worker_time,
		min_worker_time,
		max_worker_time,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		total_elapsed_time,
		last_elapsed_time,
		min_elapsed_time,
		max_elapsed_time,
		0, 0, 0, 0,	-- num physical IO
		0, 0, 0, 0,	-- page server reads
		0, 0, 0, 0	-- num page server IO IO
	FROM OpenRowset (TABLE XTP_PROC_STATS, ASCII('F') + (ASCII('N') * 256))
go

