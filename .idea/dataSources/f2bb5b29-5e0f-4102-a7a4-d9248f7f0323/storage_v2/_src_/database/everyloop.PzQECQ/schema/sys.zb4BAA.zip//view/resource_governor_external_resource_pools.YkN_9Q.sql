CREATE VIEW sys.resource_governor_external_resource_pools
AS
    -- ISSUE - VSTS 83011
    -- Use isnull() below because Algebrizer doesn't properly
    -- determine these columns are non-nullable.
    SELECT
        external_pool_id             = co.id,
        name                = co.name,
        max_cpu_percent     = isnull((co.status/0x100)     % 0x100, 0),
        max_memory_percent  = isnull((co.status/0x1000000) % 0x100, 0),
        max_processes     = isnull( convert(int,co.intprop), 0),
        version = isnull(convert(bigint, ov.value), 0)
    FROM
        master.sys.sysclsobjs co LEFT JOIN
        master.sys.sysobjvalues ov ON
        (
            co.id = ov.objid AND
            ov.valclass = 125 AND -- SVC_RG_EXTERNAL_POOL
            ov.subobjid = 0 AND
            ov.valnum = 1
        )
    WHERE 
        co.class = 104 AND -- SOC_RG_EXTERNAL_POOL
        has_access('RG', 0) = 1
go

