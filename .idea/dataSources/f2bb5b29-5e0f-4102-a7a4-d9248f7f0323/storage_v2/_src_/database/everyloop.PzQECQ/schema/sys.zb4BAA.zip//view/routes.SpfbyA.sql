CREATE VIEW sys.routes AS
	SELECT name,
		route_id = id,
		principal_id = p.indepid,
		remote_service_name = remsvc,
		broker_instance = brkrinst,
		lifetime,
		address = addr,
		mirror_address = miraddr
	FROM sys.sysrts r
	LEFT JOIN sys.syssingleobjrefs p ON p.depid = r.id AND p.class = 49 AND p.depsubid = 0	-- SRC_ROUTEOWNER
	WHERE has_access('RT', r.id) = 1
go

grant select on sys.routes to [public]
go

