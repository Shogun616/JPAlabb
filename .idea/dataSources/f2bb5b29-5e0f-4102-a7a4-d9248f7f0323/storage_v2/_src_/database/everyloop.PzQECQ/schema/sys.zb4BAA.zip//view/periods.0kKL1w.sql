CREATE VIEW sys.periods AS
	SELECT 
		convert(sysname, v.value) collate catalog_default as name,
		convert(tinyint, 1) as period_type,
		convert(nvarchar(60), 'SYSTEM_TIME_PERIOD') collate Latin1_General_CI_AS_KS_WS as period_type_desc,
		v.objid as object_id,
		v.subobjid as start_column_id,
		v.valnum as end_column_id
	FROM sys.sysobjvalues v
	WHERE v.valclass = 113 AND has_access('CO', v.objid) = 1
go

grant select on sys.periods to [public]
go

