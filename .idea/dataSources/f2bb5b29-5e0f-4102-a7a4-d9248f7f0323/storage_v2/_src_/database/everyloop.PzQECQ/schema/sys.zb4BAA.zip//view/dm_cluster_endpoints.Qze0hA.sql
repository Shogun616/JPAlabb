
-- add it
create view sys.dm_cluster_endpoints as
select
name collate database_default name,
description collate database_default description,
endpoint collate database_default endpoint,
protocol_desc collate database_default protocol_desc
from OPENROWSET(TABLE DM_CLUSTER_ENDPOINTS)
go

