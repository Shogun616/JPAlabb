CREATE VIEW sys.dm_db_xtp_hash_index_stats
AS
	SELECT H.object_id,
		xtp_object_id,
		H.index_id,
		bucket_count AS total_bucket_count,
		bucket_count - filled_count AS empty_bucket_count,
		avg_chain_length,
		max_chain_length
	FROM OpenRowset(TABLE XTP_HASH_IDX_STATS) H
	WHERE H.object_id > 0 -- filter out system tables.
go

