CREATE VIEW sys.dm_external_script_resource_usage_stats AS
 	SELECT
		package_name,
		memory_usage,
		cpu_usage
	FROM OpenRowSet(TABLE DM_EXTSCRIPT_RESOURCE_USAGE_STATS)
go

