CREATE VIEW sys.trigger_event_types AS
	SELECT type, type_name, parent_type
	FROM OpenRowset(TABLE event_notification_event_types)
	WHERE is_trigger = 1
go

