CREATE VIEW sys.fulltext_catalogs AS
	SELECT fulltext_catalog_id = o.id,
		name = o.name,
		path = convert(nvarchar(260),v.value),
		is_default = sysconv(bit,o.status & 1),					--FTCSTAT_DEFAULT
		is_accent_sensitivity_on = sysconv(bit,o.status & 2),	--FTCSTAT_ACCENT_SENSITIVE
		data_space_id = r.indepid,
		file_id = f.indepid,
		principal_id = p.indepid,
		is_importing = sysconv(bit,o.status & 4)	--FTCSTAT_IMPORTING
	FROM sys.sysclsobjs o
	LEFT JOIN sys.sysobjvalues v ON v.valclass = 41 AND v.objid = o.id AND v.subobjid = 0 and v.valnum = 0	--SVC_FTCATPATH
	LEFT JOIN sys.syssingleobjrefs r ON r.depid = o.id AND r.class = 45 AND r.depsubid = 0	-- SRC_FTCATTODS
	LEFT JOIN sys.syssingleobjrefs p ON p.depid = o.id AND p.class = 46 AND p.depsubid = 0	-- SRC_FTCATOWNER
	LEFT JOIN sys.syssingleobjrefs f ON f.depid = o.id AND f.class = 16 AND f.depsubid = 0	-- SRC_FTCATTOFILE
	WHERE o.class = 32	--SOC_FTCAT
		AND has_access('FT', o.id) = 1
go

grant select on sys.fulltext_catalogs to [public]
go

