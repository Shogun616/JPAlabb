CREATE VIEW sys.securable_classes AS
	SELECT * FROM OpenRowset(TABLE SECURABLECLASSES)
go

