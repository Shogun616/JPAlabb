CREATE VIEW sys.external_language_files AS
	SELECT 
		co.id AS external_language_id,
		ov2.imageval AS content,
		convert(sysname, ov1.value) collate catalog_default AS file_name,
		convert(tinyint, ov1.subobjid) AS platform,
		pv.name as platform_desc,
		convert(sysname, ov3.value) collate catalog_default AS parameters,
		convert(sysname, ov4.value) collate catalog_default AS environment_variables
	FROM
		sys.sysclsobjs co LEFT JOIN
		sys.sysobjvalues ov1 ON
		(
			co.id = ov1.objid AND
			ov1.valclass = 145 AND -- SVC_EXTERNAL_LANGUAGE
			ov1.valnum = 3 -- EXTLANG_FILENAME
		) LEFT JOIN
		sys.sysobjvalues ov2 ON
		(
			co.id = ov2.objid AND
			ov2.valclass = 145 AND -- SVC_EXTERNAL_LANGUAGE
			ov2.valnum = 2 AND -- EXTLANG_SOURCE
			ov2.subobjid = ov1.subobjid
		) LEFT JOIN
		sys.sysobjvalues ov3 ON
		(
			co.id = ov3.objid AND
			ov3.valclass = 145 AND -- SVC_EXTERNAL_LANGUAGE
			ov3.valnum = 4 AND -- EXTLANG_PARAMETERS
			ov3.subobjid = ov1.subobjid
		) LEFT JOIN
		sys.sysobjvalues ov4 ON
		(
			co.id = ov4.objid AND
			ov4.valclass = 145 AND -- SVC_EXTERNAL_LANGUAGE
			ov4.valnum = 5 AND -- EXTLANG_ENV_VARS
			ov4.subobjid = ov1.subobjid
		) LEFT JOIN
		sys.syspalvalues pv ON
		(
			pv.class = 'ELGP' AND
			pv.value = ov1.subobjid
		)
	WHERE
		co.class = 106 AND -- SOC_EXTERNAL_LANGUAGE
		has_access('LA', co.id) = 1
go

grant select on sys.external_language_files to [public]
go

