CREATE VIEW sys.fulltext_semantic_language_statistics_database AS
	SELECT database_id, register_date, registered_by, version
	FROM master.sys.sysftsemanticsdb
go

