CREATE VIEW sys.dm_os_windows_info AS
	SELECT *
	FROM OpenRowset(TABLE DM_OS_WINDOWS_INFO)
go

