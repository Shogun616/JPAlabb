CREATE VIEW sys.server_audit_specifications AS
	SELECT
		asp.id AS server_specification_id,
		asp.name AS name,
		asp.created AS create_date,
		asp.modified AS modify_date,
		g.guid AS audit_guid,
		sysconv(bit, sysconv (int, asp.status) & 0x1) AS is_state_enabled
	FROM master.sys.sysclsobjs asp
	LEFT JOIN master.sys.sysguidrefs g ON g.class = 6 AND g.id = asp.id AND g.subid = 0  -- GRC_SRVAUDITSPECGUID
	WHERE asp.class = 65 AND asp.type = 'SA' -- SOC_SECAUDITSPEC
		AND has_access('SA', 0) = 1
go

