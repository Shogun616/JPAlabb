CREATE VIEW sys.dm_hadr_automatic_seeding AS
	SELECT 
		start_time as start_time,
		completion_time as completion_time,
		ag_id as ag_id,
		ag_db_id as ag_db_id,
		ag_remote_replica_id as ag_remote_replica_id,
		operation_id as operation_id,
		is_source as is_source,
		current_state as current_state,
		performed_seeding as performed_seeding,
		failure_state as failure_state,
		failure_state_desc as failure_state_desc,
		error_code as error_code,
		number_of_attempts as number_of_attempts
	FROM OpenRowset(TABLE DM_HADR_AUTOMATIC_SEEDING)
	UNION
	SELECT 
		start_time as start_time,
		completion_time as completion_time,
		ag_id as ag_id,
		ag_db_id as ag_db_id,
		ag_remote_replica_id as ag_remote_replica_id,
		operation_id as operation_id,
		is_source as is_source,
		current_state collate database_default as current_state,
		performed_seeding as performed_seeding,
		failure_state as failure_state,
		failure_state_desc collate database_default as failure_state_desc,
		error_code as error_code,
		number_of_attempts as number_of_attempts
	FROM msdb.dbo.dm_hadr_automatic_seeding_history
go

