CREATE VIEW sys.identity_columns AS
	SELECT object_id = id,
		name = c.name,
		column_id = colid,
		system_type_id = xtype,
		user_type_id = utype,
		max_length = length,
		precision = prec,
		scale = scale,
		collation_name = convert(sysname,CollationPropertyFromId(collationid,'name')),
		is_nullable = sysconv(bit, 1 - (status & 1)), 	-- CPM_NOTNULL
		is_ansi_padded = sysconv(bit, status & 2), 	-- CPM_NOTRIM
		is_rowguidcol = sysconv(bit, status & 8), 	-- CPM_ROWGUIDCOL
		is_identity = sysconv(bit, status & 4), 		-- CPM_IDENTCOL
		is_filestream = sysconv(bit, status & 32), 	-- CPM_FILESTREAM
		is_replicated = sysconv(bit, status & 0x20000), 	-- CPM_REPLICAT
		is_non_sql_subscribed = sysconv(bit, status & 0x40000), 	-- CPM_NONSQSSUB
		is_merge_published = sysconv(bit, status & 0x80000), 		-- CPM_MERGEREPL
		is_dts_replicated = sysconv(bit, status & 0x100000), 		-- CPM_REPLDTS
		is_xml_document = sysconv(bit, 0),
		xml_collection_id = sysconv(int, 0),
		default_object_id = sysconv(int, 0),
		rule_object_id = sysconv(int, 0),
		seed_value = IdentityProperty(id, 'SeedValue'),
		increment_value = IdentityProperty(id, 'IncrementValue'),
		last_value = IdentityProperty(id, 'LastValue'),
		is_not_for_replication = sysconv(bit, status & 0x10000),	-- CPM_ID_REPL
		is_computed = sysconv(bit, status & 16),			-- CPM_COMPUTED				
		sysconv(bit, 0) as is_sparse,
		sysconv(bit, 0) as is_column_set,
		convert(tinyint, 0) AS generated_always_type,
		convert(nvarchar(60), 'NOT_APPLICABLE') collate Latin1_General_CI_AS_KS_WS AS generated_always_type_desc,
		convert(int, NULL) as encryption_type,
		convert(nvarchar(64), NULL) COLLATE Latin1_General_CI_AS_KS_WS as encryption_type_desc,
		convert(sysname, NULL) COLLATE Latin1_General_CI_AS_KS_WS as encryption_algorithm_name,
		convert(int, NULL) as column_encryption_key_id,
		convert(sysname, NULL) collate catalog_default as column_encryption_key_database_name,
		sysconv(bit, 0) as is_hidden,
		sysconv(bit, isnull(sov2.value, 0)) AS is_masked,
		convert(int, sov1.value) as graph_type,
		convert(nvarchar(60), v1.name) collate Latin1_General_CI_AS_KS_WS as graph_type_desc
	FROM sys.syscolpars c
	LEFT JOIN sys.sysobjvalues sov1 ON sov1.valclass = 128 /*SVC_GRAPHDB_COLUMN_TYPE*/ and sov1.objid = id and sov1.subobjid = colid and sov1.valnum = 0
	LEFT JOIN sys.sysobjvalues sov2 ON sov2.valclass = 120 /*SVC_COL_DATA_MASK*/ and sov2.objid = id and sov2.subobjid = colid and sov2.valnum = 0
	LEFT JOIN sys.syspalvalues v1 ON v1.class = 'EGCT' AND v1.value = convert(int, sov1.value)
	WHERE number = 0	-- SOC_COLUMN
		AND (status & 4) = 4 	-- CPM_IDENTCOL
		AND has_access('CO', id) = 1
go

grant select on sys.identity_columns to [public]
go

