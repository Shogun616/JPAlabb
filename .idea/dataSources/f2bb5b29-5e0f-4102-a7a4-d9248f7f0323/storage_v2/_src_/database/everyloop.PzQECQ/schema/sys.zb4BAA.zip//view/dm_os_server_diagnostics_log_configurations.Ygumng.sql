create view sys.dm_os_server_diagnostics_log_configurations
as
	select *
	from OpenRowset(TABLE DIAGLOG_CONFIGS)
go

