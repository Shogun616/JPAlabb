CREATE VIEW sys.sysforeignkeys AS
	SELECT
		constid = constraint_object_id,
		fkeyid = parent_object_id,
		rkeyid = referenced_object_id,
		fkey = convert(smallint, parent_column_id),
		rkey = convert(smallint, referenced_column_id),
		keyno = convert(smallint, constraint_column_id)
	FROM sys.foreign_key_columns
go

grant select on sys.sysforeignkeys to [public]
go

