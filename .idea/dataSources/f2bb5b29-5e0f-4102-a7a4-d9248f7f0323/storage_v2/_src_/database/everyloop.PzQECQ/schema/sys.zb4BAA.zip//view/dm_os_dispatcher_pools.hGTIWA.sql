CREATE VIEW sys.dm_os_dispatcher_pools AS
	SELECT *
	FROM OpenRowSet(TABLE DM_OS_DISPATCHERPOOLS)
go

