CREATE VIEW sys.remote_data_archive_tables AS
	SELECT
		mr.depid as object_id,
		mr.indepid as remote_database_id,
		convert(sysname, v.value) as remote_table_name,
		object_definition(mr.depid, -1) AS filter_predicate,
		convert(tinyint,
					CASE
						WHEN EXISTS (SELECT 1 FROM sys.sysobjvalues WHERE objid = mr.depid AND valclass = 116 /*SVC_STRETCH*/ AND valnum = 2 /*STRETCH_TABLE_MIGRATION_STATE*/ AND convert(int, value) & 2 <> 0  /*INBOUND UNMIGRATE*/) THEN 1
						WHEN EXISTS (SELECT 1 FROM sys.sysobjvalues WHERE objid = mr.depid AND valclass = 116 /*SVC_STRETCH*/ AND valnum = 2 /*STRETCH_TABLE_MIGRATION_STATE*/ AND convert(int, value) & 2 = 0 /*OUTBOUND MIGRATE*/) THEN 0
						ELSE 0
					END) AS migration_direction,
				convert(nvarchar(60),
					CASE
						WHEN EXISTS (SELECT 1 FROM sys.sysobjvalues WHERE objid = mr.depid AND valclass = 116 /*SVC_STRETCH*/ AND valnum = 2 /*STRETCH_TABLE_MIGRATION_STATE*/ AND convert(int, value) & 2 <> 0 /*INBOUND UNMIGRATE*/) THEN N'INBOUND'
						WHEN EXISTS (SELECT 1 FROM sys.sysobjvalues WHERE objid = mr.depid AND valclass = 116 /*SVC_STRETCH*/ AND valnum = 2 /*STRETCH_TABLE_MIGRATION_STATE*/ AND convert(int, value) & 2 = 0 /*OUTBOUND MIGRATE*/) THEN N'OUTBOUND'
						ELSE N'OUTBOUND'
					END) COLLATE catalog_default AS migration_direction_desc,
				convert(bit,
					CASE
						WHEN EXISTS (SELECT 1 FROM sys.sysobjvalues WHERE objid = mr.depid AND valclass = 116 /*SVC_STRETCH*/ AND valnum = 2 /*STRETCH_TABLE_MIGRATION_STATE*/ AND convert(int, value) & 1 <> 0 /*NOT PAUSED*/) THEN 0
						WHEN EXISTS (SELECT 1 FROM sys.sysobjvalues WHERE objid = mr.depid AND valclass = 116 /*SVC_STRETCH*/ AND valnum = 2 /*STRETCH_TABLE_MIGRATION_STATE*/ AND convert(int, value) & 1 = 0 /*PAUSED*/) THEN 1
						ELSE 1
					END) AS is_migration_paused,
				convert(bit,
					CASE
						WHEN EXISTS (SELECT 1 FROM sys.sysobjvalues WHERE objid = mr.depid AND valclass = 116 /*SVC_STRETCH*/ AND valnum = 2 /*STRETCH_TABLE_MIGRATION_STATE*/ AND convert(int, value) & 4 <> 0 /*NOT RECONCILED*/) THEN 0
						WHEN EXISTS (SELECT 1 FROM sys.sysobjvalues WHERE objid = mr.depid AND valclass = 116 /*SVC_STRETCH*/ AND valnum = 2 /*STRETCH_TABLE_MIGRATION_STATE*/ AND convert(int, value) & 4 = 0 /*RECONCILED*/) THEN 1
						ELSE 1
					END) AS is_reconciled
	FROM sys.sysmultiobjrefs mr LEFT JOIN sys.sysobjvalues v ON mr.depid = v.objid AND v.valclass = 116 /* SVC_STRETCH */ AND v.valnum = 3 /* STRETCH_TABLE_REMOTE_TABLE_NAME */
	WHERE
	 mr.class = 27 -- MRC_STRETCH_REMOTE_DATABASE
	 AND has_access('CO', mr.depid) = 1
go

grant select on sys.remote_data_archive_tables to [public]
go

