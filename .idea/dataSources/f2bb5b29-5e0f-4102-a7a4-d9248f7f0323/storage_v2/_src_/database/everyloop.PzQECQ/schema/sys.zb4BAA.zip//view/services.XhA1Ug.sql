CREATE VIEW sys.services AS
	SELECT name,
		service_id,
		principal_id,
		service_queue_id
	FROM sys.services$
	WHERE has_access('SV', service_id) = 1
go

grant select on sys.services to [public]
go

