CREATE VIEW sys.dm_server_registry AS
	SELECT *
	FROM OpenRowset(TABLE DM_SERVER_REGISTRY)
go

