CREATE VIEW sys.dm_db_mirroring_auto_page_repair AS
	SELECT d.database_id AS database_id,
		p.file_id AS file_id,
		p.page_id AS page_id,
		p.error_type AS error_type,
		p.page_status AS page_status,
		p.modification_time AS modification_time
	FROM sys.databases d CROSS APPLY OpenRowset(TABLE DBMIRROR_AUTO_PAGE_REPAIR, d.database_id) p
	WHERE d.database_id < 0x7fff
		AND has_access('DB', d.database_id) = 1
go

