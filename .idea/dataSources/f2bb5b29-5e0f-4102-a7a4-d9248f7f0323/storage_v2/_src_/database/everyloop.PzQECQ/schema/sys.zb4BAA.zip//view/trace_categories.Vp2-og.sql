create view sys.trace_categories as select * from OpenRowset(TABLE SYSTRACECATEGORIES)
go

