
CREATE VIEW sys.dm_db_rda_schema_update_status
AS
SELECT * FROM OpenRowset(TABLE DM_DB_RDA_SCHEMA_UPDATE_STATUS)
go

