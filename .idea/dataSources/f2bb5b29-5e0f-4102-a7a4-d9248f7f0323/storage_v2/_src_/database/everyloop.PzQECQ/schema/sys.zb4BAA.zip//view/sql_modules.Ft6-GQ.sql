CREATE VIEW sys.sql_modules AS
	SELECT object_id = o.id,
		definition = object_definition(o.id),
		uses_ansi_nulls = sysconv(bit, o.status & 0x40000), 			-- OBJMOD_ANSINULLS
		uses_quoted_identifier = sysconv(bit, o.status & 0x80000), 		-- OBJMOD_QUOTEDIDENT
		is_schema_bound = sysconv(bit, o.status & 0x20000), 			-- OBJMOD_SCHEMABOUND
		uses_database_collation = sysconv(bit, o.status & 0x100000), 	-- OBJMOD_USESDBCOLL
		is_recompiled = sysconv(bit, o.status & 0x400000), 				-- OBJMOD_NOCACHE
		null_on_null_input = sysconv(bit, o.status & 0x200000), 		-- OBJMOD_NULLONNULL
		execute_as_principal_id = x.indepid,
		uses_native_compilation = sysconv(bit, CASE WHEN (o.type = 'P') THEN o.status & 0x00000200	-- OBJPRC_HEKATON
												WHEN (o.type = 'FN') THEN o.status & 0x00000200		-- OBJPRC_HEKATON
												WHEN (o.type = 'TR') THEN o.status & 0x00001000		-- OBJTRG_HEKATON
												WHEN (o.type = 'IF') THEN o.status & 0x00000200		-- OBJPRC_HEKATON
												ELSE 0
												END),
		inline_type = sysconv(bit, o.status & 0x1000000),		 		-- OBJMOD_INLINE_TYPE
		is_inlineable = sysconv(bit, o.status & 0x2000000)		 		-- OBJMOD_IS_INLINEABLE
	FROM sys.sysschobjs$ o
	LEFT JOIN sys.syssingleobjrefs x ON x.depid = o.id AND x.class = 22 AND x.depsubid = 0 -- SRC_OBJEXECASOWNER
	WHERE o.pclass <> 100 -- x_eunc_Server
		AND ((o.type = 'TR' AND has_access('TR', o.id, o.pid, o.nsclass) = 1)
			OR (type IN ('P','V','FN','IF','TF','RF','IS') AND has_access('CO', o.id) = 1)
			OR (type IN ('R','D') AND o.pid = 0))
go

grant select on sys.sql_modules to [public]
go

