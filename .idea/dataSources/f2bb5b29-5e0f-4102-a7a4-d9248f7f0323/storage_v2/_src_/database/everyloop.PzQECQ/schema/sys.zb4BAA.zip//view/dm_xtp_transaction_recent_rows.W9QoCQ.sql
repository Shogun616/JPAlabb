CREATE VIEW sys.dm_xtp_transaction_recent_rows
AS
	SELECT
	*
	FROM OpenRowset(TABLE XTP_TRANSACTION_RECENT_ROWS)
go

