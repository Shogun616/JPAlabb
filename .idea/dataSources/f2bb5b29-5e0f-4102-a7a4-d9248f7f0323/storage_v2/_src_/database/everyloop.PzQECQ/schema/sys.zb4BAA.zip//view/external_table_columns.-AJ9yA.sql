
CREATE VIEW sys.external_table_columns
AS
	(SELECT columns_table.object_id,
		  columns_table.column_id,
		  oridinals_table.partition_column_ordinal,
		  oridinals_table.hash_column_ordinal
	FROM	(SELECT sys.columns.object_id AS object_id,
				  sys.columns.column_id AS column_id
			FROM   sys.columns
				  INNER JOIN sys.external_tables
						  ON sys.columns.object_id =
			sys.external_tables.object_id)
			columns_table
			LEFT JOIN (SELECT singlereftable.depid AS object_id,
							singlereftable.indepsubid AS column_id,
							CASE
							  WHEN singlereftable.class = 126 -- partition class
							THEN singlereftable.depsubid END AS partition_column_ordinal,
							CASE
							  WHEN singlereftable.class = 127 -- hash class
							THEN singlereftable.depsubid END AS hash_column_ordinal
					  FROM   sys.syssingleobjrefs singlereftable
					  WHERE  class = 126
							 OR class = 127) oridinals_table
				 ON ( columns_table.object_id = oridinals_table.object_id
						AND columns_table.column_id = oridinals_table.column_id ))

go

grant select on sys.external_table_columns to [public]
go

