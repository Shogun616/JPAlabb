CREATE VIEW sys.availability_groups_cluster AS
	SELECT 
		group_id = ags.group_id,
		name = CONVERT(sysname, ags.name),
		resource_id = CAST(ags.resource_id AS nvarchar(40)),
		resource_group_id = CAST(ags.resource_group_id AS nvarchar(40)),
		failure_condition_level,
		health_check_timeout,
		automated_backup_preference,
		automated_backup_preference_desc
	FROM OpenRowset(TABLE DM_AVAILABILITY_GROUPS_CLUSTER) ags
go

