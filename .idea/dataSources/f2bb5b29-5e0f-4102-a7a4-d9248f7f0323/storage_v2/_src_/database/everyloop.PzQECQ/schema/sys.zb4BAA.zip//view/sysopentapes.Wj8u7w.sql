CREATE VIEW sys.sysopentapes AS
	SELECT * FROM OpenRowset (TABLE OPENTAPES)
go

