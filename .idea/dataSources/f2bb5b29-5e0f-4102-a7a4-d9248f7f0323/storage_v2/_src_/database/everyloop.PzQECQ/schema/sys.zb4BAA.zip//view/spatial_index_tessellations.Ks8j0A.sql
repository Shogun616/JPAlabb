CREATE VIEW sys.spatial_index_tessellations
AS
	-- GEOMETRY_GRID indexes have a scheme id of 1 and are output by this clause.
	--
	SELECT 
	objid AS object_id, 
	subobjid AS index_id, 
	tes.name AS tessellation_scheme,
	convert(float, [2]) AS bounding_box_xmin, 
	convert(float, [3]) AS bounding_box_ymin,
	convert(float, [4]) AS bounding_box_xmax,
	convert(float, [5]) AS bounding_box_ymax,
	convert(smallint, case [6] when 1 then 4 when 2 then 16 when 3 then 64 when 4 then 256 else NULL end) AS level_1_grid,
	d1.name AS level_1_grid_desc,
	convert(smallint, case [7] when 1 then 4 when 2 then 16 when 3 then 64 when 4 then 256 else NULL end) AS level_2_grid,
	d2.name AS level_2_grid_desc,
	convert(smallint, case [8] when 1 then 4 when 2 then 16 when 3 then 64 when 4 then 256 else NULL end) AS level_3_grid,
	d3.name AS level_3_grid_desc,
	convert(smallint, case [9] when 1 then 4 when 2 then 16 when 3 then 64 when 4 then 256 else NULL end) AS level_4_grid,
	d4.name AS level_4_grid_desc,
	convert(int, [10]) AS cells_per_object
	FROM
	(
		SELECT objid, subobjid, i.intprop as scheme_id, valnum, value FROM sys.sysobjvalues v
		LEFT JOIN sys.sysidxstats i ON i.id = v.objid and i.indid = v.subobjid
		WHERE v.subobjid >= 384000 AND v.subobjid <= 385000 
			AND has_access('CO', i.id) = 1
			AND i.intprop = 1
	) AS SourceTable
	PIVOT
	(
		MIN(value) FOR valnum IN ([2], [3], [4], [5], [6], [7], [8], [9], [10])
	) AS PivotTable
	LEFT JOIN sys.syspalvalues tes ON tes.class = 'EISP' and tes.value = scheme_id
	LEFT JOIN sys.syspalvalues d1 ON d1.class = 'EISD' and d1.value = [6]
	LEFT JOIN sys.syspalvalues d2 ON d2.class = 'EISD' and d2.value = [7]
	LEFT JOIN sys.syspalvalues d3 ON d3.class = 'EISD' and d3.value = [8]
	LEFT JOIN sys.syspalvalues d4 ON d4.class = 'EISD' and d4.value = [9]

	UNION ALL

	-- GEOGRAPHY_GRID indexes have a scheme id of 2 and are output by this clause.
	-- The bounding box columns are null for geography indexes.

	SELECT 
	objid AS object_id, 
	subobjid AS index_id, 
	tes.name AS tessellation_scheme,
	null AS bounding_box_xmin, 
	null AS bounding_box_ymin,
	null AS bounding_box_xmax,
	null AS bounding_box_ymax,
	convert(smallint, case [2] when 1 then 4 when 2 then 16 when 3 then 64 when 4 then 256 else NULL end) AS level_1_grid,
	d1.name AS level_1_grid_desc,
	convert(smallint, case [3] when 1 then 4 when 2 then 16 when 3 then 64 when 4 then 256 else NULL end) AS level_2_grid,
	d2.name AS level_2_grid_desc,
	convert(smallint, case [4] when 1 then 4 when 2 then 16 when 3 then 64 when 4 then 256 else NULL end) AS level_3_grid,
	d3.name AS level_3_grid_desc,
	convert(smallint, case [5] when 1 then 4 when 2 then 16 when 3 then 64 when 4 then 256 else NULL end) AS level_4_grid,
	d4.name AS level_4_grid_desc,
	convert(int, [6]) AS cells_per_object
	FROM
	(
		SELECT objid, subobjid, i.intprop as scheme_id, valnum, value FROM sys.sysobjvalues v
		LEFT JOIN sys.sysidxstats i ON i.id = v.objid and i.indid = v.subobjid
		WHERE v.subobjid >= 384000 AND v.subobjid <= 385000 
			AND has_access('CO', i.id) = 1
			AND i.intprop = 2
	) AS SourceTable
	PIVOT
	(
		MIN(value) FOR valnum IN ([2], [3], [4], [5], [6])
	) AS PivotTable
	LEFT JOIN sys.syspalvalues tes ON tes.class = 'EISP' and tes.value = scheme_id
	LEFT JOIN sys.syspalvalues d1 ON d1.class = 'EISD' and d1.value = [2]
	LEFT JOIN sys.syspalvalues d2 ON d2.class = 'EISD' and d2.value = [3]
	LEFT JOIN sys.syspalvalues d3 ON d3.class = 'EISD' and d3.value = [4]
	LEFT JOIN sys.syspalvalues d4 ON d4.class = 'EISD' and d4.value = [5]

	UNION ALL

	-- GEOMETRY_AUTO_GRID indexes have a scheme id of 3 and are output by this clause.
	--
	SELECT 
	objid AS object_id, 
	subobjid AS index_id, 
	tes.name AS tessellation_scheme,
	convert(float, [2]) AS bounding_box_xmin, 
	convert(float, [3]) AS bounding_box_ymin,
	convert(float, [4]) AS bounding_box_xmax,
	convert(float, [5]) AS bounding_box_ymax,
	NULL AS level_1_grid,
	NULL AS level_1_grid_desc,
	NULL AS level_2_grid,
	NULL AS level_2_grid_desc,
	NULL AS level_3_grid,
	NULL AS level_3_grid_desc,
	NULL AS level_4_grid,
	NULL AS level_4_grid_desc,
	convert(int, [6]) AS cells_per_object
	FROM
	(
		SELECT objid, subobjid, i.intprop as scheme_id, valnum, value FROM sys.sysobjvalues v
		LEFT JOIN sys.sysidxstats i ON i.id = v.objid and i.indid = v.subobjid
		WHERE v.subobjid >= 384000 AND v.subobjid <= 385000 
			AND has_access('CO', i.id) = 1
			AND i.intprop = 3
	) AS SourceTable
	PIVOT
	(
		MIN(value) FOR valnum IN ([2], [3], [4], [5], [6])
	) AS PivotTable
	LEFT JOIN sys.syspalvalues tes ON tes.class = 'EISP' and tes.value = scheme_id

	UNION ALL

	-- GEOGRAPHY_AUTO_GRID indexes have a scheme id of 4 and are output by this clause.
	-- The bounding box columns are null for geography indexes.

	SELECT 
	objid AS object_id, 
	subobjid AS index_id, 
	tes.name AS tessellation_scheme,
	null AS bounding_box_xmin, 
	null AS bounding_box_ymin,
	null AS bounding_box_xmax,
	null AS bounding_box_ymax,
	NULL AS level_1_grid,
	NULL AS level_1_grid_desc,
	NULL AS level_2_grid,
	NULL AS level_2_grid_desc,
	NULL AS level_3_grid,
	NULL AS level_3_grid_desc,
	NULL AS level_4_grid,
	NULL AS level_4_grid_desc,
	convert(int, [2]) AS cells_per_object
	FROM
	(
		SELECT objid, subobjid, i.intprop as scheme_id, valnum, value FROM sys.sysobjvalues v
		LEFT JOIN sys.sysidxstats i ON i.id = v.objid and i.indid = v.subobjid
		WHERE v.subobjid >= 384000 AND v.subobjid <= 385000 
			AND has_access('CO', i.id) = 1
			AND i.intprop = 4
	) AS SourceTable
	PIVOT
	(
		MIN(value) FOR valnum IN ([2])
	) AS PivotTable
	LEFT JOIN sys.syspalvalues tes ON tes.class = 'EISP' and tes.value = scheme_id

go

grant select on sys.spatial_index_tessellations to [public]
go

