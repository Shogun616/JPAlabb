CREATE VIEW sys.sysremotelogins AS
	SELECT
		remoteserverid = convert(smallint, r.server_id),
		remoteusername = r.remote_name,
		status = convert(smallint, 0),
		p.sid,
		changedate = r.modify_date
	FROM sys.remote_logins r
	LEFT JOIN sys.server_principals p ON r.local_principal_id = p.principal_id
go

