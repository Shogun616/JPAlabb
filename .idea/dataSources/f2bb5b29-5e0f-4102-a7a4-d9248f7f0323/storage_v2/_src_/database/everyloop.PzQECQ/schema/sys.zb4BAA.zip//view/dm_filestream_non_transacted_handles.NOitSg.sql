CREATE VIEW sys.dm_filestream_non_transacted_handles AS
    SELECT *
    FROM OpenRowset(TABLE DM_FILESTREAM_NON_TRANSACTED_HANDLES)
go

