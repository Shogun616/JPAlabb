CREATE VIEW sys.assembly_references AS
	SELECT depid AS assembly_id,
		indepid AS referenced_assembly_id
	FROM sys.sysmultiobjrefs
	WHERE class = 10 AND depsubid = 0 AND indepsubid = 0
go

grant select on sys.assembly_references to [public]
go

