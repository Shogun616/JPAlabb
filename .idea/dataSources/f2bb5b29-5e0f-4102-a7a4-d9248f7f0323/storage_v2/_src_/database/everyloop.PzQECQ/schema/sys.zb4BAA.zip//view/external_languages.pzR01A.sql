CREATE VIEW sys.external_languages AS
	SELECT 
		co.id AS external_language_id,
		convert(sysname, ov1.value) collate catalog_default AS language,
		co.created AS create_date,
		sor.indepid AS principal_id
	FROM
		sys.sysclsobjs co LEFT JOIN
		sys.sysobjvalues ov1 ON
		(
			co.id = ov1.objid AND
			ov1.valclass = 145 AND -- SVC_EXTERNAL_LANGUAGE
			ov1.valnum = 1 -- EXTLANG_NAME
		) LEFT JOIN
		sys.syssingleobjrefs sor ON
		(
			sor.depid = co.id AND sor.class = 125 -- SRC_EXTERNAL_LANGUAGE_OWNER
		)
	WHERE
		co.class = 106 AND -- SOC_EXTERNAL_LANGUAGE
		has_access('LA', co.id) = 1
go

grant select on sys.external_languages to [public]
go

