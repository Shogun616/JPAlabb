CREATE VIEW sys.dm_column_encryption_enclave_operation_stats AS
	SELECT *
	FROM OpenRowset(TABLE DM_COLUMN_ENCRYPTION_ENCLAVE_OPERATION_STATS)
go

