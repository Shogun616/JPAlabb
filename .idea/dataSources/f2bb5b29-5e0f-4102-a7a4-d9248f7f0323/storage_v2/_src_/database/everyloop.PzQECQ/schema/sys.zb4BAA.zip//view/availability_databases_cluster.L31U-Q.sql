CREATE VIEW sys.availability_databases_cluster AS
	SELECT 
		group_id = agdbs.group_id,
		group_database_id = agdbs.group_database_id,
		database_name = CONVERT(sysname, agdbs.database_name),
		truncation_lsn = agdbs.truncation_lsn
	FROM OpenRowset(TABLE DM_AVAILABILITY_DATABASES_CLUSTER) agdbs
go

