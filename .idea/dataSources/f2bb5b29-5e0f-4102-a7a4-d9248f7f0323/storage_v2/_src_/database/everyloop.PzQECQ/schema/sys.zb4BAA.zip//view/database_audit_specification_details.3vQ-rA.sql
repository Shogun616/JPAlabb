CREATE VIEW sys.database_audit_specification_details AS
	SELECT
		database_specification_id	= asp.id,
		audit_action_id 			= saa.type, -- EDiskAuditActionType
		audit_action_name 			= convert(nvarchar(60), 
											audit_action_property('name', saa.class, saa.type)),
		class 						= saa.class, -- EMDPermissionClass
		class_desc				 	= n.name,
		major_id				 	= saa.id,
		minor_id				 	= saa.subid,
		audited_principal_id		= saa.grantee,
		audited_result			 	= convert(nvarchar(60), 'SUCCESS AND FAILURE'),
		is_group				 	= sysconv(bit, 
										audit_action_property('is_group', saa.class, saa.type))
	FROM
		sys.sysclsobjs asp INNER JOIN 
		sys.sysaudacts saa ON
			(
				saa.audit_spec_id = asp.id
			) LEFT JOIN
		sys.syspalvalues n ON 
			(
				n.class = 'UNCL' AND
				n.value = saa.class
			)
	WHERE
		asp.class = 65 AND -- SOC_SECAUDITSPEC
		asp.type = 'DA'
		AND has_access('DA', 0) = 1 -- catalog security check
go

grant select on sys.database_audit_specification_details to [public]
go

