CREATE VIEW INFORMATION_SCHEMA.COLUMN_DOMAIN_USAGE
AS
SELECT
	DB_NAME()					AS DOMAIN_CATALOG,
	SCHEMA_NAME(t.schema_id)	AS DOMAIN_SCHEMA,
	t.name						AS DOMAIN_NAME,
	DB_NAME()					AS TABLE_CATALOG,
	SCHEMA_NAME(o.schema_id)	AS TABLE_SCHEMA,
	o.name						AS TABLE_NAME,
	c.name						AS COLUMN_NAME
FROM
	sys.objects o JOIN sys.columns c ON c.object_id = o.object_id
	JOIN sys.types t ON t.user_type_id = c.user_type_id
WHERE
	c.user_type_id > 256	-- UDT
go

