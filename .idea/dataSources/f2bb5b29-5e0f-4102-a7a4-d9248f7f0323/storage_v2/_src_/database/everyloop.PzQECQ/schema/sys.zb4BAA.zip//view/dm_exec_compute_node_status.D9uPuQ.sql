
-- add it
create view sys.dm_exec_compute_node_status as
select
	B.compute_node_id,
	B.process_id,
	B.process_name	collate database_default process_name,
	B.allocated_memory,
	B.available_memory,
	B.process_cpu_usage,
	B.total_cpu_usage,
	B.thread_count,
	B.handle_count,
	B.total_elapsed_time,
	B.is_available,
	B.sent_time,
	B.received_time,
	B.error_id	collate database_default error_id,
	A.compute_pool_id
from (
	select 0
	union all
	select bdc_pool_id as compute_pool_id
	from OPENROWSET(TABLE DM_EXEC_COMPUTE_POOLS, 0)
	) as A(compute_pool_id)
cross apply
	sys.fn_polybase_compute_node_status_per_pool(A.compute_pool_id) B
go

