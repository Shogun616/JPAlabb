CREATE VIEW sys.dm_os_sys_info AS
	SELECT *
	FROM OpenRowset(TABLE SYSINFO)
go

