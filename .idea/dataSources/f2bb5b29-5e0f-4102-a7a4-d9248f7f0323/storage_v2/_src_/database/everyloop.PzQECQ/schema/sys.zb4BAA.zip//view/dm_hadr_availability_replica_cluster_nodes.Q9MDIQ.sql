CREATE VIEW sys.dm_hadr_availability_replica_cluster_nodes AS
	SELECT *
	FROM OpenRowset(TABLE DM_HADR_AVAILABILITY_REPLICA_CLUSTER_NODES)
go

