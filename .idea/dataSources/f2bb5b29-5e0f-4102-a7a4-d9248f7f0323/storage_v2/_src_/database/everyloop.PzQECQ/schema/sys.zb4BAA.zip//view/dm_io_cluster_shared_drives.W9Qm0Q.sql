create view sys.dm_io_cluster_shared_drives
as
	select * from OpenRowset(TABLE SERVERSHAREDDRIVES)
go

