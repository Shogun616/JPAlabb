CREATE VIEW sys.dm_os_memory_cache_entries AS
	SELECT *
	FROM OpenRowset(TABLE SYSMEMORYCACHEENTRIES)
go

