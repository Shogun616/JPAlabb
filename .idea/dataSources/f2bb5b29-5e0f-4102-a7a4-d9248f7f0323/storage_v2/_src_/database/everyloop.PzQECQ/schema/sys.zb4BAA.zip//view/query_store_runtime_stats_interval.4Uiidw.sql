CREATE VIEW sys.query_store_runtime_stats_interval AS
	SELECT	*
	FROM sys.plan_persist_runtime_stats_interval
	UNION ALL
	SELECT	TOP 0 *
	FROM OpenRowSet(TABLE QUERY_STORE_RUNTIME_STATS_INTERVAL)
go

grant select on sys.query_store_runtime_stats_interval to [public]
go

