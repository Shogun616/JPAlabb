CREATE VIEW sys.sysservers AS SELECT
	srvid = convert(smallint, server_id),
	srvstatus = convert(smallint,
		is_remote_login_enabled + is_publisher * 2
		+ is_subscriber * 4 + is_distributor * 8
		+ is_linked * 32 + is_rpc_out_enabled * 64
		+ is_data_access_enabled * 128 + is_collation_compatible * 256
		+ is_system * 512 + uses_remote_collation * 1024
		+ lazy_schema_validation * 2048 + is_nonsql_subscriber * 4096),
	srvname = name,
	srvproduct = product,
	providername = case when UPPER(provider) = N'SQLNCLI' then N'SQLOLEDB' else provider end,
	datasource = data_source,
	location,
	providerstring = provider_string,
	schemadate = modify_date,
	topologyx = convert(int, 0),
	topologyy = convert(int, 0),
	catalog,
	srvcollation = convert(sysname, collationproperty(collation_name, 'collationid')),
	connecttimeout = connect_timeout,
	querytimeout = query_timeout,
	srvnetname = convert(char(30), case when (product = N'SQL Server') then data_source end),
	isremote = sysconv(bit, 1 - is_linked),
	rpc = is_remote_login_enabled,
	pub = is_publisher,
	sub = is_subscriber,
	dist = is_distributor,
	dpub = sysconv(bit, is_distributor & is_publisher),
	rpcout = is_rpc_out_enabled,
	dataaccess = is_data_access_enabled,
	collationcompatible = is_collation_compatible,
	system = is_system,
	useremotecollation = uses_remote_collation,
	lazyschemavalidation = lazy_schema_validation,
	collation = collation_name,
	nonsqlsub = is_nonsql_subscriber
FROM sys.servers
go

