CREATE VIEW sys.dm_db_xtp_table_memory_stats
AS
	SELECT
		object_id,
		memory_allocated_for_table_kb,
		memory_used_by_table_kb,
		memory_allocated_for_indexes_kb,
		memory_used_by_indexes_kb
	FROM
		sys.dm_db_xtp_table_memory_stats$
	WHERE database_id = db_id()
go

