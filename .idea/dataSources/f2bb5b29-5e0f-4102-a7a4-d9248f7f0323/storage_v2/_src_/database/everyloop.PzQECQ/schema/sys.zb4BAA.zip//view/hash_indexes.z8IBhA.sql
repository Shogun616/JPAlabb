CREATE VIEW sys.hash_indexes AS
	SELECT i.id AS object_id,
		i.name AS name,
		i.indid AS index_id,
		i.type,
		n.name AS type_desc,
		sysconv(bit, i.status & 0x8) AS is_unique,			-- IS_IND_UNIQUE
		0 AS data_space_id,
		sysconv(bit, i.status & 0x4) AS ignore_dup_key,		-- IS_IND_DPKEYS
		sysconv(bit, i.status & 0x20) AS is_primary_key,	-- IS_IND_PRIMARY
		sysconv(bit, i.status & 0x40) AS is_unique_constraint,	-- IS_IND_UNIQUE_CO
		i.fillfact AS fill_factor,
		sysconv(bit, i.status & 0x10) AS is_padded,		-- IS_IND_PADINDEX
		sysconv(bit, i.status & 0x80) AS is_disabled,		-- IS_IND_OFFLINE
		sysconv(bit, i.status & 0x100) AS is_hypothetical,	-- IS_IND_ITWINDEX
		sysconv(bit, i.status & 0x02000000) AS is_ignored_in_optimization,	-- IS_IND_IGNORE_IN_OPTIMIZATION
		sysconv(bit, 1 - (i.status & 512)/512) AS allow_row_locks,		-- IS_IND_NO_ROWLOCK
		sysconv(bit, 1 - (i.status & 1024)/1024) AS allow_page_locks,		-- IS_IND_NO_PAGELOCK
		sysconv(bit, i.status & 0x20000) AS has_filter,	-- IS_HAS_FILTER
		case when (i.status & 0x20000) != 0 then object_definition(i.id, i.indid, 7) else NULL end AS filter_definition, -- x_euncIndex
		i.intprop AS bucket_count,
		sysconv(bit, i.status & 0x08000000) AS auto_created	-- IS_IND_AUTO_CREATED
	FROM sys.sysidxstats i
	LEFT JOIN sys.syssingleobjrefs ds ON ds.depid = i.id AND ds.class = 7 AND ds.depsubid = i.indid	-- SRC_INDEXTODS
	LEFT JOIN sys.syspalvalues n ON n.class = 'IDXT' and n.value = i.type
	WHERE (i.status & 1) <> 0 AND i.type = 7 -- HASH indexes are type 7
		AND has_access('CO', i.id) = 1	-- IS_INDEX
go

grant select on sys.hash_indexes to [public]
go

