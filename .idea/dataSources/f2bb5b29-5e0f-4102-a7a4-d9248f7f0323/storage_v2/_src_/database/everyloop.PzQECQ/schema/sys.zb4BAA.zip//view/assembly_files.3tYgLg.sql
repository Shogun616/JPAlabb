CREATE VIEW sys.assembly_files AS
		SELECT asm.objid AS assembly_id,
			convert(nvarchar(260), asm.value) collate catalog_default AS name,
			asm.subobjid AS file_id,
			case when asm.objid < 65536 then GetSystemAssemblyBytes(asm.objid) else f.imageval end AS content -- x_MinUserAssemblyId
		FROM sys.sysobjvalues asm
		LEFT JOIN sys.sysobjvalues f ON f.valclass = 10 AND f.objid = asm.objid AND f.subobjid = asm.subobjid AND f.valnum = 2
		WHERE asm.valclass = 10 AND asm.valnum = 1	-- SVC_ASSEMBLYFILE
			AND has_access('AF', asm.objid) = 1
go

grant select on sys.assembly_files to [public]
go

