CREATE VIEW sys.server_role_members AS
	SELECT role_principal_id = indepid,
		member_principal_id = depid
	FROM master.sys.sysmultiobjrefs
	WHERE class = 26 AND depsubid = 0 AND indepsubid = 0	-- MRC_SRVROLEMEMBER
		AND has_access('SM', depid, indepid) = 1
go

