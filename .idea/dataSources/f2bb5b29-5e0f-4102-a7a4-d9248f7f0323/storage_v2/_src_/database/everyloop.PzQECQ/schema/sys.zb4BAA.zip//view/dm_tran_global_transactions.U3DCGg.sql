CREATE VIEW sys.dm_tran_global_transactions AS
	SELECT *
	FROM OpenRowset(TABLE GLOBAL_TRANSACTIONS)
go

