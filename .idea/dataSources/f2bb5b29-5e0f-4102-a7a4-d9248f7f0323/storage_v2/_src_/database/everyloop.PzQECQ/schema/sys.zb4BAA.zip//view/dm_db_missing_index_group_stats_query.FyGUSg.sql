CREATE VIEW sys.dm_db_missing_index_group_stats_query AS

	SELECT
		-- key
		group_handle = index_id,
		query_hash,
		query_plan_hash,
		
		-- last statement descriptor
		last_sql_handle,
		last_statement_start_offset,
		last_statement_end_offset,
		last_statement_sql_handle,
		
		-- stats for user queries
		user_seeks,
		user_scans,
		last_user_seek,
		last_user_scan,
		avg_total_user_cost =
			CASE 
				WHEN (user_seeks + user_scans) > 0 
				THEN total_user_cost / (user_seeks + user_scans)
				ELSE 0 
			END,
		avg_user_impact =
			CASE 
				WHEN (user_seeks + user_scans) > 0 AND total_user_improvement > 0 AND total_user_cost > 0
				THEN ROUND(100 * IIF(total_user_improvement > total_user_cost, 1, total_user_improvement / total_user_cost), 2)
				ELSE 0 
			END,

		-- stats for system queries
		system_seeks,
		system_scans,
		last_system_seek,
		last_system_scan,
		avg_total_system_cost =
			CASE 
				WHEN (system_seeks + system_scans) > 0 
				THEN total_system_cost / (system_seeks + system_scans)
				ELSE 0 
			END,
		avg_system_impact =
			CASE 
				WHEN (system_seeks + system_scans) > 0 AND total_system_improvement > 0 AND total_system_cost > 0
				THEN ROUND(100 * IIF(total_system_improvement > total_system_cost, 1, total_system_improvement / total_system_cost), 2)
				ELSE 0 
			END

	FROM OpenRowset(TABLE LOGINDEXSTATS)
	WHERE status <> 0
go

