CREATE VIEW sys.dm_db_task_space_usage AS
	SELECT *
	FROM OpenRowset(TABLE DM_DB_TASK_SPACE_USAGE)
go

