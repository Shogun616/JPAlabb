
CREATE VIEW sys.dm_hpc_device_stats AS
	SELECT * from OpenRowset (TABLE HPC_DEVICE_STATS);
go

