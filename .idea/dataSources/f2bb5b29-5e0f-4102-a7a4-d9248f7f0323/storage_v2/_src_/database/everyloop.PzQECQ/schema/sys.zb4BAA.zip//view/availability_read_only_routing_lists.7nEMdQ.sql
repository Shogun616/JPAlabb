CREATE VIEW sys.availability_read_only_routing_lists  AS
	SELECT
		replica_id = reps.ag_replica_id,
		rrls.*
	FROM
		sys.dm_hadr_internal_wsfc_ag_replicas AS reps
	CROSS APPLY
		OpenRowset(TABLE DM_HADR_INTERNAL_AG_READONLY_ROUTING_LIST, reps.ag_id, reps.ag_replica_id) AS rrls
go

