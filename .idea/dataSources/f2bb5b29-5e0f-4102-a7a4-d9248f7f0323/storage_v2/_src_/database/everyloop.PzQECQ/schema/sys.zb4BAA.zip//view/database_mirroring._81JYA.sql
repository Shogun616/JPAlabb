CREATE VIEW sys.database_mirroring AS
	SELECT d.id_nonrepl AS database_id,
		p.guid AS mirroring_guid,
		p.state AS mirroring_state, p.state_desc AS mirroring_state_desc,
		p.role AS mirroring_role, p.role_desc AS mirroring_role_desc,
		p.role_sequence AS mirroring_role_sequence,
		p.safety_level AS mirroring_safety_level,
		p.safety_level_desc AS mirroring_safety_level_desc,
		p.safety_sequence AS mirroring_safety_sequence,
		p.partner_name AS mirroring_partner_name,
		p.partner_instance AS mirroring_partner_instance,
		p.witness_name AS mirroring_witness_name,
		p.witness_state AS mirroring_witness_state,
		p.witness_state_desc AS mirroring_witness_state_desc,
		p.failover_lsn AS mirroring_failover_lsn,
		p.connection_timeout AS mirroring_connection_timeout,
		p.redo_queue AS mirroring_redo_queue,
		p.redo_queue_type AS mirroring_redo_queue_type,
		p.end_of_log_lsn AS mirroring_end_of_log_lsn,
		p.safe_relication_lsn AS mirroring_replication_lsn
	FROM master.sys.sysdbreg$ d OUTER APPLY OpenRowset(TABLE DBMIRROR, d.id) p
	WHERE d.id < 0x7fff AND repl_sys_db_visible(d.id) = 1
		AND has_access('DB', d.id) = 1
go

