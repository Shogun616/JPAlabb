CREATE VIEW sys.dm_clr_appdomains AS
	SELECT
		appdomain_address,
		appdomain_id,
		appdomain_name,
		creation_time,
		db_id,
		user_id,
		state,
		strong_refcount,
		weak_refcount,
		cost,
		value,
		compatibility_level,
		total_processor_time_ms,
		total_allocated_memory_kb,
		survived_memory_kb
	FROM OpenRowset(TABLE DM_CLR_APPDOMAINS)
go

