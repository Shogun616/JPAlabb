CREATE VIEW sys.dm_db_file_space_usage AS
	SELECT *
	FROM OpenRowset(TABLE DM_DB_FILE_SPACE_USAGE)
go

