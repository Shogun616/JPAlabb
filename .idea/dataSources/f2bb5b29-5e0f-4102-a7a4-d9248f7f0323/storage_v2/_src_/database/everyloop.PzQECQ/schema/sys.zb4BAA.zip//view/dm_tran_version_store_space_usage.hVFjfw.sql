CREATE VIEW sys.dm_tran_version_store_space_usage AS
	SELECT *
	FROM OpenRowset(TABLE DM_TRAN_VERSION_STORE_SPACE_USAGE)
go

