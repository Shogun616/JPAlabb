CREATE VIEW sys.syscursorcolumns AS
	SELECT *
	FROM OpenRowSet(TABLE SYSCURSORCOLS)
go

