CREATE VIEW sys.dm_os_ring_buffers AS
	SELECT *
	FROM OpenRowset(TABLE SYSRINGBUFFERS)
go

