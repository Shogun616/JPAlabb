CREATE VIEW sys.dm_db_script_level AS
	SELECT
		d.database_id AS database_id,
		s.script_id AS script_id,
		s.script_name AS script_name,
		s.version AS version,
		s.script_level AS script_level,
		s.downgrade_start_level AS downgrade_start_level,
		s.downgrade_target_level AS downgrade_target_level,
		s.upgrade_start_level AS upgrade_start_level,
		s.upgrade_target_level AS upgrade_target_level
	FROM sys.databases d CROSS APPLY OpenRowset(TABLE DBSCRIPTLEVEL, d.database_id) s
	WHERE d.database_id < 0x7fff
		AND has_access('DL', 0) = 1
go

