CREATE VIEW sys.dm_os_nodes AS
	SELECT *
	FROM OpenRowSet(TABLE DM_OS_NODES)
go

