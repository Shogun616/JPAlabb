CREATE VIEW sys.dm_xtp_gc_queue_stats
AS
	SELECT		*
	FROM 		OpenRowset(TABLE XTP_GC_QUEUE_STATS)
go

