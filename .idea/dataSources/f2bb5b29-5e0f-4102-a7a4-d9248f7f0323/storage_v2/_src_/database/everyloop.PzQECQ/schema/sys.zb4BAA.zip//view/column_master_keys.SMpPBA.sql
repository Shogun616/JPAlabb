CREATE VIEW sys.column_master_keys AS
	SELECT 
		sc.name as name, 
		sc.id as column_master_key_id,
		sc.created AS create_date,
		sc.modified AS modify_date,
		convert(sysname, sov2.value) collate catalog_default as key_store_provider_name,
		convert(nvarchar(4000), sov1.value) collate catalog_default as key_path,
		(case when (sov3.value is null) then 0 else 1 end) as allow_enclave_computations,
		convert(varbinary(8000), sov4.value) as signature
	FROM sys.sysclsobjs sc
	INNER JOIN sys.sysobjvalues sov1 ON sov1.valclass = 114 /*SVC_COL_MASTER_KEY_VERSION*/ and sov1.objid = sc.id and sov1.valnum = 0 -- KEY_PATH
	INNER JOIN sys.sysobjvalues sov2 ON sov2.valclass = 114 /*SVC_COL_MASTER_KEY_VERSION*/ and sov2.objid = sc.id and sov2.subobjid = sov1.subobjid and sov2.valnum = 1 -- KEY_STORE_NAME
	LEFT OUTER JOIN sys.sysobjvalues sov3 ON sov3.valclass = 114 /*SVC_COL_MASTER_KEY_VERSION*/ and sov3.objid = sc.id and sov3.subobjid = sov1.subobjid and sov3.valnum = 2 -- ENCLAVE_SUPPORT
	LEFT OUTER JOIN sys.sysobjvalues sov4 ON sov4.valclass = 114 /*SVC_COL_MASTER_KEY_VERSION*/ and sov4.objid = sc.id and sov4.subobjid = sov1.subobjid and sov4.valnum = 3 -- SIGNATURE	
	WHERE sc.class = 101 -- SOC_COLMASTERKEY
	AND has_access('CM', DB_ID()) = 1
go

grant select on sys.column_master_keys to [public]
go

