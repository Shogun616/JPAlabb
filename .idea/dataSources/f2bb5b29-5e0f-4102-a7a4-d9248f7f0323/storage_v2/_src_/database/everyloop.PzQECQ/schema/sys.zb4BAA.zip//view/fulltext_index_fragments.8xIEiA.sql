CREATE VIEW sys.fulltext_index_fragments AS
	SELECT cprelid as table_id, fragid as fragment_id, fragobjid as fragment_object_id, ts as timestamp, status, datasize as data_size, rowcnt as row_count
	FROM sys.syscompfragments
go

grant select on sys.fulltext_index_fragments to [public]
go

