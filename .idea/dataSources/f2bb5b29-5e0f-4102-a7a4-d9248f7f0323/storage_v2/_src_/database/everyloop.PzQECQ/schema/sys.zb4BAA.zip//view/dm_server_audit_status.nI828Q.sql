CREATE VIEW sys.dm_server_audit_status AS
	SELECT *
	FROM OpenRowset(TABLE DM_SERVER_AUDIT_STATUS)
go

