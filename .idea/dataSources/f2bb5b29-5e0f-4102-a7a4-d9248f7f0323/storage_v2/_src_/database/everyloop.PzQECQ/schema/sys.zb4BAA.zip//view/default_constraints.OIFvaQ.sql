CREATE VIEW sys.default_constraints AS
	SELECT name, object_id, principal_id, schema_id, parent_object_id,
		type, type_desc, create_date, modify_date,
		is_ms_shipped, is_published, is_schema_published,
		property AS parent_column_id,
		object_definition(object_id) AS definition,
		is_system_named
	FROM sys.objects$
	WHERE type = 'D ' AND 
		(parent_object_id > 0 OR 
		(parent_object_id & 0xe0000000 = 0xa0000000)) -- IsLocalTempObjectId
go

grant select on sys.default_constraints to [public]
go

