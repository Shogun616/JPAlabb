CREATE VIEW sys.dm_db_xtp_nonclustered_index_stats
AS
	SELECT
	*
	FROM OpenRowset(TABLE XTP_RANGE_INDEX_STATS)
go

