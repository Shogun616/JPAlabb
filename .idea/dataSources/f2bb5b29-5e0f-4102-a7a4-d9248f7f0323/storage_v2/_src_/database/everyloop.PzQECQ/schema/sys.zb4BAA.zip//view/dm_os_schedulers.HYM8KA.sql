CREATE VIEW sys.dm_os_schedulers AS
	SELECT *
	FROM OpenRowSet(TABLE SYSSCHEDULERS)
go

