CREATE VIEW sys.dm_os_memory_clerks AS
	SELECT *
	FROM OpenRowSet(TABLE SYSMEMCLERKS)
go

