
CREATE VIEW sys.dm_hpc_thread_proxy_stats AS
	SELECT * from OpenRowset (TABLE HPC_THREAD_PROXY_STATS);
go

