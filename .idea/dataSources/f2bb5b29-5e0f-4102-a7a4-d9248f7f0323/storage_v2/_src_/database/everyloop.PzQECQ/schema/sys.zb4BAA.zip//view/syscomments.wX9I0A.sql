-- Return system objects in master database context
CREATE VIEW sys.syscomments AS
	SELECT o.id AS id,
		convert(smallint, case when o.type in ('P', 'RF') then 1 else 0 end) AS number,
		s.colid, s.status,
		convert(varbinary(8000), s.text) AS ctext,
		convert(smallint, 2 + 4 * (s.status & 1)) AS texttype,
		convert(smallint, 0) AS language,
		sysconv(bit, s.status & 1) AS encrypted,
		sysconv(bit, 0) AS compressed,
		s.text
	FROM sys.sysschobjs$ o CROSS APPLY OpenRowset(TABLE SQLSRC, o.id, 0) s
	WHERE o.nsclass = 0 -- x_eonc_Standard
		AND o.pclass = 1 -- x_eunc_Object
		AND o.type IN ('C','D','P','R','V','X','FN','IF','TF','RF','IS','TR')
	AND (DB_ID() = 1 AND has_access('AO', o.id) = 1 OR has_access('CO', o.id) = 1)
	UNION ALL
	SELECT c.object_id AS id,
		convert(smallint, c.column_id) AS number,
		s.colid, s.status,
		convert(varbinary(8000), s.text) AS ctext,
		convert(smallint, 2 + 4 * (s.status & 1)) AS texttype,
		convert(smallint, 0) AS language,
		sysconv(bit, s.status & 1) AS encrypted,
		sysconv(bit, 0) AS compressed,
		s.text
	FROM sys.computed_columns c CROSS APPLY OpenRowset(TABLE SQLSRC, c.object_id, c.column_id) s
	UNION ALL
	SELECT p.object_id AS id,
		convert(smallint, p.procedure_number) AS number,
		s.colid, s.status,
		convert(varbinary(8000), s.text) AS ctext,
		convert(smallint, 2 + 4 * (s.status & 1)) AS texttype,
		convert(smallint, 0) AS language,
		sysconv(bit, s.status & 1) AS encrypted,
		sysconv(bit, 0) AS compressed,
		s.text
	FROM sys.numbered_procedures p CROSS APPLY OpenRowset(TABLE SQLSRC, p.object_id, p.procedure_number) s
go

grant select on sys.syscomments to [public]
go

