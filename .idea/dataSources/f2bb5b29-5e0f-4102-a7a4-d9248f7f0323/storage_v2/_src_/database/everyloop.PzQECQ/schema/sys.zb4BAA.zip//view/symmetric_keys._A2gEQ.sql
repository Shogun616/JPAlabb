CREATE VIEW sys.symmetric_keys AS
	SELECT s.name AS name,
		r.indepid AS principal_id,
		s.id AS symmetric_key_id,
		s.intprop AS key_length,
		s.type AS key_algorithm,
		case when vpt.value = 6 then  -- x_emd_EKMProvider = 6
		    convert(nvarchar(60),symkeyproperty(s.id, 'algorithm_desc'))
		    else alg.name end AS algorithm_desc,
		s.created AS create_date,
		s.modified AS modify_date,
		g.guid AS key_guid,
		vph.value AS key_thumbprint,
		n.name as provider_type,
		convert(uniqueidentifier, vpg.value) AS cryptographic_provider_guid,
		vpa.value AS cryptographic_provider_algid
	FROM sys.sysclsobjs s
	LEFT JOIN sys.syssingleobjrefs r ON r.depid = s.id AND r.class = 47 AND r.depsubid = 0
	LEFT JOIN sys.sysguidrefs g ON g.id = s.id AND g.class = 2 AND g.subid = 0
	LEFT JOIN sys.syspalnames alg ON alg.class = 'ENAL' AND alg.value = s.type
	LEFT JOIN sys.sysobjvalues vpt ON vpt.valclass = 35 AND vpt.objid = s.id AND vpt.subobjid = 0 AND vpt.valnum = 1	-- SVC_OKEYPROVPROPS/PROV_TYPE_PROP
	LEFT JOIN sys.sysobjvalues vpg ON vpg.valclass = 35 AND vpg.objid = s.id AND vpg.subobjid = 0 AND vpg.valnum = 2	-- SVC_OKEYPROVPROPS/PROV_GUID_PROP
	LEFT JOIN sys.sysobjvalues vpa ON vpa.valclass = 35 AND vpa.objid = s.id AND vpa.subobjid = 0 AND vpa.valnum = 3	-- SVC_OKEYPROVPROPS/PROV_ALGID_PROP
	LEFT JOIN sys.sysobjvalues vph ON vph.valclass = 35 AND vph.objid = s.id AND vph.valnum = 4	-- SVC_OKEYPROVPROPS/PROV_THUMB_PROP
	LEFT JOIN sys.syspalvalues n ON n.class = 'CPKP' AND n.value = vpt.value
	WHERE s.class = 56
		AND has_access('OK', s.id) = 1
go

grant select on sys.symmetric_keys to [public]
go

