
-- add it
create view sys.dm_exec_distributed_request_steps as
select
	B.execution_id	collate database_default execution_id,
	B.step_index,
	B.operation_type	collate database_default operation_type,
	B.distribution_type	collate database_default distribution_type,
	B.location_type	collate database_default location_type,
	B.status		collate database_default status,
	B.error_id	collate database_default error_id,
	B.start_time,
	B.end_time,
	B.total_elapsed_time,
	B.row_count,
	B.command		collate database_default command,
	A.compute_pool_id
from (
	select 0
	union all
	select bdc_pool_id as compute_pool_id
	from OPENROWSET(TABLE DM_EXEC_COMPUTE_POOLS, 0)
	) as A(compute_pool_id)
cross apply
	sys.fn_polybase_distributed_request_steps_per_pool(A.compute_pool_id) B
go

