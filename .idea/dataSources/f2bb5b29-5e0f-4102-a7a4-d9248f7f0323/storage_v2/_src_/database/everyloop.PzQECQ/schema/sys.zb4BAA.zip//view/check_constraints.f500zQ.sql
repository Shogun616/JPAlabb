CREATE VIEW sys.check_constraints AS
	SELECT name, object_id, principal_id, schema_id, parent_object_id,
		type, type_desc, create_date, modify_date,
		is_ms_shipped, is_published, is_schema_published,
		is_disabled, is_not_for_replication, is_not_trusted,
		property AS parent_column_id,
		object_definition(object_id) AS definition,
		uses_database_collation, is_system_named
	FROM sys.objects$
	WHERE type = 'C '
go

grant select on sys.check_constraints to [public]
go

