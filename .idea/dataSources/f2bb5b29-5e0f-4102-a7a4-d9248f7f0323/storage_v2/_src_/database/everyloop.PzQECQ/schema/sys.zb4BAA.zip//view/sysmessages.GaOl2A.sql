CREATE VIEW sys.sysmessages AS
	SELECT
		message_id AS error,
		severity,
		convert(smallint, is_event_logged * 128) AS dlevel,
		convert(nvarchar(255), text) AS description,
		language_id AS msglangid
	FROM sys.messages
go

