CREATE VIEW sys.dm_os_memory_cache_counters AS
	SELECT *
	FROM OpenRowSet(TABLE SYSMEMORYCACHECOUNTERS)
go

