CREATE VIEW sys.dm_os_process_memory AS
	SELECT *
	FROM OpenRowSet(TABLE DM_OS_PROCESS_MEMORY)
go

