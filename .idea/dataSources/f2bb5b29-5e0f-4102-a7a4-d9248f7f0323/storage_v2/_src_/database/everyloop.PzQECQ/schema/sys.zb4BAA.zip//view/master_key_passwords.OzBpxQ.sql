CREATE VIEW sys.master_key_passwords AS
	SELECT
		co.id AS credential_id,
		convert(uniqueidentifier, 
			stringtovarbinary(convert(varchar(128),
									SUBSTRING ( co.name, 
												charindex('_', co.name) + 1,
												charindex('_', co.name, charindex('_', co.name) + 1) - charindex('_', co.name) - 1)
			   )			   )		 ) AS family_guid
	FROM master.sys.sysclsobjs co
	LEFT JOIN master.sys.sysobjvalues ov ON ov.valclass = 28 AND ov.objid = co.id AND ov.subobjid = 0 AND ov.valnum = 1
	WHERE co.class = 57
		AND has_access('CR', 0) = 1 AND co.name LIKE '##DBMKEY_%'
go

