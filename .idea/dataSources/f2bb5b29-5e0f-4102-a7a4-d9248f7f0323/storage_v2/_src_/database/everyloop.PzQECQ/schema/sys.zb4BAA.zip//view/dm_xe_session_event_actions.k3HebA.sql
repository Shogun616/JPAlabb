CREATE VIEW sys.dm_xe_session_event_actions AS
	SELECT *
	FROM OpenRowset(TABLE DM_XE_SESSION_EVENT_ACTIONS, 0)
go

