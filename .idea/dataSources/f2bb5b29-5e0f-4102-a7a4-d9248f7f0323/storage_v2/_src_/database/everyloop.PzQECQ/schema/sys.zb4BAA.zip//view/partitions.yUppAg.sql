CREATE VIEW sys.partitions AS
	WITH partitions_columnstore(partition_id, object_id, index_id, partition_number, hobt_id, 
					rows, status, filestream_filegroup_id, data_compression, data_compression_desc)
	AS
	(
	SELECT
		rs.rowsetid AS partition_id,
		rs.idmajor AS object_id, -- The following 3 columns form a unique
		rs.idminor AS index_id,  -- Composite ID for a partition.
		rs.numpart AS partition_number, -- This is the third column
		rs.rowsetid AS hobt_id,
		-- To get the rows, we first check if ALUCOUNT has any rows related to the partition.
		-- ALUCOUNT is a tvf that fetches the row count for a partition.
		-- sysrowsets does not maintain the row count all the time for columnstore 
		-- e.g. when the tuple mover compresses row groups.
		-- So use ALUCOUNT to get the row count.
		isnull(ct.rows, rs.rcrows) as rows,
		rs.status as status,
		rs.fgidfs as filestream_filegroup_id,
		cmprlevel AS data_compression,
		cl.name AS data_compression_desc
	FROM sys.sysrowsets rs OUTER APPLY OpenRowset(TABLE ALUCOUNT, rs.rowsetid, 0, 0, 0) ct
		LEFT JOIN sys.syspalvalues cl ON cl.class = 'CMPL' AND cl.value = cmprlevel
		WHERE rs.ownertype = 1 and sysconv(bit, rs.status & 0x00010000) = 1 -- Consider only columnstore base indexes
	),
	partitions_rowstore(partition_id, object_id, index_id, partition_number, hobt_id, 
				rows, status, filestream_filegroup_id, data_compression, data_compression_desc)
	AS
	(
	SELECT
		rs.rowsetid AS partition_id,
		rs.idmajor AS object_id, -- The following 3 columns form a unique
		rs.idminor AS index_id,  -- Composite ID for a partition.
		rs.numpart AS partition_number, -- This is the third column
		rs.rowsetid AS hobt_id,
		rs.rcrows as rows,
		rs.status as status,
		rs.fgidfs as filestream_filegroup_id,
		cmprlevel AS data_compression,
		cl.name AS data_compression_desc
	FROM sys.sysrowsets rs 
		LEFT JOIN sys.syspalvalues cl ON cl.class = 'CMPL' AND cl.value = cmprlevel
		WHERE rs.ownertype = 1 and sysconv(bit, rs.status & 0x00010000) = 0 -- Ignore columnstore base indexes and orphaned rows.
	)
	
	-- Result is a union of rowstore and columnstore partitions.
	
	-- Get rowstore partitions
	SELECT 
		partition_id,
		object_id,
		index_id,
		partition_number,
		hobt_id,
		isnull(ct.rows, p.rows) AS rows,
		filestream_filegroup_id,
		data_compression,
		data_compression_desc	
		from partitions_rowstore p OUTER APPLY OpenRowset(TABLE ALUCOUNT, p.partition_id, 0, 0, p.object_id) ct
	
	union all
	
	-- For columnstore the total rows in a partition is sum of the rows in 
	-- compressed row groups, deltastores, minus the rows in delete buffer and delete bitmap.
	-- P1 below gives the columnstore base index
	-- P2 gives the rows in delete bitmaps, delta stores and delete buffers
	-- 
	-- NOTE: While calculating rows, even though we use a LEFT JOIN we do NOT expect
	-- P2.rows to be NULL. This is because there will at least be a delete bitmap present which
	-- returns 0 for P2.rows. Hence the check isnull(P2.rows, 0) is not required.
	-- And by using LEFT JOIN we can SEEK on partition_id that offers better performance.
	SELECT 
		P1.partition_id,
		P1.object_id,
		P1.index_id,
		P1.partition_number,
		P1.hobt_id,
		(P1.rows + P2.rows) AS rows,
		P1.filestream_filegroup_id,
		P1.data_compression,
		P1.data_compression_desc
	FROM 
		partitions_columnstore as P1
	LEFT JOIN 
		(SELECT 
			rs.idmajor AS object_id,
			rs.idminor AS index_id,
			rs.numpart AS partition_number,
			SUM(CASE -- ownertype 2 corresponds to delete bitmaps and 4 to delete buffers
					WHEN ownertype IN (2, 4) THEN -isnull(ct.rows, rs.rcrows) -- Flip sign of delete bitmaps and delete buffers
					ELSE isnull(ct.rows, rs.rcrows) -- delta stores are ownertype 3 and included here.
				END)
				AS rows
		FROM sys.sysrowsets rs OUTER APPLY OpenRowset(TABLE ALUCOUNT, rs.rowsetid, 0, 0, 0) ct
		WHERE ownertype IN (2, 3, 4) -- delete bitmaps, delta stores and delete buffers
		GROUP BY rs.idmajor, rs.idminor, rs.numpart) as P2 
		
	ON P1.object_id = P2.object_id and P1.index_id = P2.index_id and P1.partition_number = P2.partition_number
go

grant select on sys.partitions to [public]
go

