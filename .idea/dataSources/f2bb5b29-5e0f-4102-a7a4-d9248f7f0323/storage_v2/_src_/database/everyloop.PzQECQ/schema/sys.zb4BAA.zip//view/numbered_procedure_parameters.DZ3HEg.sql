CREATE VIEW sys.numbered_procedure_parameters AS
	SELECT object_id, procedure_number = number,
		name, parameter_id,
		system_type_id, user_type_id,
		max_length, precision,
		scale, is_output, is_cursor_ref
	FROM sys.parameters$
	WHERE number > 1
go

grant select on sys.numbered_procedure_parameters to [public]
go

