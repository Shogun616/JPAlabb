CREATE VIEW sys.key_encryptions AS
	SELECT s.id AS key_id,
		case when (k.type = 'ESKP' OR k.type = 'ESP2' OR k.type = 'ESP3') then NULL else k.thumbprint end as thumbprint,
		k.type AS crypt_type,
		ct.name AS crypt_type_desc,
		(case when has_access('OE', s.id) = 1 then k.crypto else NULL end) AS crypt_property
	FROM sys.sysclsobjs s
	JOIN sys.sysobjkeycrypts k ON k.class = 24 AND k.id = s.id
	LEFT JOIN sys.syspalnames ct ON ct.class = 'CRTY' AND ct.value = k.type
	WHERE s.class = 56
		AND has_access('OK', s.id) = 1
go

grant select on sys.key_encryptions to [public]
go

