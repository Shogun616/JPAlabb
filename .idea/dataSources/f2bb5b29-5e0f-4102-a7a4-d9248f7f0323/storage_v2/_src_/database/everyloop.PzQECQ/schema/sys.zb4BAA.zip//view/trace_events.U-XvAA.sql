create view sys.trace_events as select * from OpenRowset(TABLE SYSTRACEEVENTS)
go

