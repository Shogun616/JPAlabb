
CREATE VIEW sys.dm_db_column_store_row_group_physical_stats AS

	SELECT rg.parent_object_id as [object_id],
		rg.parent_index_id as [index_id],
		rg.parent_part_number as [partition_number],
		rg.[row_group_id],
		rg.[delta_store_hobt_id],
		rg.[state],
		sdstate.[name] as state_desc,
		rg.[total_rows],
		rg.[deleted_rows],
		rg.[size_in_bytes],
		rg.[trim_reason],
		sdtrim.[name] as trim_reason_desc,
		rg.[transition_reason] as transition_to_compressed_state,
		sdtransition.[name] as transition_to_compressed_state_desc,
		rg.[has_vertipaq_optimization],
		rg.[generation],
		rg.[created_time],
		rg.[closed_time]
	FROM
	(sys.syspalvalues sdstate
	INNER hash JOIN
	(sys.syspalvalues sdtrim
	right OUTER hash JOIN
	(sys.syspalvalues sdtransition
	right OUTER hash JOIN
	-- First parameter determines which table to open
	-- Second parameter determines the object id passed in
	-- Third parameter determines which view to show,
	-- 1 is to show dm_db_column_store_row_group_physical_stats
	-- 0 is to show fn_column_store_row_groups or column_store_row_groups
	OpenRowset(TABLE COLUMNSTORE_ROW_GROUPS, 0, 1) rg
		ON (sdtransition.class = 'RGTR' AND sdtransition.value = rg.transition_reason))
		ON (sdtrim.class = 'RGCR' AND sdtrim.value = rg.trim_reason))
		ON (sdstate.class = 'CSRG' AND sdstate.value = rg.state))
	WHERE has_access('CO', rg.parent_object_id) = 1;
go

grant select on sys.dm_db_column_store_row_group_physical_stats to [public]
go

