create view sys.trace_event_bindings as select * from OpenRowset(TABLE SYSTRACEEVENTBINDINGS)
go

