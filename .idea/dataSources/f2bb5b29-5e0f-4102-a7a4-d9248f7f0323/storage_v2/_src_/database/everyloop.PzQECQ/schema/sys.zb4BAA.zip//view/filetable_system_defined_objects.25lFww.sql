CREATE VIEW sys.filetable_system_defined_objects AS
	SELECT
		o.id AS object_id,
		o.pid AS parent_object_id
	FROM sys.sysschobjs$ o
	WHERE sysconv(bit, o.status2 & 0x00000001) = 1 -- OBJALL2_SYSTEM_SCHEMA
		AND has_access('CO', o.id) = 1
go

grant select on sys.filetable_system_defined_objects to [public]
go

