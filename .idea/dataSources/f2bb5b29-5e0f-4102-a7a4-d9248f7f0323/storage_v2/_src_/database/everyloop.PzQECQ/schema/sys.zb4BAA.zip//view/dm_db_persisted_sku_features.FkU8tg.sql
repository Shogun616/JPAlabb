CREATE VIEW sys.dm_db_persisted_sku_features AS
	SELECT feature_name, feature_id
	FROM OpenRowset(TABLE persisted_sku_features)
go

