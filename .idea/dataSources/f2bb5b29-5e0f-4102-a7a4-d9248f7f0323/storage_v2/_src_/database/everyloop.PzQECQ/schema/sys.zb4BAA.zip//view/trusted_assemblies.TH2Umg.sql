
CREATE VIEW sys.trusted_assemblies AS
	SELECT *
	FROM OpenRowSet(TABLE TRUSTED_ASSEMBLIES)
go

