CREATE VIEW sys.column_store_segments
AS
	SELECT s.hobt_id as partition_id,
		s.hobt_id,
		c.rscolid as column_id,
		s.segment_id,
		s.version,
		s.encoding_type,
		s.row_count,
		(case when has_perms_by_name(OBJECT_SCHEMA_NAME(p.idmajor) + '.' + OBJECT_NAME(p.idmajor), 'OBJECT', 'SELECT') = 1 then sysconv(bit, s.status & 1) else NULL end) as has_nulls,
		(case when has_perms_by_name(OBJECT_SCHEMA_NAME(p.idmajor) + '.' + OBJECT_NAME(p.idmajor), 'OBJECT', 'SELECT') = 1 then s.base_id else NULL end) as base_id,
		(case when has_perms_by_name(OBJECT_SCHEMA_NAME(p.idmajor) + '.' + OBJECT_NAME(p.idmajor), 'OBJECT', 'SELECT') = 1 then s.magnitude else NULL end) as magnitude,
		s.primary_dictionary_id,
		s.secondary_dictionary_id,
		(case when has_perms_by_name(OBJECT_SCHEMA_NAME(p.idmajor) + '.' + OBJECT_NAME(p.idmajor), 'OBJECT', 'SELECT') = 1 then s.min_data_id else NULL end) as min_data_id,
		(case when has_perms_by_name(OBJECT_SCHEMA_NAME(p.idmajor) + '.' + OBJECT_NAME(p.idmajor), 'OBJECT', 'SELECT') = 1 then s.max_data_id else NULL end) as max_data_id,
		(case when has_perms_by_name(OBJECT_SCHEMA_NAME(p.idmajor) + '.' + OBJECT_NAME(p.idmajor), 'OBJECT', 'SELECT') = 1 then s.null_value else NULL end) as null_value,
		s.on_disk_size
	FROM sys.syscscolsegments s
	INNER JOIN sys.sysrowsets p ON s.hobt_id = p.rowsetid
	INNER JOIN sys.sysrscols c ON s.hobt_id = c.rsid and s.column_id = c.hbcolid
	WHERE has_access('CO', p.idmajor) = 1	
	
	UNION ALL
	
	SELECT sg.partition_id,
		sg.hobt_id,
		sg.column_id,
		sg.segment_id,
		sg.version,
		sg.encoding_type,
		sg.row_count,
		(case when has_perms_by_name(OBJECT_SCHEMA_NAME(sg.object_id) + '.' + OBJECT_NAME(sg.object_id), 'OBJECT', 'SELECT') = 1 then sg.has_nulls else NULL end) as has_nulls,
		(case when has_perms_by_name(OBJECT_SCHEMA_NAME(sg.object_id) + '.' + OBJECT_NAME(sg.object_id), 'OBJECT', 'SELECT') = 1 then sg.base_id else NULL end) as base_id,
		(case when has_perms_by_name(OBJECT_SCHEMA_NAME(sg.object_id) + '.' + OBJECT_NAME(sg.object_id), 'OBJECT', 'SELECT') = 1 then sg.magnitude else NULL end) as magnitude,
		sg.primary_dictionary_id,
		sg.secondary_dictionary_id,
		(case when has_perms_by_name(OBJECT_SCHEMA_NAME(sg.object_id) + '.' + OBJECT_NAME(sg.object_id), 'OBJECT', 'SELECT') = 1 then sg.min_data_id else NULL end) as min_data_id,
		(case when has_perms_by_name(OBJECT_SCHEMA_NAME(sg.object_id) + '.' + OBJECT_NAME(sg.object_id), 'OBJECT', 'SELECT') = 1 then sg.max_data_id else NULL end) as max_data_id,
		(case when has_perms_by_name(OBJECT_SCHEMA_NAME(sg.object_id) + '.' + OBJECT_NAME(sg.object_id), 'OBJECT', 'SELECT') = 1 then sg.null_value else NULL end) as null_value,				
		sg.on_disk_size
	FROM OpenRowset(TABLE HKCS_SEGMENTS) sg
	WHERE has_access('CO', sg.object_id) = 1
go

grant select on sys.column_store_segments to [public]
go

