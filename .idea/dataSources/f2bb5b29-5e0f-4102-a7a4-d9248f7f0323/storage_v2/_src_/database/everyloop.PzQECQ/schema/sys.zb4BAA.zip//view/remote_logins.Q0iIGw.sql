CREATE VIEW sys.remote_logins AS
	SELECT srvid AS server_id,
		name AS remote_name,
		lgnid AS local_principal_id,
		modate AS modify_date
	FROM master.sys.sysrmtlgns
	WHERE lgnid = suser_id() OR has_access('SR', 0) = 1
go

