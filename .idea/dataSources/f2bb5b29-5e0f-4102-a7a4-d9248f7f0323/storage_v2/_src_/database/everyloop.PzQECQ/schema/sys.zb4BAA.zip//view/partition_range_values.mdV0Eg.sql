CREATE VIEW sys.partition_range_values AS
	SELECT objid AS function_id,
		subobjid AS boundary_id,
		valnum AS parameter_id,
		value AS value
	FROM sys.sysobjvalues
	WHERE valclass = 30
go

grant select on sys.partition_range_values to [public]
go

