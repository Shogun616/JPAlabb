create view sys.dm_os_cluster_properties
as
	select *
	from OpenRowset(TABLE FCI_CONFIGS)
go

