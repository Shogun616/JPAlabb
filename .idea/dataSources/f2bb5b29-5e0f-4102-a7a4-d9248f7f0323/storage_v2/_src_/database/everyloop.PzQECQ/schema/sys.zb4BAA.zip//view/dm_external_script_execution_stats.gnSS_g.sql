CREATE VIEW sys.dm_external_script_execution_stats AS
 	SELECT
		[language] =
			CAST (CASE script_type
				WHEN 0 THEN 'Test'
				WHEN 1 THEN 'R'
				WHEN 2 THEN 'Python'
				ELSE 'Not Supported'
			END as nvarchar(128)),
		counter_name,
		counter_value
	FROM OpenRowSet(TABLE DM_EXTSCRIPT_EXEC_STATS)
go

