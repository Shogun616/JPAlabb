CREATE VIEW sys.dm_resource_governor_external_resource_pool_affinity AS
	SELECT *
	FROM OpenRowSet(TABLE DM_RG_EXTPOOL_AFFINITY)
go

