CREATE VIEW sys.spatial_indexes AS
	SELECT i.id AS object_id,
		i.name AS name,
		i.indid AS index_id,
		i.type,
		n.name AS type_desc,
		sysconv(bit, i.status & 0x8) AS is_unique,			-- IS_IND_UNIQUE
		isnull(ds.indepid, 1) AS data_space_id,
		sysconv(bit, i.status & 0x4) AS ignore_dup_key,		-- IS_IND_DPKEYS
		sysconv(bit, i.status & 0x20) AS is_primary_key,		-- IS_IND_PRIMARY
		sysconv(bit, i.status & 0x40) AS is_unique_constraint,	-- IS_IND_UNIQUE_CO
		i.fillfact AS fill_factor,
		sysconv(bit, i.status & 0x10) AS is_padded,				-- IS_IND_PADINDEX
		sysconv(bit, i.status & 0x80) AS is_disabled,			-- IS_IND_OFFLINE
		sysconv(bit, i.status & 0x100) AS is_hypothetical,		-- IS_IND_ITWINDEX
		sysconv(bit, i.status & 0x02000000) AS is_ignored_in_optimization,	-- IS_IND_IGNORE_IN_OPTIMIZATION
		sysconv(bit, 1 - (i.status & 512)/512) AS allow_row_locks,		-- IS_IND_NO_ROWLOCK
		sysconv(bit, 1 - (i.status & 1024)/1024) AS allow_page_locks,	-- IS_IND_NO_PAGELOCK
		i.intprop AS spatial_index_type,
		ei.name AS spatial_index_type_desc,
		tes.name AS tessellation_scheme,
		sysconv(bit, 0) AS has_filter,
		convert(nvarchar(max), NULL) AS filter_definition,
		sysconv(bit, i.status & 0x08000000) AS auto_created	-- IS_IND_AUTO_CREATED
	FROM sys.sysidxstats i
	LEFT JOIN sys.syssingleobjrefs ds ON ds.depid = i.id AND ds.class = 7 AND ds.depsubid = i.indid	-- SRC_INDEXTODS	
	LEFT JOIN sys.syspalvalues n ON n.class = 'IDXT' and n.value = i.type
	LEFT JOIN sys.syspalvalues ei ON ei.class = 'EITP' and ei.value = i.intprop
	LEFT JOIN sys.syspalvalues tes ON tes.class = 'EISP' and tes.value = i.intprop
	WHERE i.indid >= 384000 and i.indid < 512000 --indid greater and equal than x_MDIndexStatsId_MinExtended(384000) and less than x_MDIndexStatsId_MinTemp(512000)
		AND has_access('CO', i.id) = 1
go

grant select on sys.spatial_indexes to [public]
go

