
CREATE VIEW sys.dm_exec_sessions AS
	SELECT
		session_id, login_time, host_name, program_name, host_process_id,
		client_version, client_interface_name, security_id, login_name, nt_domain,
		nt_user_name, status, context_info, cpu_time, memory_usage, total_scheduled_time,
		total_elapsed_time, endpoint_id, last_request_start_time, last_request_end_time,
		reads, writes, logical_reads, is_user_process, text_size, language, date_format,
		date_first, quoted_identifier, arithabort, ansi_null_dflt_on, ansi_defaults,
		ansi_warnings, ansi_padding, ansi_nulls, concat_null_yields_null, transaction_isolation_level,
		lock_timeout, deadlock_priority, row_count, prev_error, original_security_id, original_login_name,
		last_successful_logon, last_unsuccessful_logon, unsuccessful_logons, group_id, database_id,
		authenticating_database_id, open_transaction_count,
		page_server_reads
	FROM OpenRowset(TABLE SYSSESSIONS)
go

