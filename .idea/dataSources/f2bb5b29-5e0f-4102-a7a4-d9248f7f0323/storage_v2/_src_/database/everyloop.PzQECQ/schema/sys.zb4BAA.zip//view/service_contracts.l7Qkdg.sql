CREATE VIEW sys.service_contracts AS
	SELECT name,
		service_contract_id,
		principal_id
	FROM sys.service_contracts$
	WHERE has_access('SC', service_contract_id) = 1
go

grant select on sys.service_contracts to [public]
go

