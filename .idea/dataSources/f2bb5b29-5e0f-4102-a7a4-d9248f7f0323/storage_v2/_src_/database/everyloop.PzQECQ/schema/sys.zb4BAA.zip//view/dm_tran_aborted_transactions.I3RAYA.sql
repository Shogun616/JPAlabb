CREATE VIEW sys.dm_tran_aborted_transactions AS
	SELECT *
	FROM OpenRowset(TABLE ABORTED_TRANSACTIONS)
go

