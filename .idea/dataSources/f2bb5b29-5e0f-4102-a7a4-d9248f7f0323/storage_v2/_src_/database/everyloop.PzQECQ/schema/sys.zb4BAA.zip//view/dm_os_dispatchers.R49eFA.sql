CREATE VIEW sys.dm_os_dispatchers AS
	SELECT *
	FROM OpenRowSet(TABLE DM_OS_DISPATCHERS)
go

