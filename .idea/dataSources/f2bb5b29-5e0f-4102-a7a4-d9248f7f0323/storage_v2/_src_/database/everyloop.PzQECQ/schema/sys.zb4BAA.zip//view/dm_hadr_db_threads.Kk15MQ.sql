CREATE VIEW sys.dm_hadr_db_threads AS
	SELECT group_id,
		ag_db_id,
		name,
		num_capture_threads,
		num_redo_threads,
		num_parallel_redo_threads
	FROM OpenRowset(TABLE DM_HADR_DB_THREADS)
go

