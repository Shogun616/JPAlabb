CREATE VIEW sys.sysindexes AS
	SELECT i.id,
		status = convert(int,
			case i.indid when 1 then 16 else 0 end	-- (is_clustered * 16)
			+ (i.status & 8)/4		-- IS_IND_UNIQUE (is_unique * 2)
			+ (i.status & 4)/4		-- IS_IND_DPKEYS (ignore_dup_key * 1)
			+ (i.status & 32)*64	-- IS_IND_PRIMARY (is_primary_key * 2048)
			+ (i.status & 64)*64	-- IS_IND_UNIQUE_CO (is_unique_constraint * 4096)
			+ (i.status & 16)*16	-- IS_IND_PADINDEX (is_padded * 256)
			+ (i.status & 256)/8		-- IS_IND_ITWINDEX (is_hypothetical * 32)
			+ (1-(i.status & 1))*64	-- IS_INDEX
			+ (i.status & 8192)*1024	-- IS_STATS_AUTO_CRT (auto_created * 0x800000)
			+ (i.status & 16384)*1024),	-- IS_STATS_NORECOMP (no_recompute * 0x1000000)
		first = case when i.rowset > 0 then p.first end,
		indid = convert(smallint, i.indid),
		root = case when i.rowset > 0 then p.root end,
		minlen = convert(smallint, case when i.status & 1 = 0 then 0 else indexproperty(i.id, i.name, 'minlen') end),
		keycnt = convert(smallint, indexproperty(i.id, i.name, 'keycnt80')),
		groupid = convert(smallint, case
			when (i.status & 1) = 0 then 0
			when (i.status & 256) <> 0 then 0
			when d.indepid is null then 1
			when d.indepid < 32768 then d.indepid end),
		dpages = convert(int, case when i.status & 1 = 0 then 0 else p.data_pages end),
		reserved = convert(int, case when i.status & 1 = 0 then 0 else p.total_pages end),
		used = convert(int, case when i.status & 1 = 0 then 0 else p.used_pages end),
		rowcnt = convert(bigint, case when i.status & 1 = 0 then 0 else p.rows end),
		rowmodctr = convert(int, indexproperty(i.id, i.name, 'rowmodcnt80')),
		reserved3 = convert(tinyint, 0),
		reserved4 = convert(tinyint, 0),
		xmaxlen = convert(smallint, case when i.status & 1 = 0 then 0 else indexproperty(i.id, i.name, 'maxlen') end),
		p.maxirow,
		OrigFillFactor = convert(tinyint, (i.status & 1)*fillfact),	-- fill_factor
		StatVersion = convert(tinyint, 0),
		reserved2 = convert(int, 0),
		FirstIAM = case when i.rowset > 0 then p.FirstIAM end,
		impid = convert(smallint, 0),
		lockflags = convert(smallint, (i.status & 512)/512 + (i.status & 1024)/512),	-- no_row_locks + no_page_locks*2
		pgmodctr = convert(int, 0),
		keys = convert(varbinary(1088), null),
		name = i.name,
		statblob = convert (image, null),
		maxlen = convert(int, 8000),
		rows = convert(int,  case when i.status & 1 = 0 then 0 else 0x7FFFFFFF & p.rows end)
	FROM sys.sysidxstats i OUTER APPLY OpenRowset(TABLE INDEXPROP, i.id, i.indid, i.rowset) p
	LEFT JOIN sys.syssingleobjrefs d ON d.depid = i.id AND d.class = 7 AND d.depsubid = i.indid	-- SRC_INDEXTODS	
	INNER JOIN sys.sysschobjs$ obj ON obj.id = i.id
	WHERE i.indid < 256000
		AND has_access('CO', i.id) = 1
		AND obj.status2 & 0x00000008 = 0		-- OBJTAB2_HEKATON
		AND (i.status & 0x04000000) = 0			-- !IS_IND_RESUMABLE
go

grant select on sys.sysindexes to [public]
go

