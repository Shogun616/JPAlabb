CREATE view sys.dm_fts_memory_buffers
AS
	SELECT * FROM OpenRowset(TABLE FTMEMBUFFERS)
go

