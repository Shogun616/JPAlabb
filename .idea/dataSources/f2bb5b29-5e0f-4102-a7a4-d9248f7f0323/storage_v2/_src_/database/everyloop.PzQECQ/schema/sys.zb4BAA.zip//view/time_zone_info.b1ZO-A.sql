CREATE VIEW sys.time_zone_info AS
	SELECT 	name,
			current_utc_offset,
			is_currently_dst
	FROM OPENROWSET(TABLE TIME_ZONE_INFO, SYSUTCDATETIME())
go

grant select on sys.time_zone_info to [public]
go

