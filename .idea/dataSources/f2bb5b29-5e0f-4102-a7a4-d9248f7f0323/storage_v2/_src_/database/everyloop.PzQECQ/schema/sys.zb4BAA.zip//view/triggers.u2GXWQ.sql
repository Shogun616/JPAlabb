CREATE VIEW sys.triggers AS
	SELECT o.name,
		object_id = o.id,
		parent_class = o.pclass,
		parent_class_desc = pc.name,
		parent_id = o.pid,
		type = o.type,
		type_desc = n.name,
		create_date = o.created,
		modify_date = o.modified,
		is_ms_shipped = sysconv(bit, o.status & 1), 		-- OBJALL_MSSHIPPED
		is_disabled = sysconv(bit, o.status & 256), 		-- OBJTRG_DISABLED
		is_not_for_replication = sysconv(bit, o.status & 512), 	-- OBJTRG_NOTFORREPL
		is_instead_of_trigger = sysconv(bit, o.status & 1024) 	-- OBJTRG_INSTEADOF
	FROM sys.sysschobjs$ o
	LEFT JOIN sys.syspalnames n ON n.class = 'OBTY' AND n.value = o.type
	LEFT JOIN sys.syspalvalues pc ON pc.class = 'UNCL' AND pc.value = o.pclass
	WHERE o.type IN ('TA','TR') AND o.pclass <> 100 -- x_eunc_Server
		AND has_access('TR', o.id, o.pid, o.nsclass) = 1
go

grant select on sys.triggers to [public]
go

