CREATE VIEW sys.system_components_surface_area_configuration AS
	SELECT s.component_name, s.database_name, s.schema_name,
		s.object_name, s.state, s.type, p.name AS type_desc
	FROM sys.sac_state s
	LEFT JOIN sys.syspalnames p ON p.class = 'OBTY' AND p.value = s.type
go

