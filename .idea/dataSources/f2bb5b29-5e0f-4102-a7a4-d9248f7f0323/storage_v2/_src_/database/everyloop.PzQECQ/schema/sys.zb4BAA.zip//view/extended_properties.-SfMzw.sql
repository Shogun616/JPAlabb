CREATE VIEW sys.extended_properties AS
	SELECT p.class,
		class_desc = n.name,
		major_id = p.id,
		minor_id = p.subid,
		p.name, p.value
	FROM sys.sysxprops p
	LEFT JOIN sys.syspalvalues n ON n.class = 'UNCL' AND n.value = p.class
	WHERE has_access('EP', p.class, p.id) = 1
go

grant select on sys.extended_properties to [public]
go

