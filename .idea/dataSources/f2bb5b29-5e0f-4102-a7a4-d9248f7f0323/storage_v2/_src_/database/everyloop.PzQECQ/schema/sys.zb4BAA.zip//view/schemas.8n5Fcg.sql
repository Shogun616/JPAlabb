CREATE VIEW sys.schemas AS
	SELECT s.name, schema_id = s.id,
		principal_id = r.indepid
	FROM sys.sysclsobjs s
	LEFT JOIN sys.syssingleobjrefs r ON r.depid = s.id AND r.class = 50 AND r.depsubid = 0 -- SRC_SCHEMAOWNER
	WHERE s.class = 50	-- SOC_SCHEMA
go

grant select on sys.schemas to [public]
go

