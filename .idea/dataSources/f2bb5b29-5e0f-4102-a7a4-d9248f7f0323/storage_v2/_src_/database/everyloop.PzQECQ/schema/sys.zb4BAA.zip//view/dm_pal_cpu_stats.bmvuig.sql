CREATE VIEW sys.dm_pal_cpu_stats AS
	SELECT *
	FROM OpenRowset(TABLE DM_PAL_CPU_STATS)
go

