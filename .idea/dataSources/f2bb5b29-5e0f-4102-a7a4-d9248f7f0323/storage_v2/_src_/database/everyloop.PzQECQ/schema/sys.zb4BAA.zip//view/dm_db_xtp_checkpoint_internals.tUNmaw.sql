
CREATE VIEW sys.dm_db_xtp_checkpoint_internals
AS
	SELECT
	*
	FROM OpenRowset(TABLE XTP_CHECKPOINTS)
go

