CREATE VIEW sys.dm_tran_session_transactions AS
	SELECT 
		session_id,
		transaction_id,
		transaction_descriptor,
		enlist_count,
		is_user_transaction,
		is_local,
		is_enlisted,
		is_bound,
		open_transaction_count
	FROM OpenRowset(TABLE dm_tran_session_transactions)
go

