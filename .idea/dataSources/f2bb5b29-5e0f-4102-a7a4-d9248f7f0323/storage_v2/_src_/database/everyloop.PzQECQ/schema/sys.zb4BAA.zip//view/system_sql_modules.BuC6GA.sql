CREATE VIEW sys.system_sql_modules AS
	SELECT o.object_id,
		definition = object_definition(o.object_id),
		uses_ansi_nulls = sysconv(bit, 1),
		uses_quoted_identifier = sysconv(bit, 1),
		is_schema_bound = sysconv(bit, 0),
		uses_database_collation = sysconv(bit, 0),
		is_recompiled = sysconv(bit, 0),
		null_on_null_input = sysconv(bit, 0),
		execute_as_principal_id = convert(int, NULL),
		uses_native_compilation = sysconv(bit, 0),
		inline_type = sysconv(bit, 0),
		is_inlineable = sysconv(bit, 0)
	FROM sys.system_objects o
	WHERE o.type IN ('P','V','FN','IF','TF','RF','IS')
go

grant select on sys.system_sql_modules to [public]
go

