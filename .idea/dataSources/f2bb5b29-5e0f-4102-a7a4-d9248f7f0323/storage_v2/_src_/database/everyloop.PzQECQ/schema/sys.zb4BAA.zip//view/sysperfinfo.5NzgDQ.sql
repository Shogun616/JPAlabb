CREATE VIEW sys.sysperfinfo AS
	SELECT * from sys.dm_os_performance_counters
go

