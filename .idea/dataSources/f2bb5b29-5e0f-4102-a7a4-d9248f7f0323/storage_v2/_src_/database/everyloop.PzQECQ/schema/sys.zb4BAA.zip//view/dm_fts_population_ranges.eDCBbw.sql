CREATE view sys.dm_fts_population_ranges
AS
	SELECT * FROM OpenRowset(TABLE FTCRAWLRANGES)
go

