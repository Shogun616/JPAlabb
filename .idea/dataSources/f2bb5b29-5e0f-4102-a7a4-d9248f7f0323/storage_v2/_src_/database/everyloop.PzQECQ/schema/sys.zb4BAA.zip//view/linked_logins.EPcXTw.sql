CREATE VIEW	sys.linked_logins AS
	SELECT srvid AS server_id,
		lgnid AS local_principal_id,
		sysconv(bit, status & 1) AS uses_self_credential,	-- LGN_LINKED_USESELF
		name AS remote_name,
		modate AS modify_date
	FROM master.sys.syslnklgns
	WHERE lgnid = suser_id() OR has_access('SR', 0) = 1
go

