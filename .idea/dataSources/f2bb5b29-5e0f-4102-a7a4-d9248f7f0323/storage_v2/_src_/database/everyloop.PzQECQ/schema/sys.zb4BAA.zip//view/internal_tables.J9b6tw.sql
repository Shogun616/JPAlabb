CREATE VIEW sys.internal_tables AS
	SELECT o.name, o.id AS object_id, convert(int, null) AS principal_id, o.nsid AS schema_id, o.pid AS parent_object_id,
		o.type, n.name AS type_desc, o.created AS create_date, o.modified AS modify_date,
		convert(bit, 0) AS is_ms_shipped, convert(bit, 0) AS is_published, convert(bit, 0) AS is_schema_published,
		convert(tinyint, par.depsubid) AS internal_type,
		itt.name AS internal_type_desc,
		par.indepid AS parent_id,
		par.indepsubid AS parent_minor_id,
		isnull(ds.indepid, 0) AS lob_data_space_id,
		rfs.indepid AS filestream_data_space_id
	FROM sys.sysschobjs$ o
	LEFT JOIN sys.syspalnames n ON n.class = 'OBTY' AND n.value = o.type
	LEFT JOIN sys.syssingleobjrefs par ON par.depid = o.id AND par.class = 40	 -- SRC_INTLTAB_PARENT
	LEFT JOIN sys.syspalvalues itt ON itt.class = 'ITTY' AND itt.value = par.depsubid
	LEFT JOIN sys.syssingleobjrefs ds ON ds.depid = o.id AND ds.class = 8 AND ds.depsubid <= 1	-- SRC_INDEXTOLOBDS	
	LEFT JOIN sys.syssingleobjrefs rfs ON rfs.depid = o.id AND rfs.class = 42 AND rfs.depsubid = 0	-- SRC_OBJTOFSDS
	WHERE o.nsclass = 0 -- x_eonc_Standard
		AND o.nsid = 4 AND o.pclass = 1 AND o.type = 'IT' -- x_eunc_Object
		AND has_access('IT', par.indepid, par.depsubid) = 1
go

grant select on sys.internal_tables to [public]
go

