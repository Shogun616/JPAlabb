CREATE VIEW INFORMATION_SCHEMA.DOMAINS
AS
SELECT
	DB_NAME()					AS DOMAIN_CATALOG,
	SCHEMA_NAME(schema_id)		AS DOMAIN_SCHEMA,
	name						AS DOMAIN_NAME,
	TYPE_NAME(system_type_id) 	AS DATA_TYPE,
	convert(int, TypePropertyEx(user_type_id, 'charmaxlen'))	AS CHARACTER_MAXIMUM_LENGTH,
	convert(int, TypePropertyEx(user_type_id, 'octetmaxlen'))	AS CHARACTER_OCTET_LENGTH,
	convert(sysname, null)			AS COLLATION_CATALOG,
	convert(sysname, null) collate catalog_default		AS COLLATION_SCHEMA,
	collation_name				AS COLLATION_NAME,
	convert(sysname, null)			AS CHARACTER_SET_CATALOG,
	convert(sysname, null) collate catalog_default		AS CHARACTER_SET_SCHEMA,
	convert(sysname, CASE
		WHEN system_type_id IN (35, 167, 175) THEN SERVERPROPERTY('sqlcharsetname') -- char/varchar/text
		WHEN system_type_id IN (99, 231, 239) THEN N'UNICODE' END) AS CHARACTER_SET_NAME,		-- nchar/nvarchar/ntext
	convert(tinyint, CASE -- int/decimal/numeric/real/float/money
		WHEN system_type_id IN (48, 52, 56, 59, 60, 62, 106, 108, 122, 127) THEN precision
		END)									AS NUMERIC_PRECISION,
	convert(smallint, CASE	-- int/money/decimal/numeric
		WHEN system_type_id IN (48, 52, 56, 60, 106, 108, 122, 127) THEN 10
		WHEN system_type_id IN (59, 62) THEN 2 END)	AS NUMERIC_PRECISION_RADIX,
	convert(int, CASE	-- datetime/smalldatetime
		WHEN system_type_id IN (40, 41, 42, 43, 58, 61) THEN NULL
		ELSE ODBCSCALE(system_type_id, scale) END)	AS NUMERIC_SCALE,
	convert(smallint, CASE -- datetime/smalldatetime
		WHEN system_type_id IN (40, 41, 42, 43, 58, 61) THEN  ODBCSCALE(system_type_id, scale) END)	AS DATETIME_PRECISION,
	convert(nvarchar(4000),
		OBJECT_DEFINITION(default_object_id))			AS DOMAIN_DEFAULT
FROM
	sys.types
WHERE
	user_type_id > 256	-- UDT
go

