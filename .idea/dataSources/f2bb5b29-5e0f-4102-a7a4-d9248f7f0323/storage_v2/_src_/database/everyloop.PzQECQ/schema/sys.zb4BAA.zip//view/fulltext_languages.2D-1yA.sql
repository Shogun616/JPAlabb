CREATE VIEW sys.fulltext_languages AS
	SELECT lcid, name 
	FROM OpenRowSet(TABLE SYSFULLTEXTLANGUAGES)
go

