CREATE VIEW sys.data_spaces AS
	SELECT o.name AS name,
		o.id AS data_space_id,
		o.type AS type,
		c.name AS type_desc,
		sysconv(bit, o.status & 1) AS is_default,
		sysconv(bit, o.status & 0x4) AS is_system
	FROM sys.sysclsobjs o
	LEFT JOIN sys.syspalnames c ON c.class = 'DSTY' AND c.value = o.type
	WHERE o.class = 31
go

grant select on sys.data_spaces to [public]
go

