CREATE VIEW sys.fulltext_semantic_languages AS
	SELECT lcid, name 
	FROM OpenRowSet(TABLE SYSSEMANTICLANGUAGES)
go

