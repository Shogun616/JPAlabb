CREATE VIEW sys.partition_parameters AS
	SELECT idmajor AS function_id,
		subid AS parameter_id,
		xtype AS system_type_id,
		length AS max_length,
		prec AS precision,
		scale AS scale,
		convert(sysname, CollationPropertyFromID(collationid, 'name')) AS collation_name,
		utype AS user_type_id
	FROM sys.systypedsubobjs
	WHERE class = 30
go

grant select on sys.partition_parameters to [public]
go

