CREATE VIEW sys.external_library_setup_errors AS
	SELECT
		db_id 				= librarySetupFailures.db_id,
		principal_id		= librarySetupFailures.principal_id,
		external_library_id = librarySetupFailures.external_library_id,
		error_code			= librarySetupFailures.error_code,
		error_timestamp		= librarySetupFailures.error_timestamp,
		error_message 		= librarySetupFailures.error_message
	FROM master.sys.external_library_setup_failures librarySetupFailures
	WHERE librarySetupFailures.db_id = db_id() and has_access('EL', external_library_id) = 1
go

grant select on sys.external_library_setup_errors to [public]
go

