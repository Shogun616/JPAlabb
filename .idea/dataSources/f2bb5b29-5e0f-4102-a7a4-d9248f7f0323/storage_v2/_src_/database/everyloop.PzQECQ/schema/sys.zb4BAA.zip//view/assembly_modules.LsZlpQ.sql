CREATE VIEW sys.assembly_modules AS
	SELECT object_id = o.id,
		assembly_id = asm.indepid,
		assembly_class = convert(sysname, v.value) collate Latin1_General_BIN,
		assembly_method = convert(sysname, m.value) collate Latin1_General_BIN,
		null_on_null_input = sysconv(bit, o.status & 0x200000),	-- OBJMOD_NULLONNULL
		execute_as_principal_id = x.indepid
	FROM sys.sysschobjs$ o
	JOIN sys.syssingleobjrefs asm ON asm.depid = o.id AND asm.class = 11 AND asm.depsubid = 0 	-- SRC_MODULETOASM
	LEFT JOIN sys.sysobjvalues v ON v.valclass = 11 AND v.objid = o.id AND v.subobjid = 0 AND v.valnum = 1 	-- SVC_OBJASMENTRY,ASMENTRY_CLASS
	LEFT JOIN sys.sysobjvalues m ON m.valclass = 11 AND m.objid = o.id AND m.subobjid = 0 AND m.valnum = 2 	-- SVC_OBJASMENTRY,ASMENTRY_METHOD
	LEFT JOIN sys.syssingleobjrefs x ON x.depid = o.id AND x.class = 22 AND x.depsubid = 0	-- SRC_OBJEXECASOWNER
	WHERE o.pclass <> 100	-- x_eunc_Server
		AND type IN ('AF','PC','FS','FT','TA')
		AND has_access('SQ', o.id, o.pid, o.nsclass) = 1
go

grant select on sys.assembly_modules to [public]
go

