CREATE VIEW sys.sysfulltextcatalogs AS
	SELECT ftcatid = convert(smallint, fulltext_catalog_id),
		name, status = convert(smallint, is_default), path
	FROM sys.fulltext_catalogs
go

grant select on sys.sysfulltextcatalogs to [public]
go

