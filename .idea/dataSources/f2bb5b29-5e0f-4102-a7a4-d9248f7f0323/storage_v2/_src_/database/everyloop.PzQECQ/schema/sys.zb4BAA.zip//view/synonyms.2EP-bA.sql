CREATE VIEW sys.synonyms AS
	SELECT o.name, o.object_id, o.principal_id, o.schema_id, o.parent_object_id,
		o.type, o.type_desc, o.create_date, o.modify_date,
		o.is_ms_shipped, o.is_published, o.is_schema_published,
		base_object_name = convert(nvarchar(1035), v.value) collate catalog_default
	FROM sys.objects$ o
	LEFT JOIN sys.sysobjvalues v ON v.valclass = 4 AND v.objid = o.object_id AND v.subobjid = 0 AND v.valnum = 0	-- SVC_SYNBASEOBJ
	WHERE o.type = 'SN'
go

grant select on sys.synonyms to [public]
go

