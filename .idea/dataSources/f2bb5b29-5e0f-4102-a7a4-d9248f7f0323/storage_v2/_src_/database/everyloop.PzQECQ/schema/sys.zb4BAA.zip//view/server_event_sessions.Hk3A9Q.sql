CREATE VIEW sys.server_event_sessions AS
	SELECT 
		event_session_id			= c.id,
		name						= convert(sysname, c.name) collate catalog_default,
		event_retention_mode		= char(v2.subobjid), -- EMDXEEventRetention
		event_retention_mode_desc	= xeer.name collate catalog_default,
		max_dispatch_latency		= convert(INT, v1.value),
		max_memory					= v1.subobjid,
		max_event_size				= v1.valnum,
		memory_partition_mode		= char(v2.valnum), -- EMDXEMemoryPartition
		memory_partition_mode_desc	= xemp.name collate catalog_default,
		track_causality				= convert(bit, c.status & 1), -- XE_SESSION_STATUS_BIT_CAUSALITY
		startup_state				= convert(bit, c.status & 2),  -- XE_SESSION_STATUS_BIT_AUTOSTART
		has_long_running_target			= convert(bit, c.status & 0x10)  -- XE_SESSION_STATUS_BIT_LONGRUNNINGTARGET
	FROM master.sys.sysclsobjs c
	LEFT JOIN master.sys.sysobjvalues v1 ON
		v1.valclass = 90 AND	-- SVC_XE_SESSION_PROP_1
		v1.objid = c.id
	LEFT JOIN master.sys.sysobjvalues v2 ON
		v2.valclass = 91 AND	-- SVC_XE_SESSION_PROP_2
		v2.objid = c.id
	LEFT JOIN sys.syspalnames xeer ON xeer.class = 'XEER' AND xeer.value = char(v2.subobjid)
	LEFT JOIN sys.syspalnames xemp ON xemp.class = 'XEMP' AND xemp.value = char(v2.valnum)
	WHERE c.class = 62			-- SOC_XESESSION
	AND convert(bit, c.status & 4) = 0 	-- filter out database scoped sessions	
	AND has_access ('ES', 0) = 1
go

