CREATE VIEW sys.dm_os_buffer_pool_extension_configuration AS
	SELECT 
		path, 
		file_id, 
		state, 
		state_description, 
		current_size_in_kb
	FROM OpenRowset(TABLE DM_OS_BPOOLEXTENSION_CONFIG)
go

