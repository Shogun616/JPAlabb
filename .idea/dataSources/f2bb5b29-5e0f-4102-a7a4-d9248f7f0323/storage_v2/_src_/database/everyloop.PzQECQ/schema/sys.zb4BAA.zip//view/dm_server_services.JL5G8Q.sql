CREATE VIEW sys.dm_server_services AS
	SELECT *
	FROM OpenRowset(TABLE DM_SERVER_SERVICES)
go

