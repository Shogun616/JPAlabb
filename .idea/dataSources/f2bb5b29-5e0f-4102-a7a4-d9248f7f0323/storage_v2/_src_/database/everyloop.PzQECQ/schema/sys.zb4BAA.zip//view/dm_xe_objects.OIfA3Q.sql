CREATE VIEW sys.dm_xe_objects AS
	SELECT *
	FROM OpenRowset(TABLE DM_XE_OBJECTS)
go

