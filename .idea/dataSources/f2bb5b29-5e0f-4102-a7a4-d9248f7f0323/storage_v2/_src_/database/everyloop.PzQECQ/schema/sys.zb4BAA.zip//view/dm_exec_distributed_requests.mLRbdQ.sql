
-- add it
create view sys.dm_exec_distributed_requests as
select
	B.sql_handle,
	B.execution_id	collate database_default execution_id,
	B.status			collate database_default status,
	B.error_id,
	B.start_time,
	B.end_time,
	B.total_elapsed_time,
	A.compute_pool_id
from (
	select 0
	union all
	select bdc_pool_id as compute_pool_id
	from OPENROWSET(TABLE DM_EXEC_COMPUTE_POOLS, 0)
	) as A(compute_pool_id)
cross apply
	sys.fn_polybase_distributed_requests_per_pool(A.compute_pool_id) B
go

