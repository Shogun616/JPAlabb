CREATE VIEW sys.dm_hadr_availability_group_states AS
	SELECT
		ags.group_id,
		primary_replica = CAST (ags.primary_replica AS NVARCHAR(128)),
		primary_recovery_health = CASE
			WHEN ags.local_replica_role = 1 THEN ars.recovery_health_aggr
			ELSE NULL END,
		primary_recovery_health_desc = CASE
			WHEN (ags.local_replica_role = 1 AND ars.recovery_health_aggr = 0) THEN CAST ('ONLINE_IN_PROGRESS' AS NVARCHAR(60))
			WHEN (ags.local_replica_role = 1 AND ars.recovery_health_aggr > 0) THEN CAST ('ONLINE' AS NVARCHAR(60))
			ELSE CAST (NULL AS NVARCHAR(60)) END,
		secondary_recovery_health = CASE
			WHEN ags.local_replica_role = 2 THEN ars.recovery_health_aggr
			ELSE NULL END,
		secondary_recovery_health_desc = CASE
			WHEN (ags.local_replica_role = 2 AND ars.recovery_health_aggr = 0) THEN CAST ('ONLINE_IN_PROGRESS' AS NVARCHAR(60))
			WHEN (ags.local_replica_role = 2 AND ars.recovery_health_aggr > 0) THEN CAST ('ONLINE' AS NVARCHAR(60))
			ELSE CAST (NULL AS NVARCHAR(60)) END,
		synchronization_health = CASE
			WHEN ars.synchronization_health_aggr IS NULL THEN CAST (0 AS TINYINT)			-- NOT_HEALTHY
			WHEN (ags.local_replica_role = 1 AND ags.configured_replica_count > ars.replica_count) THEN CAST (0 AS TINYINT)	-- NOT_HEALTHY (one or more replicas/DBs not joined)
			ELSE CAST (ars.synchronization_health_aggr AS TINYINT) END,
		synchronization_health_desc = CASE
			WHEN ars.synchronization_health_aggr IS NULL THEN CAST ('NOT_HEALTHY' AS NVARCHAR(60))
			WHEN (ags.local_replica_role = 1 AND ags.configured_replica_count > ars.replica_count) THEN CAST ('NOT_HEALTHY' AS NVARCHAR(60))
			WHEN ars.synchronization_health_aggr = 2 THEN CAST ('HEALTHY' AS NVARCHAR(60))
			WHEN ars.synchronization_health_aggr = 1 THEN CAST ('PARTIALLY_HEALTHY' AS NVARCHAR(60))
			ELSE CAST ('NOT_HEALTHY' AS NVARCHAR(60)) END
	FROM
		sys.dm_hadr_internal_availability_group_states ags
		LEFT OUTER JOIN
		(
			SELECT
				group_id,
				replica_count = COUNT (*),
				recovery_health_aggr = MAX (recovery_health),
				synchronization_health_aggr = MIN (synchronization_health)
			FROM
				sys.dm_hadr_availability_replica_states
			GROUP BY group_id
		)
		AS ars
		ON ags.group_id = ars.group_id
go

