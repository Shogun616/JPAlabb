CREATE VIEW sys.dm_os_tasks AS
	SELECT *
	FROM OpenRowSet(TABLE SYSTASKS)
go

