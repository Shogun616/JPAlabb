CREATE VIEW sys.syscurconfigs AS
	SELECT value,
		convert(smallint, id) AS config,
		description AS comment,
		convert(smallint, status) AS status
	FROM OpenRowset(TABLE CFGPROP)
go

