
CREATE VIEW sys.external_data_sources AS
	SELECT
		seds.data_source_id AS data_source_id,
		seds.name AS name,
		seds.location AS location,
		UPPER(seds.type_desc) AS type_desc,
		seds.type AS type,
		seds.job_tracker_location AS resource_manager_location,
		seds.credential_id AS credential_id,
		seds.shard_map_manager_db AS database_name,
		seds.shard_map_name AS shard_map_name,
		seds.connection_options AS connection_options,
		seds.pushdown AS pushdown
	FROM sys.sysextsources seds
	WHERE has_access('ED', DB_ID()) = 1 -- catalog security check	
go

grant select on sys.external_data_sources to [public]
go

