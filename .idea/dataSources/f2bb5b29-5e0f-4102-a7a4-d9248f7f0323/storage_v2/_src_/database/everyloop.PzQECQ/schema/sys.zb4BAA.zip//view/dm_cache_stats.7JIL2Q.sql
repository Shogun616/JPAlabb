
CREATE VIEW sys.dm_cache_stats AS
	SELECT 
		CASE WHEN st.distribution_id != NULL 
			THEN st.distribution_id
			ELSE si.distribution_id END AS distribution_id,
		st.cache_hit,
		st.remote_hit,
		st.collection_start_time,
		si.cache_used,
		si.cache_available,
		si.cache_capacity
	FROM
	sys.dm_cache_hit_stats st
	full outer join sys.dm_cache_size si on si.distribution_id = st.distribution_id
go

