CREATE VIEW sys.dm_xe_session_object_columns AS
	SELECT *
	FROM OpenRowset(TABLE DM_XE_SESSION_OBJECT_COLUMNS,0)
go

