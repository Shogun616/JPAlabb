CREATE VIEW sys.fulltext_stopwords AS
	SELECT 
		fts.stoplistid AS stoplist_id,
		fts.stopword,
		ftl.name AS language,
		language_id = fts.lcid
	FROM sys.sysftstops fts
	JOIN sys.fulltext_languages ftl ON fts.lcid = ftl.lcid
	JOIN sys.sysclsobjs sc ON fts.stoplistid = sc.id and sc.class = 33 and has_access ('FS', sc.id) = 1 -- join to filter stoplist according to has_access() 
go

grant select on sys.fulltext_stopwords to [public]
go

