CREATE VIEW sys.external_libraries AS
	SELECT 
		co.id AS external_library_id,
		convert(sysname, ov1.value) collate catalog_default AS name,
		sor.indepid AS principal_id,
		convert(sysname, ov2.value) collate catalog_default AS language,
		CASE sor.indepid
			WHEN 1 THEN 0 -- DBO
			ELSE 1
		END AS scope,
		CASE sor.indepid
			WHEN 1 THEN 'PUBLIC' -- DBO
			ELSE 'PRIVATE'
		END collate Latin1_General_CI_AS_KS_WS AS scope_desc
	FROM
		sys.sysclsobjs co LEFT JOIN
		sys.sysobjvalues ov1 ON
		(
			co.id = ov1.objid AND
			ov1.valclass = 129 AND -- SVC_EXTERNAL_LIBRARY
			ov1.valnum = 1 -- EXTLIB_NAME
		) LEFT JOIN
		sys.sysobjvalues ov2 ON
		(
			co.id = ov2.objid AND
			ov2.valclass = 129 AND -- SVC_EXTERNAL_LIBRARY
			ov2.valnum = 2 -- EXTLIB_RUNTIME
		) LEFT JOIN
		sys.syssingleobjrefs sor ON
		(
			sor.depid = co.id AND sor.class = 122 -- SRC_EXTERNAL_LIBRARY_OWNER
		)
	WHERE
		co.class = 105 AND -- SOC_EXTERNAL_LIBRARY
		has_access('EL', co.id) = 1
go

grant select on sys.external_libraries to [public]
go

