CREATE VIEW sys.stats AS
	SELECT id AS object_id, name,
		indid AS stats_id,
		sysconv(bit, status & 0x2000) AS auto_created,	-- IS_STATS_AUTO_CRT
		sysconv(bit, case when (status & 0x2001) = 0 then 1 else 0 end) AS user_created,
	  	sysconv(bit, status & 0x4000) AS no_recompute,	-- IS_STATS_NORECOMP
		sysconv(bit, status & 0x20000) AS has_filter,	-- IS_HAS_FILTER
		case when (status & 0x20000) != 0 then object_definition(id, indid, 9) else NULL end AS filter_definition, -- x_euncStats
		convert(bit, 0) as is_temporary,
		sysconv(bit, status & 0x800000) AS is_incremental,
		sysconv(bit, status & 0x10000000) AS has_persisted_sample,
		CASE ISNULL(o.value, 0)
			WHEN 1 THEN 1
			ELSE 0 -- to prevent confusion
		END as stats_generation_method,
		CASE ISNULL(o.value, 0)
			WHEN 1 THEN 'Streaming statistics computed by CREATE or UPDATE statistics and auto statistics'
			WHEN 2 THEN 'Streaming statistics computed during load' -- not yet created
			ELSE 'Sort based statistics'
		END collate Latin1_General_CI_AS_KS_WS AS stats_generation_method_desc -- These _DESC columns should always be the fixed latin collation. Reason is that unlike other columns in system tables that can change depending on the collation setting of the database/instance, these are always fixed on all installations of SQL Server.
	FROM sys.sysidxstats s 
	LEFT JOIN sys.sysobjvalues o ON o.valclass = 143 AND o.valnum = 1 AND id = o.objid AND indid = o.subobjid	-- SVC_STREAMING_STATISTICS
	WHERE (status & 2)  = 2			-- IS_STATS
		AND has_access('CO', id) = 1
		AND indid NOT IN 
        (
            SELECT t.valnum as stats_id
            FROM tempstatvals t
            WHERE t.valnum < 0x40000
                AND t.subobjid = s.id
        )
        AND (s.status & 0x04000000) = 0 -- !IS_IND_RESUMABLE
    UNION ALL
    SELECT	t.subobjid as object_id,
    		v.name COLLATE catalog_default AS name,
    		t.valnum as stats_id,
    		v.auto_created, 
    		v.user_created,
    		v.no_recompute,
    		convert(bit, 0) as has_filter,
    		'' as filter_definition,
    		convert(bit, 1) as is_temporary,
    		convert(bit, 0) as is_incremental,
			v.has_persisted_sample,		
			sysconv(int, 0) AS stats_generation_method,
			'Sorted statistics (default)' collate Latin1_General_CI_AS_KS_WS AS stats_generation_method_desc
    FROM	tempstatvals t   
    		OUTER APPLY 
    		OPENROWSET(TABLE TEMPSTATS, t.objid, t.subobjid, t.valnum, convert(bit, 0)) v 
    WHERE 	has_access('CO', t.subobjid) = 1
go

grant select on sys.stats to [public]
go

