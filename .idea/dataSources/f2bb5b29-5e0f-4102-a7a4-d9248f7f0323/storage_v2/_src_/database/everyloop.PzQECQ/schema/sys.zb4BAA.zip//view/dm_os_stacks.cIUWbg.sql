CREATE VIEW sys.dm_os_stacks AS
	SELECT *
	FROM OpenRowSet(TABLE SYSSTACKS)
go

