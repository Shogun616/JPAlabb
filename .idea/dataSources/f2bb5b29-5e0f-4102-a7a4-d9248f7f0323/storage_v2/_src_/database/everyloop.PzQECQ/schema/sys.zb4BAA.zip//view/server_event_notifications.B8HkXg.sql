CREATE VIEW sys.server_event_notifications AS
	SELECT o.name,
		object_id = o.id,
		parent_class = o.pclass,
		parent_class_desc = pc.name,
		parent_id = o.pid,
		create_date = o.created,
		modify_date = o.modified,
		service_name = convert(nvarchar(256), v.value) COLLATE Latin1_General_BIN,
		broker_instance = convert(sysname, b.value) COLLATE Latin1_General_BIN,
		creator_sid = convert(varbinary(85), cs.value),
		principal_id = r.indepid
	FROM master.sys.sysschobjs$ o
	LEFT JOIN sys.sysobjvalues v ON v.valclass = 72 AND v.objid = o.id AND v.subobjid = 0 AND v.valnum = 0		-- SVC_ASYNTRGSVCNAME
	LEFT JOIN sys.sysobjvalues b ON b.valclass = 74 AND b.objid = o.id AND b.subobjid = 0 AND b.valnum = 0		-- SVC_ASYNTRGBRKRINST
	LEFT JOIN sys.sysobjvalues cs ON cs.valclass = 75 AND cs.objid = o.id AND cs.subobjid = 0 AND cs.valnum = 0	-- SVC_ASYNTRGCTRSID
	LEFT JOIN sys.syssingleobjrefs r ON r.depid = o.id AND r.class = 98 AND r.depsubid = 0	-- SRC_OBJLOGIN
	LEFT JOIN sys.syspalvalues pc ON pc.class = 'UNCL' AND pc.value = o.pclass
	WHERE o.type = 'EN' AND o.nsclass = 30 AND o.pclass = 100	-- x_eonc_EvtNotifOnServer:x_eunc_Server
		AND has_access('TR', o.id, o.pid, o.nsclass) = 1
go

