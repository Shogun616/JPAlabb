CREATE VIEW sys.dm_tran_global_recovery_transactions AS
	SELECT *
	FROM OpenRowset(TABLE GLOBAL_TRANSACTIONS_RECOVERY)
go

