CREATE VIEW sys.syscharsets AS
	SELECT type, id, csid,
		convert(smallint, 0) AS status,
		name, description,
		convert(varbinary(6000), null) AS binarydefinition,
		convert(image, null) AS definition
	FROM OpenRowset(TABLE CHARSET)
go

