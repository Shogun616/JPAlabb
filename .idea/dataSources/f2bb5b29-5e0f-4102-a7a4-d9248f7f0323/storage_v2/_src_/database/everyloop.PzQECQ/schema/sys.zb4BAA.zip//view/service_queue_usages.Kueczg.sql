CREATE VIEW sys.service_queue_usages AS
	SELECT depid AS service_id,
		indepid AS service_queue_id
	FROM sys.syssingleobjrefs
	WHERE class = 21 AND depsubid = 0	-- SRC_SVCTOQUEUE
go

grant select on sys.service_queue_usages to [public]
go

