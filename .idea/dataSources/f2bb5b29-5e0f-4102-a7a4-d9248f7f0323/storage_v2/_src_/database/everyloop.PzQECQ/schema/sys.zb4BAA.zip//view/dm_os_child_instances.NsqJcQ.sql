CREATE VIEW sys.dm_os_child_instances AS
	SELECT * FROM OpenRowset(TABLE CHILDINSTANCES)
go

