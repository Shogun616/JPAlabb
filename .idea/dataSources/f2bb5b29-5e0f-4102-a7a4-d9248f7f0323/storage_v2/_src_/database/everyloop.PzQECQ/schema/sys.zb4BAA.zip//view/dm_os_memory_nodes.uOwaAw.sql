CREATE VIEW sys.dm_os_memory_nodes AS
	SELECT *
	FROM OpenRowSet(TABLE DM_OS_MEMORY_NODES)
go

