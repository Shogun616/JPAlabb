CREATE VIEW sys.computed_columns AS
	SELECT object_id = id,
		name = s.name,
		column_id = colid,
		system_type_id = xtype,
		user_type_id = utype,
		max_length = length,
		precision = prec,
		scale = scale,
		collation_name = convert(sysname,CollationPropertyFromId(collationid,'name')),
		is_nullable = sysconv(bit, 1 - (status & 1)), 		-- CPM_NOTNULL
		is_ansi_padded = sysconv(bit, status & 2), 		-- CPM_NOTRIM
		is_rowguidcol = sysconv(bit, status & 8), 		-- CPM_ROWGUIDCOL
		is_identity = sysconv(bit, status & 4), 		-- CPM_IDENTCOL
		is_filestream = sysconv(bit, status & 32), 		-- CPM_FILESTREAM
		is_replicated = sysconv(bit, status & 0x20000), 	-- CPM_REPLICAT
		is_non_sql_subscribed = sysconv(bit, status & 0x40000),	-- CPM_NONSQSSUB
		is_merge_published = sysconv(bit, status & 0x80000), 	-- CPM_MERGEREPL
		is_dts_replicated = sysconv(bit, status & 0x100000), 	-- CPM_REPLDTS
		is_xml_document = sysconv(bit, status & 2048),		-- CPM_XML_DOC 		
		xml_collection_id = xmlns,
		default_object_id = dflt,
		rule_object_id = chk,
		definition = object_definition(id, colid),
		uses_database_collation = sysconv(bit, status & 128),		-- CPM_USESDBCOLL
		is_persisted = sysconv(bit, status & 64),			-- CPM_PERSISTEDCC	
		is_computed = sysconv(bit, status & 16),			-- CPM_COMPUTED	
		sysconv(bit, 0) as is_sparse,
		sysconv(bit, 0) as is_column_set,
		convert(tinyint, 0) AS generated_always_type,
		convert(nvarchar(60), 'NOT_APPLICABLE') collate Latin1_General_CI_AS_KS_WS AS generated_always_type_desc,
		convert(int, NULL) as encryption_type,
		convert(nvarchar(64), NULL) COLLATE Latin1_General_CI_AS_KS_WS as encryption_type_desc,
		convert(sysname, NULL) COLLATE Latin1_General_CI_AS_KS_WS as encryption_algorithm_name,
		convert(int, NULL) as column_encryption_key_id,
		convert(sysname, NULL) collate catalog_default as column_encryption_key_database_name,
		sysconv(bit, 0) as is_hidden,
		sysconv(bit, 0) AS is_masked,
		convert(int, NULL) AS graph_type,
		convert(nvarchar(60), NULL) collate Latin1_General_CI_AS_KS_WS as graph_type_desc
	FROM sys.syscolpars s
	LEFT JOIN sys.sysobjvalues sov1 ON sov1.valclass = 128 /*SVC_GRAPHDB_COLUMN_TYPE*/ AND sov1.objid = id AND sov1.subobjid = colid AND sov1.valnum = 0 
	LEFT JOIN sys.syspalvalues v1 ON v1.class = 'EGCT' AND v1.value = convert(int, sov1.value)
	WHERE number = 0
		AND (status & 16) = 16			-- CPM_COMPUTED
		AND sov1.value IS NULL
		AND has_access('CO', id) = 1
go

grant select on sys.computed_columns to [public]
go

