CREATE VIEW sys.all_views AS
	SELECT o.name, o.id AS object_id,
		r.indepid AS principal_id, o.nsid AS schema_id,
		o.pid AS parent_object_id,
		o.type, n.name AS type_desc,
		o.created AS create_date, o.modified AS modify_date,
		convert(bit, o.status & 1) AS is_ms_shipped,
		convert(bit, o.status & 16) AS is_published,
		convert(bit, o.status & 64) AS is_schema_published,
		convert(bit, o.status & 0x1000) AS is_replicated,
		convert(bit, o.status & 0x2000) AS has_replication_filter,
		convert(bit, o.status & 512) AS has_opaque_metadata,
		convert(bit, o.status & 2048) AS has_unchecked_assembly_data,
		convert(bit, o.status & 1024) AS with_check_option,
		convert(bit, o.status & 2) AS is_date_correlation_view,
		convert(bit, o.status & 0x01000000) AS is_tracked_by_cdc,
		convert(bit, o.status2 & 0x00001000) AS has_snapshot
	FROM sys.sysschobjs$ o		
	LEFT JOIN sys.syssingleobjrefs r ON r.depid = o.id AND r.class = 97 AND r.depsubid = 0	-- SRC_OBJOWNER
	LEFT JOIN sys.syspalnames n ON n.class = 'OBTY' AND n.value = o.type
	WHERE o.nsclass = 0 -- x_eonc_Standard
		AND o.pclass = 1 AND type = 'V' -- x_eunc_Object
		AND has_access('AO', o.id) = 1
go

grant select on sys.all_views to [public]
go

