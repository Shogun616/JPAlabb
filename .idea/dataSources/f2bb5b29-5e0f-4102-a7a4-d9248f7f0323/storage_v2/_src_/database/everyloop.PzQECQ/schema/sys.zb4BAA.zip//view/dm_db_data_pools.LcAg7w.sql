
-- add it
create view sys.dm_db_data_pools as
select
bdc_pool_id as data_pool_id,
name collate database_default name,
location collate database_default location
from OPENROWSET(TABLE DM_EXEC_BDC_POOLS, 1)
go

