CREATE VIEW sys.dm_db_xtp_gc_cycle_stats
AS
	SELECT
	*
	FROM OpenRowset(TABLE XTP_GC_CYCLE_STATS)
go

