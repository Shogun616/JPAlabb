CREATE VIEW sys.edge_constraints AS
	SELECT o.name, o.object_id, o.principal_id, o.schema_id, o.parent_object_id,
		o.type, o.type_desc, o.create_date, o.modify_date,
		o.is_ms_shipped, o.is_published, o.is_schema_published,
		o.is_disabled, o.is_not_trusted,
		o.is_system_named,
		o.delete_referential_action,
		d.name AS delete_referential_action_desc
	FROM sys.objects$ o
	LEFT JOIN sys.syspalvalues d ON d.class = 'FKRA' AND d.value = o.delete_referential_action
	WHERE o.type = 'EC'
go

grant select on sys.edge_constraints to [public]
go

