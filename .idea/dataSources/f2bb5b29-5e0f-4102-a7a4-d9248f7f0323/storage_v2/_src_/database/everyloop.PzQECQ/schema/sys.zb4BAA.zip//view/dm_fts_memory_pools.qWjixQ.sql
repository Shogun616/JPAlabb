CREATE view sys.dm_fts_memory_pools
AS
	SELECT * FROM OpenRowset(TABLE FTMEMPOOLS)
go

