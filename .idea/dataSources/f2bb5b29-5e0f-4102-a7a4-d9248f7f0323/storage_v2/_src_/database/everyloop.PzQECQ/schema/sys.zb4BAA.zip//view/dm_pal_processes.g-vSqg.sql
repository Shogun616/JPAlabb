CREATE VIEW sys.dm_pal_processes AS
	SELECT *
	FROM OpenRowset(TABLE DM_PAL_PROCESSES)
go

