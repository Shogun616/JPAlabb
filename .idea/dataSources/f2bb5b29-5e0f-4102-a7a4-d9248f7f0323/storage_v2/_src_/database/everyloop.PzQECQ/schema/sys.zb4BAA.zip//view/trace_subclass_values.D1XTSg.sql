create view sys.trace_subclass_values as select * from OpenRowset(TABLE SYSTRACESUBCLASSVALUES)
go

