CREATE VIEW sys.soap_endpoints AS
	SELECT e.name,
		endpoint_id = e.id,
		principal_id = o.indepid,
		e.protocol,
		protocol_desc = p.name,
		e.type,
		type_desc = t.name,
		state = convert(tinyint, bstat & 3),	-- BSTAT_STATEMASK
		state_desc = s.name,
		sysconv(bit, case when e.affinity = -1 then 1 else 0 end) AS is_admin_endpoint, 
		is_sql_language_enabled = sysconv(bit, e.tstat & 8),		-- TSTAT_SOAP_SQL
		wsdl_generator_procedure = e.wsdlproc,
		default_database = e.dfltdb,
		default_namespace = e.dfltns,
		default_result_schema = convert(tinyint, e.tstat & 7),		-- TSTAT_SOAP_RSLTSCHMASK
		default_result_schema_desc = rs.name,
		is_xml_charset_enforced = sysconv(bit, e.tstat & 16),		-- TSTAT_SOAP_XMLCHARSET
		is_session_enabled = sysconv(bit, e.tstat & 32),			-- TSTAT_SOAP_SESSION
		session_timeout = e.typeint,
		login_type = sl.name,
		header_limit = e.maxconn
	FROM master.sys.sysendpts e
	LEFT JOIN sys.syssingleobjrefs o ON o.depid = e.id AND o.class = 60 AND o.depsubid = 0	-- SRC_ENDPTLOGINOWNER
	LEFT JOIN sys.syspalvalues p ON p.class = 'EPPR' AND p.value = e.protocol
	LEFT JOIN sys.syspalvalues t ON t.class = 'EPTY' AND t.value = e.type
	LEFT JOIN sys.syspalvalues s ON s.class = 'EPST' AND s.value = e.bstat & 3
	LEFT JOIN sys.syspalvalues rs ON rs.class = 'SPRS' AND rs.value = e.tstat & 7
	LEFT JOIN sys.syspalvalues sl ON sl.class = 'SPSL' AND sl.value = e.tstat & 64
	WHERE e.type = 1
		AND has_access('HE', e.id) = 1
go

