CREATE VIEW sys.plan_guides AS
	SELECT 
		plan_guide_id 	= g.id,
		name 		= g.name, 
		create_date 	= g.created,
		modify_date 	= g.modified,
		is_disabled 	= sysconv(bit, g.status & 1),
		query_text 	= convert(nvarchar(max), p.stmt),
		scope_type 	= g.scopetype,
		scope_type_desc 	= convert(nvarchar(60), case g.scopetype 
								when  1 then 'OBJECT' 
								when  2 then 'SQL'
								else 'TEMPLATE' end),
		scope_object_id = sysconv(int, case g.scopetype when 1 then g.scopeid end), -- object-id is non-NULL only for module-scoped guide
		scope_batch 	= convert(nvarchar(max), p.batch), -- for single-stmt batch, batch_text is always NULL
		parameters 		= convert(nvarchar(max), p.params),
		hints 			= convert(nvarchar(max), p.hints)
	FROM sys.syssqlguides g CROSS APPLY OpenRowset(TABLE PLANGUIDES, g.id, g.scopeid, g.scopetype) p	
	WHERE g.scopeid <> 0 -- filter-out batch entries
go

grant select on sys.plan_guides to [public]
go

