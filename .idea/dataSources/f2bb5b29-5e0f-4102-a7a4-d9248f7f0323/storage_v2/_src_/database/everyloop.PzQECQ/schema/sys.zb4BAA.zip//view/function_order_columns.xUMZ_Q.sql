CREATE VIEW sys.function_order_columns AS
	SELECT idmajor AS object_id,
		subid AS order_column_id,
		intprop AS column_id,
	  	convert (bit, status & 0x4) AS is_descending	-- ISC_IC_DESC_KEY
	FROM sys.sysiscols
	WHERE (status & 64) <> 0 -- ISC_ORDER_HINT
		AND has_access('CO', idmajor) = 1
go

grant select on sys.function_order_columns to [public]
go

