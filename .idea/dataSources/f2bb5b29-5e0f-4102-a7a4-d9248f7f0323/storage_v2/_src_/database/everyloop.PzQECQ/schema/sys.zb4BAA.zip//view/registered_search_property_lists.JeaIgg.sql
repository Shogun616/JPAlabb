CREATE VIEW sys.registered_search_property_lists AS
	SELECT 
		o.id AS property_list_id,
		o.name AS name,
		o.created AS create_date,
		o.modified AS modify_date,
		p.indepid as principal_id 
	FROM sys.sysclsobjs o 
	LEFT JOIN sys.syssingleobjrefs p ON p.depid = o.id AND p.class = 102 AND p.depsubid = 0	
	where o.class = 66
		AND has_access ('FP', o.id) = 1
go

grant select on sys.registered_search_property_lists to [public]
go

