CREATE VIEW sys.dm_db_fts_index_physical_stats AS
	SELECT
		it.parent_object_id AS object_id,
		SUM( CASE
				WHEN it.internal_type IN
							(211, -- ITT_FTAvdl
							 212, -- ITT_FTCompFragment
							 213, -- ITT_FTDocidStatus
							 214, -- ITT_FTIndexedDocid
							 215, -- ITT_FTDocidFilter
							 216) -- ITT_FTIndDocidMap
				THEN p.used_page_count
				ELSE 0
				END ) AS fulltext_index_page_count,
		SUM( CASE
				WHEN it.internal_type = 222 -- ITT_SEMPLTTagIndex
				THEN p.used_page_count
				ELSE 0
				END ) AS keyphrase_index_page_count,
		SUM( CASE
				WHEN it.internal_type = 221 -- ITT_SEMPLTDocumentIndex
				THEN p.used_page_count
				ELSE 0
				END ) AS similarity_index_page_count
	FROM
			sys.internal_tables it
		JOIN
			sys.dm_db_partition_stats p
		ON
			p.object_id = it.object_id
	WHERE it.internal_type IN
			(211, -- ITT_FTAvdl
			 212, -- ITT_FTCompFragment
			 213, -- ITT_FTDocidStatus
			 214, -- ITT_FTIndexedDocid
			 215, -- ITT_FTDocidFilter
			 216, -- ITT_FTIndDocidMap
			 221, -- ITT_SEMPLTDocumentIndex
			 222) -- ITT_SEMPLTTagIndex
	GROUP BY it.parent_object_id
go

