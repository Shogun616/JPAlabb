
CREATE VIEW sys.dm_cache_size AS

	SELECT
		distribution_id,
		cache_used,
		cache_available,
		cache_capacity
	FROM
	OpenRowset(TABLE DM_PDW_DISTRIBUTION_CACHE_SIZE)
go

