CREATE VIEW sys.security_policies AS
	SELECT name, object_id, principal_id, schema_id, parent_object_id,
		type, type_desc,
		create_date, modify_date,
		is_ms_shipped, is_enabled, is_not_for_replication,
		uses_database_collation,
		is_security_policy_schema_bound as is_schema_bound
	FROM sys.objects$
	WHERE type = 'SP'
go

grant select on sys.security_policies to [public]
go

