CREATE VIEW sys.conversation_groups AS
	SELECT cg.conversation_group_id,
		cg.service_id,
		cg.is_system
	FROM sys.conversation_groups$ cg
	JOIN sys.syssingleobjrefs r ON r.depid = cg.service_id AND r.class = 21 AND r.depsubid = 0 -- SRC_SVCTOQUEUE
	WHERE has_access('CO', r.indepid) = 1
go

grant select on sys.conversation_groups to [public]
go

