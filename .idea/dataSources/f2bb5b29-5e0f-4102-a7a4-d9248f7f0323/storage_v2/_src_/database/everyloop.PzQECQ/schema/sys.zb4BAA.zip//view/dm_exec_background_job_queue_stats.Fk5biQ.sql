CREATE VIEW sys.dm_exec_background_job_queue_stats AS
	SELECT *
	FROM OpenRowSet(TABLE DM_EXEC_BACKGROUND_JOB_QUEUE_STATS)
go

