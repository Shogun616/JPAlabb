 CREATE VIEW sys.database_permissions AS
	SELECT p.class,
		class_desc = n.name,
		major_id = p.id,
		minor_id = p.subid,
		grantee_principal_id = p.grantee,
		grantor_principal_id = p.grantor,
		p.type,
		permission_name = permission_name(p.class, p.type),
		p.state,
		state_desc = s.name
	FROM sys.sysprivs p
	LEFT JOIN sys.syspalvalues n ON n.class = 'UNCL' AND n.value = p.class
	LEFT JOIN sys.syspalnames s ON s.class = 'PRST' AND s.value = p.state
	WHERE (p.state <> 'R' OR p.subid <> 0) AND p.class < 100
		AND (has_access('US', p.grantee, p.grantor) = 1 OR has_access('CT', p.class, p.id) = 1)
 go

 grant select on sys.database_permissions to [public]
 go

