CREATE VIEW sys.dm_pal_wait_stats AS
	SELECT *
	FROM OpenRowset(TABLE DM_PAL_WAIT_STATS)
go

