CREATE VIEW sys.dm_tran_active_transactions AS
	SELECT
		transaction_id,
		name,
		transaction_begin_time,
		transaction_type,
		transaction_uow,
		transaction_state,
		transaction_status,
		transaction_status2,
		dtc_state,
		dtc_status,
		dtc_isolation_level,
		filestream_transaction_id
	FROM OpenRowset(TABLE ACTIVE_TRANSACTIONS)
go

