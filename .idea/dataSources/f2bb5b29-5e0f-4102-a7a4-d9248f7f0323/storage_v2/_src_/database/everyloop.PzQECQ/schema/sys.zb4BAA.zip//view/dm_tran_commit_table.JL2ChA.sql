CREATE VIEW sys.dm_tran_commit_table AS
	SELECT commit_ts, xdes_id, commit_lbn, commit_csn, commit_time
			FROM sys.syscommittab WITH (READCOMMITTEDLOCK)
	UNION
	SELECT commit_ts, xdes_id, commit_lbn, commit_csn, commit_time
			FROM OpenRowset (table SYSCOMMITTABLE, db_id (), 0, 0)
go

