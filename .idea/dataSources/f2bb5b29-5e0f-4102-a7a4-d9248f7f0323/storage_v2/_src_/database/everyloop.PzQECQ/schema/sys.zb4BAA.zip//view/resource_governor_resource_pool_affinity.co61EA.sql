CREATE VIEW sys.resource_governor_resource_pool_affinity
AS
	SELECT pool_id, processor_group, scheduler_mask
	FROM OpenRowSet(TABLE SYS_RG_POOL_AFFINITY)
go

