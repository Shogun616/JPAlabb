CREATE VIEW sys.dm_external_script_requests AS
 	SELECT
		external_script_request_id,
		[language] =
			CAST (CASE script_type
				WHEN 0 THEN 'Test'
				WHEN 1 THEN 'R'
				WHEN 2 THEN 'Python'
				ELSE 'Not Supported'
			END AS nvarchar(128)),
		degree_of_parallelism,
		external_user_name

	FROM OpenRowSet(TABLE DM_EXTSCRIPT_REQUESTS)
go

