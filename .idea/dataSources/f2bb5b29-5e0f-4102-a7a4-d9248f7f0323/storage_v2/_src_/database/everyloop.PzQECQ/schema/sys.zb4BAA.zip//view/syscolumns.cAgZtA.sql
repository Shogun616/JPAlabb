-- Return visible system objects in master database context
CREATE VIEW sys.syscolumns AS
	SELECT c.name, c.id, c.xtype,
		typestat = convert(tinyint, c.status & 3),	-- (1-is_nullable) + is_ansi_padded * 2
		xusertype = convert(smallint, c.utype),
		c.length, xprec = c.prec,
		xscale = c.scale,
		colid = convert(smallint, c.colid),
		xoffset = convert(smallint, 0),
		bitpos = convert(tinyint, 0),
		reserved = convert(tinyint, 0),
		colstat = convert(smallint,
			(c.status & 4)/4				-- CPM_IDENTCOL (is_identity)
			+ (c.status & 8)/4			-- CPM_ROWGUIDCOL (is_rowguidcol * 2)
			+ (case when sov4.value is null then (c.status & 16)/4 else 0 end)			-- CPM_COMPUTED (is_computed * 4)
			+ (c.status & 512)/128		-- CPM_OUTPUT (is_output * 4)
			+ (c.status & 1024)/32		-- CPM_CURSORREF (is_cursor_ref * 32)					
			+ (c.status & 0x20000)/32		-- CPM_REPLICAT (is_replicated * 4096)
			+ (c.status & 0x40000)/32		-- CPM_NONSQSSUB (is_non_sql_subscribed * 8192)
			+ (c.status & 0x80000)/32		-- CPM_MERGEREPL (is_merge_published * 16384)
			+ (c.status & 0x100000)/32),	-- CPM_REPLDTS (is_dts_replicated * 32768)
		cdefault = c.dflt,
		domain = c.chk,
		number = convert(smallint, case c.number when 1 then 1 - objectproperty(c.id, 'isscalarfunction') else c.number end),
		colorder = convert(smallint, c.colid),
		autoval = convert(varbinary(8000), null),
		offset  = convert(smallint, case c.number when 0 then columnproperty(c.id, c.name, 'sql65offset') else 0 end),
		c.collationid,
		language = case c.number when 0 then columnproperty(c.id, c.name, 'fulltextlcid') else 0 end,
		status = convert(tinyint,
			(1-(c.status & 1))*8			-- CPM_NOTNULL (is_nullable * 8)
			+ case when (c.status & 2 <> 0) or (c.xtype in (34, 35) and c.status & 0x20000 <> 0)	-- CPM_NOTRIM,CPM_REPLICAT
			then 16 else 0 end			-- image, text (is_ansi_padded <> 0 or (system_type_id in (34, 35) and is_replicated <> 0))
			+ case when (c.xtype in (34, 35) and c.status & 0x40000 <> 0) or (c.xtype in (173, 175, 189) and c.status & 1 = 0)
			then 32 else 0 end			-- (is_non_sql_subscribed <> 0 and image/text) or is_nullable and timestamp/char/binary
			+ (c.status & 512)/8			-- CPM_OUTPUT (is_output * 64)
			+ (case when sov4.value is null then ((c.status & 16) * 4) else 0 end)			-- CPM_COMPUTED (is_computed*64)
			+ (c.status & 4)*32),			-- CPM_IDENTCOL (is_identity * 128)
		type = xtypetotds(c.xtype, 1 - (c.status & 1)),	-- CPM_NOTNULL (is_nullable)
		usertype = convert(smallint, columnproperty(c.id, c.name, 'oldusertype')),
		printfmt = convert(varchar(255), null),
		prec = convert(smallint,
			case when c.xtype in (34, 35, 99) then null	-- ntext, image, text
			when c.xtype = 36 then c.prec					-- uniqueidentifier
			when c.length = -1 then -1					-- new style large objects
			else odbcprec(c.xtype, c.length, c.prec) end),
		scale = odbcscale(c.xtype, c.scale),
		iscomputed = convert(int, case when sov4.value is null then (c.status & 16)/16 else 0 end),	-- CPM_COMPUTED (is_computed)
		isoutparam = convert(int, (c.status & 512)/512),	-- CPM_OUTPUT (is_output)
		isnullable = convert(int, 1 - (c.status & 1)),	-- CPM_NOTNULL (is_nullable)
		collation = convert(sysname, collationpropertyfromid(collationid, 'name')),
		tdscollation = convert(binary(5), collationpropertyfromid(collationid, 'tdscollation'))
	FROM sys.syscolpars c
	LEFT JOIN sys.sysobjvalues sov4 ON sov4.valclass = 128 /*SVC_GRAPHDB_COLUMN_TYPE*/ and sov4.objid = c.id and sov4.subobjid = c.colid and sov4.valnum = 0
	WHERE has_access('CO', c.id) = 1
	UNION ALL
	SELECT c.name collate catalog_default AS name,
		c.id, c.xtype, c.typestat, c.xusertype, c.length, c.xprec, c.xscale,
		c.colid, c.xoffset, c.bitpos, c.reserved, c.colstat, c.cdefault,
		c.domain, c.number, c.colorder, c.autoval, c.offset, c.collationid,
		c.language, c.status, c.type, c.usertype, c.printfmt, c.prec, c.scale,
		c.iscomputed, c.isoutparam, c.isnullable, c.collation, c.tdscollation
	FROM sys.syscolumns$ c
	WHERE has_access('RO', c.id) = 1
go

grant select on sys.syscolumns to [public]
go

