
CREATE VIEW sys.external_libraries_installed AS
	SELECT
		db_id 				= externalLibrariesInstalled.db_id,
		principal_id		= externalLibrariesInstalled.principal_id,
		language_id			= externalLibrariesInstalled.language_id,
		external_library_id = externalLibrariesInstalled.external_library_id,
		name			= externalLibrariesInstalled.name,
		mdversion		= externalLibrariesInstalled.mdversion
	FROM msdb.dbo.external_libraries_installed externalLibrariesInstalled
	WHERE externalLibrariesInstalled.db_id = db_id() and has_access('EL', external_library_id) = 1
go

grant select on sys.external_libraries_installed to [public]
go

