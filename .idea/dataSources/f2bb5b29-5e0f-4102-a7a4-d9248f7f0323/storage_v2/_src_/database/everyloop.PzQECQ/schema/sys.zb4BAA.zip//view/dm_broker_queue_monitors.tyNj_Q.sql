CREATE VIEW sys.dm_broker_queue_monitors AS
    SELECT * FROM OpenRowset (TABLE SBQUEUEMONITORS)
go

