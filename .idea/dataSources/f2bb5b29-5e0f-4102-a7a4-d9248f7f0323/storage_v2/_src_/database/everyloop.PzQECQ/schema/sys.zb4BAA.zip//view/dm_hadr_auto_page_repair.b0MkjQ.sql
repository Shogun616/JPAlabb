CREATE VIEW sys.dm_hadr_auto_page_repair AS
	SELECT database_id AS database_id,
		file_id AS file_id,
		page_id AS page_id,
		error_type AS error_type,
		page_status AS page_status,
		modification_time AS modification_time
	FROM OpenRowset(TABLE DM_HADR_AUTO_PAGE_REPAIR)
	WHERE database_id < 0x7fff
		AND has_access('DB', database_id) = 1
go

