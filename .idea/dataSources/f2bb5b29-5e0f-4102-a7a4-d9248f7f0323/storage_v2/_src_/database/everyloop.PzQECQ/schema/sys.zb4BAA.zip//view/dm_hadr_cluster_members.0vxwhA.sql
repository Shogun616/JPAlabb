CREATE view sys.dm_hadr_cluster_members
as
	SELECT
	*
	FROM OpenRowset(TABLE DM_HADR_CLUSTER_MEMBERS)
go

