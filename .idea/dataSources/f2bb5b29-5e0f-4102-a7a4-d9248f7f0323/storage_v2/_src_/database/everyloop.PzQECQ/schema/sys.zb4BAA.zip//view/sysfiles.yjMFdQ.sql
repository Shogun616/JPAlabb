CREATE VIEW sys.sysfiles AS
	SELECT
		fileid = convert(smallint, fileid & 0x7fff),
		groupid = convert(smallint, grpid),
		size = isnull(FilePropertyById(fileid, 'size'), size),
		maxsize, growth,
		status = convert(int,
					case filetype when 1 then 66 else 2 end  -- x_eft_SQLLog, FCB_LOG_DEVICE, FCB_DSK_DEVICE
					+ (status & 8) * 2 -- FCB_READONLY_MEDIA
					+ (status & 16) * 256 -- FCB_READONLY
					+ case filestate when 6 then 268435456 else 0 end -- OFFLINE, FCB_OFFLINE
					+ (status & 256) * 2097152 -- FCB_SPARSE_FILE
					+ (status & 32) * 32768 -- FCB_PERCENT_GROWTH
					+ (status & 2048) / 2048), --FCB_PMM_METADATA
		perf = convert(int, 0),
		name = lname,
		filename = trim_path(pname)
	FROM sys.sysprufiles
	WHERE filetype IN (0, 1) -- x_eft_SQLData, x_eft_SQLLog (bwkcmpt types)
		AND filestate NOT IN (1, 2, 3) -- x_efs_Dummy, x_efs_Dropped, x_efs_DroppedReusePending
go

grant select on sys.sysfiles to [public]
go

