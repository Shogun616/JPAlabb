CREATE VIEW sys.server_assembly_modules AS
	SELECT object_id = o.id,
		assembly_id = asm.indepid,
		assembly_class = convert(sysname, v.value) collate Latin1_General_BIN,
		assembly_method = convert(sysname, m.value) collate Latin1_General_BIN,
		execute_as_principal_id = x.indepid
	FROM sys.sysschobjs$ o
	JOIN sys.syssingleobjrefs asm ON asm.depid = o.id AND asm.class = 11 AND asm.depsubid = 0 	-- SRC_MODULETOASM
	LEFT JOIN sys.sysobjvalues v ON v.valclass = 11 AND v.objid = o.id AND v.subobjid = 0 AND v.valnum = 1 	-- SVC_OBJASMENTRY,ASMENTRY_CLASS
	LEFT JOIN sys.sysobjvalues m ON m.valclass = 11 AND m.objid = o.id AND m.subobjid = 0 AND m.valnum = 2 	-- SVC_OBJASMENTRY,ASMENTRY_METHOD
	LEFT JOIN sys.syssingleobjrefs x ON x.depid = o.id AND x.class = 23 AND x.depsubid = 0	-- SRC_OBJEXECASLOGIN
	WHERE o.type = 'TA' AND o.nsclass = 20 AND o.pclass = 100	-- x_eonc_TrgOnServer:x_eunc_Server
		AND has_access('SQ', o.id, 0, 20) = 1
go

