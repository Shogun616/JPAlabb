CREATE VIEW sys.sysdevices AS
	SELECT name, size=convert(int, 0),
		low=convert(int, 0),
		high=convert(int, 0),
		status=convert(smallint, 16),
		cntrltype=convert(smallint, type),
		phyname = physical_name
	FROM sys.backup_devices
go

