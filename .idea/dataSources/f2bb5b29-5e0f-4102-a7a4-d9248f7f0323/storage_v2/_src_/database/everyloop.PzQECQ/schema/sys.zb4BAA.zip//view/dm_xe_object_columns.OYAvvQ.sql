CREATE VIEW sys.dm_xe_object_columns AS
	SELECT *
	FROM OpenRowset(TABLE DM_XE_OBJECT_COLUMNS)
go

