CREATE VIEW sys.column_encryption_key_values AS
	SELECT
		sc.id as column_encryption_key_id, 
		smov1.indepid as column_master_key_id,
		convert(varbinary(8000), smov1.imageval) as encrypted_value,
		convert(sysname, smov1.value) as encryption_algorithm_name
	FROM sys.sysclsobjs sc
	INNER JOIN sys.sysmultiobjvalues smov1 ON smov1.valclass = 1 /*SMVC_CEKDETAILS*/ and smov1.depid = sc.id and smov1.valnum = 0 -- ENCRYPTED_LOB_AND_ALGORITH
	WHERE sc.class = 102 -- SOC_COLENCRYPTIONKEY
	AND has_access('CK', DB_ID()) = 1
go

grant select on sys.column_encryption_key_values to [public]
go

