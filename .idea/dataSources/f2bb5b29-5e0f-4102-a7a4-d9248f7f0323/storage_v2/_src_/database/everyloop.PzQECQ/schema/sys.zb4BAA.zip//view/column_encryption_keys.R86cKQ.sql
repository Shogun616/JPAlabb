CREATE VIEW sys.column_encryption_keys AS
	SELECT sc.name as name, 
		sc.id as column_encryption_key_id,
		sc.created AS create_date,
		sc.modified AS modify_date
	FROM sys.sysclsobjs sc
	WHERE sc.class = 102 -- SOC_COLENCRYPTIONKEY
	AND has_access('CK', DB_ID()) = 1
go

grant select on sys.column_encryption_keys to [public]
go

