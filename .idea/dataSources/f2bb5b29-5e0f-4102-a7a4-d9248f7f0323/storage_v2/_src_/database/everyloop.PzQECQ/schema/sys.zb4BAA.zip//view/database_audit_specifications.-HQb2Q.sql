CREATE VIEW sys.database_audit_specifications AS
	SELECT
		asp.id AS database_specification_id,
		asp.name AS name,
		asp.created AS create_date,
		asp.modified AS modify_date,
		g.guid AS audit_guid,
		sysconv(bit, sysconv (int, asp.status) & 0x1) AS is_state_enabled
	FROM sys.sysclsobjs asp
	LEFT JOIN sys.sysguidrefs g ON g.class = 7 AND g.id = asp.id AND g.subid = 0  -- GRC_DBAUDITSPECGUID
	WHERE asp.class = 65 AND asp.type = 'DA' -- SOC_SECAUDITSPEC
		AND has_access('DA', 0) = 1 -- catalog security check
go

grant select on sys.database_audit_specifications to [public]
go

