CREATE VIEW sys.sysprotects AS
	SELECT id = major_id,
		uid = convert(smallint, grantee_principal_id),
		action = convert(tinyint, case type
			when 'IN' then 195 when 'DL' then 196 when 'EX' then 224
			when 'CRFN' then 178 when 'CRTB' then 198 when 'CRDB' then 203
			when 'CRVW' then 207 when 'CRPR' then 222  when 'BADB' then 228
			when 'CRDF' then 233 when 'BALO' then 235 when 'CRRU' then 236 end),
		protecttype = convert(tinyint, case state
			when 'W' then 204 when 'G' then 205 when 'D' then 206 end),
		columns = convert(varbinary(4000), null),
		grantor = convert(smallint, grantor_principal_id)
	FROM sys.database_permissions
	WHERE class < 2 AND minor_id = 0 AND (type in ('IN','DL','EX') OR charindex(type, 'CRFNCRTBCRDBCRVWCRPRBADBCRDFBALOCRRU')%4 > 0)
	UNION ALL
	SELECT id = c.major_id,
		uid = convert(smallint, c.grantee_principal_id),
		action = convert(tinyint, case c.type
			when 'RF' then 26 when 'SL' then 193 when 'UP' then 197 end),
		protecttype = convert(tinyint, case o.state
			when 'W' then 204 when 'G' then 205 when 'D' then 206 end),
		columns = PowerSum(c.minor_id),
		grantor = convert(smallint, c.grantor_principal_id)
	FROM sys.database_permissions c
	JOIN sys.database_permissions o
		ON o.class = 1 and o.major_id = c.major_id and o.minor_id = 0
			and o.grantee_principal_id = c.grantee_principal_id
			and o.grantor_principal_id = c.grantor_principal_id
			and o.type = c.type and o.state <> 'R'
	WHERE c.class = 1 AND c.type in ('RF','SL','UP')
	GROUP BY c.major_id, c.grantee_principal_id, c.grantor_principal_id, c.type, o.state
	UNION ALL
	SELECT id = major_id,
		uid = convert(smallint, grantee_principal_id),
		action = convert(tinyint, case type
			when 'RF' then 26 when 'SL' then 193 when 'UP' then 197 end),
		protecttype = convert(tinyint, case state
			when 'W' then 204 when 'G' then 205 when 'D' then 206 end),
		columns = PowerSum(minor_id),
		grantor = convert(smallint, grantor_principal_id)
	FROM sys.database_permissions
	WHERE class = 1 AND minor_id <> 0 AND state <> 'R'
	GROUP BY major_id, grantee_principal_id, grantor_principal_id, type, state
go

grant select on sys.sysprotects to [public]
go

