
-- add it
create view sys.dm_exec_external_operations as
select
	B.execution_id	collate database_default execution_id,
	B.step_index,
	B.operation_type	collate database_default operation_type,
	B.operation_name	collate database_default operation_name,
	B.map_progress,
	B.reduce_progress,
	A.compute_pool_id
from (
	select 0
	union all
	select bdc_pool_id as compute_pool_id
	from OPENROWSET(TABLE DM_EXEC_COMPUTE_POOLS, 0)
	) as A(compute_pool_id)
cross apply
	sys.fn_polybase_external_operations_per_pool(A.compute_pool_id) B
go

