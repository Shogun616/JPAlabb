
CREATE VIEW sys.dm_db_tuning_recommendations AS
	(SELECT
		[RecommendationName] AS [name],
		[AdvisorName] AS [type],
		[RecommendationReason] AS [reason],
		[ValidSince] AS [valid_since],
		[LastRefresh] AS [last_refresh],
		[State] AS [state],
		[IsExecutableAction] AS [is_executable_action],
		[IsRevertableAction] AS [is_revertable_action],
		[ExecuteActionStartTime] AS [execute_action_start_time],
		[ExecuteActionDuration] AS [execute_action_duration],
		[ExecuteActionInitiatedBy] AS [execute_action_initiated_by],
		[ExecuteActionInitiatedTime] AS [execute_action_initiated_time],
		[RevertActionStartTime] AS [revert_action_start_time],
		[RevertActionDuration] AS [revert_action_duration],
		[RevertActionInitiatedBy] AS [revert_action_initiated_by],
		[RevertActionInitiatedTime] AS [revert_action_initiated_time],
		[Score] AS [score],
		[Details] AS [details]
	FROM OpenRowset(TABLE DATABASE_TUNING_RECOMMENDATIONS)
	CROSS APPLY
		OPENJSON([json] Collate Database_Default) WITH (
			[RecommendationName] nvarchar(4000), [AdvisorName] nvarchar(4000), [RecommendationReason] nvarchar(4000), [ValidSince] datetime2, [LastRefresh] datetime2,
			[State] nvarchar(4000), [IsExecutableAction] bit, [IsRevertableAction] bit, [ExecuteActionStartTime] datetime2,
			[ExecuteActionDuration] time, [ExecuteActionInitiatedBy] nvarchar(4000), [ExecuteActionInitiatedTime] datetime2, [RevertActionStartTime] datetime2,
			[RevertActionDuration] time, [RevertActionInitiatedBy] nvarchar(4000), [RevertActionInitiatedTime] datetime2, [Score] int, [Details] nvarchar(max)
		))
	UNION ALL
		(SELECT * FROM sys.dm_database_plan_correction_recommendations)
go

