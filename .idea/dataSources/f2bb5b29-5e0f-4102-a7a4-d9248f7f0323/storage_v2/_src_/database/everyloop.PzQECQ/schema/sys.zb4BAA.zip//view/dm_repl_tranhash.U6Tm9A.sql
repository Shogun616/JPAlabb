CREATE view sys.dm_repl_tranhash
as
	SELECT 
		[buckets]
		,[hashed_trans]
		,[completed_trans]
		,[compensated_trans]
		,[first_begin_lsn]
		,[last_commit_lsn]
	FROM OpenRowset(TABLE DM_REPL_TRANHASH)
go

