CREATE VIEW sys.parameter_type_usages AS
	SELECT id AS object_id,
		colid AS parameter_id,
		utype AS user_type_id
	FROM sys.syscolpars
	WHERE number = 1 AND utype > 256
go

grant select on sys.parameter_type_usages to [public]
go

