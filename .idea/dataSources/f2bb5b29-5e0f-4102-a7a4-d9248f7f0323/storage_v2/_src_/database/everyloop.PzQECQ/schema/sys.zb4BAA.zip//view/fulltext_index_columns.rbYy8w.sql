CREATE VIEW sys.fulltext_index_columns AS
	SELECT object_id = objid,
		column_id = subobjid,
		type_column_id = 
			CASE convert(int, convert(varbinary, convert(bigint, value) % 0x100000000)) -- The bottom 4 bytes of value are the type_column_id
				WHEN convert(int, 0xffffffff) THEN NULL -- for back compat return NULL if the column id is bad (0xffffffff)
				ELSE convert(int, convert(varbinary, convert(bigint, value) % 0x100000000))
			END,
		language_id = valnum,
		statistical_semantics = 
			CASE 
				WHEN (convert(bigint, value) & 0x100000000) > 0 THEN 1 -- check for the semantic_statistic bit
				ELSE 0
			END
	FROM sys.sysobjvalues
	WHERE valclass = 42	-- SVC_FULLTEXT_COL	
	AND has_access('CO', objid) = 1
go

grant select on sys.fulltext_index_columns to [public]
go

