CREATE VIEW sys.dm_audit_actions AS
--	SELECT * FROM OpenRowset(TABLE DM_AUDIT_ACTIONS) dm
	SELECT REVERSE(CONVERT(char(4), CONVERT(BINARY(4), [action_id]))) as [action_id], 
		[action_name] as [name], 
		(SELECT spt.name 
			from master.dbo.spt_values spt where spt.type='EOD' AND spt.number = CONVERT(smallint, dm.class_id)) as [class_desc], 
		[covering_action_name],
		(SELECT spt.name 
			from master.dbo.spt_values spt where spt.type='EOD' AND spt.number = CONVERT(smallint, dm.parent_class_id)) as [parent_class_desc], 
		[covering_parent_action_name], 
		[configuration_level],
		[containing_group_name],
		[action_in_log]
	FROM OpenRowset(TABLE DM_AUDIT_ACTIONS) dm
go

