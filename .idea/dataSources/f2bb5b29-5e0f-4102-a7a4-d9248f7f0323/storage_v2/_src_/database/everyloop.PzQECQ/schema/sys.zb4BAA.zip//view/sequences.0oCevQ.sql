CREATE VIEW sys.sequences AS
	SELECT
		-- common fields
		o.name,
		o.object_id,
		o.principal_id,
		o.schema_id,
		o.parent_object_id,
		o.type,
		o.type_desc,
		o.create_date,
		o.modify_date,
		o.is_ms_shipped,
		o.is_published,
		o.is_schema_published,
		-- specific fields
		dmv.start_value,
		dmv.increment,
		dmv.minimum_value,
		dmv.maximum_value,
		is_cycling = o.is_cycling,
		is_cached = o.is_cached,
		cache_size = nullif (o.property, 0),
		dmv.system_type_id,
		user_type_id = isnull(udt.indepid, dmv.system_type_id),
		dmv.precision,
		scale = convert(tinyint, 0), -- The scale always returns 0 as only integer types are allowed.
		dmv.current_value,
		dmv.is_exhausted,
		dmv.last_used_value
	FROM sys.objects$ o
	CROSS APPLY OpenRowset(TABLE DM_DB_SEQUENCES, o.object_id) dmv
	LEFT JOIN sys.syssingleobjrefs udt ON udt.depid = o.object_id AND udt.class = 43 AND udt.depsubid = 0	-- SRC_OBJTOTYPE
	WHERE o.type = 'SO' -- MDOT_SEQUENCE
go

grant select on sys.sequences to [public]
go

