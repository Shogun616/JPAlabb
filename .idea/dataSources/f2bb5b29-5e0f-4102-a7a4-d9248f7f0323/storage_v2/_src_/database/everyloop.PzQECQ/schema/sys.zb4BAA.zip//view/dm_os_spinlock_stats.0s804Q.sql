CREATE VIEW sys.dm_os_spinlock_stats AS
	SELECT *
	FROM OpenRowSet(TABLE DM_OS_SPINLOCKSTATS)
go

