CREATE VIEW sys.dm_pal_vm_stats AS
	SELECT *
	FROM OpenRowset(TABLE DM_PAL_VM_STATS)
go

