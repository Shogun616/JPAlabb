CREATE VIEW sys.dm_clr_loaded_assemblies AS
	SELECT
		assembly_id,
		appdomain_address,
		load_time
	FROM OpenRowset(TABLE DM_CLR_LOADED_ASSEMBLIES)
go

