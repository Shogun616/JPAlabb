CREATE VIEW sys.query_store_query AS
	SELECT 
		query_id,
		query_text_id,
		context_settings_id,
		object_id,
		CAST(batch_sql_handle AS VARBINARY(44)) as batch_sql_handle,
		query_hash,
		is_internal_query,
		query_param_type as query_parameterization_type,
		n.name as query_parameterization_type_desc,
		initial_compile_start_time,
		last_compile_start_time,
		last_execution_time,
		CAST(last_compile_batch_sql_handle AS VARBINARY(44)) as last_compile_batch_sql_handle,
		last_compile_batch_offset_start,
		last_compile_batch_offset_end,
		compile_count as count_compiles,
		CASE WHEN compile_count = 0 THEN NULL ELSE convert(float, total_compile_duration) / compile_count END as avg_compile_duration,
		last_compile_duration,
		CASE WHEN compile_count = 0 THEN NULL ELSE convert(float, total_bind_duration) / compile_count END as avg_bind_duration,
		last_bind_duration,
		CASE WHEN compile_count = 0 THEN NULL ELSE convert(float, total_bind_cpu_time) / compile_count END as avg_bind_cpu_time,
		last_bind_cpu_time,
		CASE WHEN compile_count = 0 THEN NULL ELSE convert(float, total_optimize_duration) / compile_count END as avg_optimize_duration,
		last_optimize_duration,
		CASE WHEN compile_count = 0 THEN NULL ELSE convert(float, total_optimize_cpu_time) / compile_count END as avg_optimize_cpu_time,
		last_optimize_cpu_time,
		CASE WHEN compile_count = 0 THEN NULL ELSE convert(float, total_compile_memory_kb) / compile_count END as avg_compile_memory_kb,
		last_compile_memory_kb,
		max_compile_memory_kb,
		CASE WHEN status IS NULL	THEN NULL ELSE convert(bit, status & 0x01) END as is_clouddb_internal_query
	FROM sys.plan_persist_query_merged
	LEFT JOIN  sys.syspalvalues n ON n.class = 'QDPT' AND n.value = query_param_type
go

grant select on sys.query_store_query to [public]
go

