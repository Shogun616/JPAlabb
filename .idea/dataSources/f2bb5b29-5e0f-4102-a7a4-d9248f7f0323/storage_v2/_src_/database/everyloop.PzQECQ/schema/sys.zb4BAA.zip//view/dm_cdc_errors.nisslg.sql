CREATE view sys.dm_cdc_errors
as
	SELECT 
	    [session_id]
        ,[phase_number]
        ,[entry_time]
        ,[error_number]
        ,[error_severity]
        ,[error_state]
        ,[error_message]
        ,[start_lsn]
        ,[begin_lsn]
        ,[sequence_value]
	FROM OpenRowset(TABLE DM_CDC_ERRORS)
go

