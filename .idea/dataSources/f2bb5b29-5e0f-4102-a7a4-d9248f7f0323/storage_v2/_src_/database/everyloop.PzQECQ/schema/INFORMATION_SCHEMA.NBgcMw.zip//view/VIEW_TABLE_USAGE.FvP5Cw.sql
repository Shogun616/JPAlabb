CREATE VIEW INFORMATION_SCHEMA.VIEW_TABLE_USAGE
AS
SELECT DISTINCT
	DB_NAME()					AS VIEW_CATALOG,
	SCHEMA_NAME(v.schema_id)	AS VIEW_SCHEMA,
	v.name						AS VIEW_NAME,
	DB_NAME()					AS TABLE_CATALOG,
	SCHEMA_NAME(t.schema_id)	AS TABLE_SCHEMA,
	t.name						AS TABLE_NAME
FROM
	 sys.objects t,
	 sys.views v,
	 sys.sql_dependencies d
WHERE
	d.class < 2
	AND d.object_id = v.object_id
	AND d.referenced_major_id = t.object_id
go

