CREATE VIEW sys.syspermissions AS
	SELECT
		id = major_id,
		grantee = convert(smallint, grantee_principal_id),
		grantor = convert(smallint, grantor_principal_id),
		actadd = convert(smallint, null),
		actmod = convert(smallint, null),
		seladd = convert(varbinary(4000), null),
		selmod = convert(varbinary(4000), null),
		updadd = convert(varbinary(4000), null),
		updmod = convert(varbinary(4000), null),
		refadd = convert(varbinary(4000), null),
		refmod = convert(varbinary(4000), null)
	FROM sys.database_permissions
	WHERE class in (0, 1)
	GROUP BY class, major_id, grantee_principal_id, grantor_principal_id
go

grant select on sys.syspermissions to [public]
go

