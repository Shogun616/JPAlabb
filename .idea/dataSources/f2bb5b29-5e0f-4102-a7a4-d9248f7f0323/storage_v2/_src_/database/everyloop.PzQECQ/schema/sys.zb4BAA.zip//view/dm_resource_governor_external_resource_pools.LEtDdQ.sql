CREATE VIEW sys.dm_resource_governor_external_resource_pools AS
 	SELECT
		external_pool_id,
		name,
		pool_version,
		max_cpu_percent,
		max_processes,
		max_memory_percent,
		statistics_start_time,
		peak_memory_kb,
		write_io_count,
		read_io_count,
		total_cpu_kernel_ms,
		total_cpu_user_ms,
		active_processes_count

	FROM OpenRowSet(TABLE DM_RG_EXTPOOLS)
go

