
-- add it
-- adding cast for columns so that the types match with sys._dm_pdw_dms_workers
CREATE VIEW sys.dm_distributed_exchange_stats AS
	SELECT
		CAST(des.request_id as nvarchar(32)) collate database_default request_id,
		des.step_index as step_index,
		des.dms_step_index as dms_step_index,
		des.source_distribution_id as source_distribution_id,
		des.destination_distribution_id as destination_distribution_id,
		CAST(dwt.name as nvarchar(32)) collate database_default [type],
		CAST(dws.name as nvarchar(32)) collate database_default [status],
		des.bytes_per_sec as bytes_per_sec,
		des.bytes_processed as bytes_processed,
		des.rows_processed as rows_processed,
		des.start_time as start_time,
		des.end_time as end_time,
		des.total_elapsed_time as total_elapsed_time,
		des.cpu_time as cpu_time,
		des.query_time as query_time,
		des.buffers_available as buffers_available,
		des.sql_spid as sql_spid,
		des.dms_cpid as dms_cpid,
		CAST(des.error_id as nvarchar(36)) collate database_default error_id,
		CAST(des.source_info as nvarchar(4000)) collate database_default source_info,
		CAST(des.destination_info as nvarchar(4000)) collate database_default destination_info
	FROM OpenRowset(TABLE DM_DISTRIBUTED_EXCHANGE_STATS) des
	LEFT OUTER JOIN sys.syspalvalues dwt ON dwt.class = 'DWT' AND dwt.value = des.type
	LEFT OUTER JOIN sys.syspalvalues dws ON dws.class = 'DWS' AND dws.value = des.status
go

grant select on sys.dm_distributed_exchange_stats to [public]
go

