CREATE VIEW sys.server_file_audits AS
	SELECT
		au.audit_id,
		au.name,
		au.audit_guid,
		au.create_date,
		au.modify_date,
		au.principal_id,
		au.type,
		au.type_desc,	
		au.on_failure,
		au.on_failure_desc,
		au.is_state_enabled,
		au.queue_delay,
		au.predicate,
		convert(bigint, ms.value) AS max_file_size,
		convert(int, mr.value) AS max_rollover_files,
		convert(int, mf.value) AS max_files,
		sysconv(bit, au.status & 0x10000) AS reserve_disk_space,
		convert(nvarchar(260), pt.value) AS log_file_path,
		convert(nvarchar(260), nm.value) AS log_file_name,
		convert(int, rd.value) AS retention_days
	FROM sys.server_audits$ au
	LEFT JOIN master.sys.sysobjvalues ms ON ms.valclass = 38 AND ms.objid = au.audit_id AND ms.subobjid = 0 AND ms.valnum = 50 -- SVC_AUDITPROPS/AUDIT_FL_MAX_SIZE
	LEFT JOIN master.sys.sysobjvalues mr ON mr.valclass = 38 AND mr.objid = au.audit_id AND mr.subobjid = 0 AND mr.valnum = 51 -- SVC_AUDITPROPS/AUDIT_FL_MAX_ROLLOVER
	LEFT JOIN master.sys.sysobjvalues nm ON nm.valclass = 38 AND nm.objid = au.audit_id AND nm.subobjid = 0 AND nm.valnum = 53 -- SVC_AUDITPROPS/AUDIT_FL_NAME
	LEFT JOIN master.sys.sysobjvalues pt ON pt.valclass = 38 AND pt.objid = au.audit_id AND pt.subobjid = 0 AND pt.valnum = 54 -- SVC_AUDITPROPS/AUDIT_FL_PATH
	LEFT JOIN master.sys.sysobjvalues mf ON mf.valclass = 38 AND mf.objid = au.audit_id AND mf.subobjid = 0 AND mf.valnum = 55 -- SVC_AUDITPROPS/AUDIT_FL_MAX_FILES
	LEFT JOIN master.sys.sysobjvalues rd ON rd.valclass = 38 AND rd.objid = au.audit_id AND rd.subobjid = 0 AND rd.valnum = 56 -- SVC_AUDITPROPS/AUDIT_FL_RETENTION_DAYS
	WHERE au.type = 'FL' OR au.type = 'UL'
go

