
CREATE VIEW sys.column_store_row_groups AS

	SELECT rg.parent_object_id as [object_id],
		rg.parent_index_id as [index_id],
		rg.parent_part_number as [partition_number],
		rg.[row_group_id],
		rg.[delta_store_hobt_id],
		rg.[state],
		sd.[name] as state_description,
		rg.[total_rows],
		rg.[deleted_rows],
		rg.[size_in_bytes]
	FROM
	(sys.syspalvalues sd
	INNER hash JOIN
	-- First parameter determines which table to open
	-- Second parameter determines the object id passed in
	-- Third parameter determines which view to show,
	-- 1 is to show dm_db_column_store_row_group_physical_stats
	-- 0 is to show fn_column_store_row_groups or column_store_row_groups
	OpenRowset(TABLE COLUMNSTORE_ROW_GROUPS, 0, 0) rg
		ON sd.class = 'CSRG' AND sd.value = rg.state)
	WHERE has_access('CO', rg.parent_object_id) = 1;
go

grant select on sys.column_store_row_groups to [public]
go

