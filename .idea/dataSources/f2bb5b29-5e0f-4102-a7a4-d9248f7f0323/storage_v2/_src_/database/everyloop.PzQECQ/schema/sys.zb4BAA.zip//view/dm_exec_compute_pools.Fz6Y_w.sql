
-- add it
create view sys.dm_exec_compute_pools as
select
bdc_pool_id as compute_pool_id,
name collate database_default name,
location collate database_default location
from OPENROWSET(TABLE DM_EXEC_COMPUTE_POOLS, 0)
go

