CREATE VIEW sys.dm_tran_locks AS
	SELECT	resource_type,
			resource_subtype,
			resource_database_id,
			resource_description,
			resource_associated_entity_id,
			resource_lock_partition,
			request_mode,
			request_type,
			request_status,
			request_reference_count,
			request_lifetime,
			request_session_id,
			request_exec_context_id,
			request_request_id,
			request_owner_type,
			request_owner_id,
			request_owner_guid,
			request_owner_lockspace_id,
			lock_owner_address
	FROM OpenRowSet(TABLE SYSLOCKINFORMATION)
go

