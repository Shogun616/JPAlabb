CREATE VIEW sys.resource_governor_resource_pools
AS
    -- ISSUE - VSTS 83011
    -- Use isnull() below because Algebrizer doesn't properly
    -- determine these columns are non-nullable.
    SELECT
        pool_id             = co.id,
        name                = co.name,
        min_cpu_percent     = isnull( co.status            % 0x100, 0),
        max_cpu_percent     = isnull((co.status/0x100)     % 0x100, 0),
        min_memory_percent  = isnull((co.status/0x10000)   % 0x100, 0),
        max_memory_percent  = isnull((co.status/0x1000000) % 0x100, 0),
        cap_cpu_percent     = isnull( co.intprop % 0x100, 0),
        min_iops_per_volume = isnull(convert(int, convert(bigint, ov.value) % 0x100000000), 0),
        max_iops_per_volume = isnull(convert(int, convert(bigint, ov.value) / 0x100000000), 0)
    FROM
        master.sys.sysclsobjs co LEFT JOIN
        master.sys.sysobjvalues ov ON
        (
            co.id = ov.objid AND
            ov.valclass = 101 AND -- SVC_RG_POOL
            ov.subobjid = 0 AND
            ov.valnum = 1
        )
    WHERE 
        co.class = 54 AND -- SOC_RG_POOL
        has_access('RG', 0) = 1
go

