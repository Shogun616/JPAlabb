
-- add it
create view sys.dm_exec_compute_nodes as
select
	B.compute_node_id,
	B.type collate database_default type,
	B.name collate database_default name,
	B.address collate database_default address,
	A.compute_pool_id
from (
	select 0
	union all
	select bdc_pool_id as compute_pool_id
	from OPENROWSET(TABLE DM_EXEC_COMPUTE_POOLS, 0)
	) as A(compute_pool_id)
cross apply
	sys.fn_polybase_compute_nodes_per_pool(A.compute_pool_id) B
go

