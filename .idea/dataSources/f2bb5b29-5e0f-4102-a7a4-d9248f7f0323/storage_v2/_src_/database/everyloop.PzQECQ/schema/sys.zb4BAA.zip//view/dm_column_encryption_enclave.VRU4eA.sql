CREATE VIEW sys.dm_column_encryption_enclave AS
	SELECT *
	FROM OpenRowset(TABLE DM_COLUMN_ENCRYPTION_ENCLAVE)
go

