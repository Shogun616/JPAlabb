CREATE VIEW sys.dm_os_host_info AS
	SELECT *
	FROM OpenRowset(TABLE DM_OS_HOST_INFO)
go

