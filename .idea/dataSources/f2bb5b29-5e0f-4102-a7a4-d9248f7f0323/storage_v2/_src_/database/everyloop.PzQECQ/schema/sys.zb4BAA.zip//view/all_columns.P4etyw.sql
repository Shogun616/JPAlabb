CREATE VIEW sys.all_columns AS
 SELECT * FROM sys.columns
 UNION ALL
 SELECT * FROM sys.system_columns
go

grant select on sys.all_columns to [public]
go

