CREATE VIEW sys.endpoint_webmethods AS
	SELECT
		endpoint_id = m.id,
		namespace = m.nmspace,
		method_alias = m.alias,
		object_name = m.objname,
		result_schema = convert(tinyint, m.status & 7),			-- METHSTAT_SCHEMAMASK
		result_schema_desc = s.name,
		result_format = convert(tinyint, (m.status/8) & 7),		-- METHSTAT_FMTMASK
		result_format_desc = f.name
	FROM master.sys.syswebmethods m
	LEFT JOIN sys.syspalvalues s ON s.class = 'SPRS' AND s.value = m.status & 7
	LEFT JOIN sys.syspalvalues f ON f.class = 'SPRF' AND f.value = (m.status/8)&7
	WHERE has_access('HE', m.id) = 1
go

