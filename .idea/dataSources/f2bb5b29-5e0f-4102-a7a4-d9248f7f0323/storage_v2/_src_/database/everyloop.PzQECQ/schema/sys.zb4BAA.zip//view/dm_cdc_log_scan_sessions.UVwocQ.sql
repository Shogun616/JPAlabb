CREATE view sys.dm_cdc_log_scan_sessions
as
	SELECT 
	    [session_id]
        ,[start_time]
        ,[end_time]
        ,[duration]
        ,[scan_phase]
        ,[error_count]
        ,[start_lsn]
        ,[current_lsn]
        ,[end_lsn]
        ,[tran_count]
        ,[last_commit_lsn]
        ,[last_commit_time]
        ,[log_record_count]
        ,[schema_change_count]
        ,[command_count]
        ,[first_begin_cdc_lsn]
        ,[last_commit_cdc_lsn]
        ,[last_commit_cdc_time]
        ,[latency]
        ,[empty_scan_count]
        ,[failed_sessions_count]
	FROM OpenRowset(TABLE DM_CDC_LOGSCAN_SESSIONS)
go

