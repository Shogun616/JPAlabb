CREATE VIEW sys.sysindexkeys AS
	SELECT
		id = object_id,
		indid = convert(smallint, index_id),
		colid = convert(smallint, column_id),
		keyno = convert(smallint, key_ordinal)
	FROM sys.index_columns
	WHERE index_id < 256000
go

grant select on sys.sysindexkeys to [public]
go

