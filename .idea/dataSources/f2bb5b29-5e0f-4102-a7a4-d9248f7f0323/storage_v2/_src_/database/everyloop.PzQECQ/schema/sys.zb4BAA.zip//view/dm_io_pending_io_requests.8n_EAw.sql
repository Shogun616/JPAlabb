CREATE VIEW sys.dm_io_pending_io_requests AS
	SELECT
		io_completion_request_address,
		io_type,
		io_pending_ms_ticks,
		io_pending,
		io_completion_routine_address,
		io_user_data_address,
		scheduler_address,
		io_handle,
		io_offset,
		trim_path(io_handle_path) as io_handle_path
	FROM OpenRowSet(TABLE SYSIOS)
go

