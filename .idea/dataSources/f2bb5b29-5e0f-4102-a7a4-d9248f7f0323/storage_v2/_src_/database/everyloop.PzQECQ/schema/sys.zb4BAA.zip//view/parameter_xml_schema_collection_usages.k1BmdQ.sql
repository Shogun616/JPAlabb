CREATE VIEW sys.parameter_xml_schema_collection_usages AS
	SELECT id AS object_id,
		colid AS parameter_id,
		xmlns AS xml_collection_id
	FROM sys.syscolpars
	WHERE number = 1 AND xmlns > 0
go

grant select on sys.parameter_xml_schema_collection_usages to [public]
go

