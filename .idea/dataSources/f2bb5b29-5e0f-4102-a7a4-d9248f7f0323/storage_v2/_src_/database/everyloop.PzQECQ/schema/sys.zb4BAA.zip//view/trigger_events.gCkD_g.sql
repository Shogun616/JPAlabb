CREATE VIEW sys.trigger_events AS
	SELECT ee.object_id AS object_id,
		ee.event_id AS type,
		ee.event_desc AS type_desc,
		sysconv(bit, convert(int, e.value) & 1) AS is_first,	-- TRG_FIRSTFIRED
		sysconv(bit, convert(int, e.value) & 2) AS is_last,	-- TRG_LASTFIRED
		ee.group_id AS event_group_type,
		ee.group_desc AS event_group_type_desc,
		convert(bit, 1) AS is_trigger_event
	FROM sys.sysobjvalues e
	CROSS APPLY openrowset( TABLE EXPAND_EVENTS, e.objid, e.subobjid, 
		case when (e.valclass = 70 AND convert(int, e.value) & 4 != 4)	-- is user created trigger?
			then 1 else 0 end) ee
	WHERE e.valclass = 70 AND e.valnum <> 100	-- x_eunc_Server
		AND has_access('CO', e.objid) = 1	-- SVC_EXTTRIGEVT
go

grant select on sys.trigger_events to [public]
go

