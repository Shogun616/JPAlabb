CREATE VIEW sys.dm_server_memory_dumps AS
	SELECT *
	FROM OpenRowset(TABLE DM_SERVER_MEMORY_DUMPS)
go

