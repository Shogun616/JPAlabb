CREATE VIEW sys.availability_group_listener_ip_addresses AS
	SELECT
		listener_id = CAST(agl.listener_id AS nvarchar(36)),
		ip_address = CAST(agl.ip_address as nvarchar(48)),
		ip_subnet_mask = CAST(agl.ip_subnet_mask as nvarchar(15)),
		is_dhcp = agl.is_dhcp,
		network_subnet_ip = CAST(agl.network_subnet_ip as nvarchar(48)),
		network_subnet_prefix_length = CAST(agl.network_subnet_prefix_length as int),
		network_subnet_ipv4_mask = CAST(agl.network_subnet_ipv4_mask as nvarchar(48)),
		state = CAST(agl.state AS tinyint),
		state_desc = CAST(agl.state_desc AS nvarchar(60))
	FROM
		sys.dm_hadr_internal_ag_listener_addresses AS agl
go

