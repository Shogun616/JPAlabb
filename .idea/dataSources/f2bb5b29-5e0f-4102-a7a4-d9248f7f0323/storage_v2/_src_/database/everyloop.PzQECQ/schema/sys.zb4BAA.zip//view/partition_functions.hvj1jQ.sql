CREATE VIEW sys.partition_functions AS
	SELECT f.name,
		f.id AS function_id,
		f.type,
		n.name AS type_desc,
		f.intprop AS fanout,
		sysconv(bit, f.status & 1) AS boundary_value_on_right,
		sysconv(bit, f.status & 2) AS is_system,
		f.created AS create_date,
		f.modified AS modify_date
	FROM sys.sysclsobjs f
	LEFT JOIN sys.syspalnames n ON n.class = 'PFTY' AND n.value = f.type
	WHERE f.class = 30
go

grant select on sys.partition_functions to [public]
go

