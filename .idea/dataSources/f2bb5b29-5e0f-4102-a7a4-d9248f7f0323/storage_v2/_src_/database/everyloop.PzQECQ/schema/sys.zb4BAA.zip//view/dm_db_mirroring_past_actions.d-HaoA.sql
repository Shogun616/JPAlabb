CREATE VIEW sys.dm_db_mirroring_past_actions AS
	SELECT *
	FROM OpenRowSet(TABLE DBMIRROR_PAST_ACTIONS)
go

