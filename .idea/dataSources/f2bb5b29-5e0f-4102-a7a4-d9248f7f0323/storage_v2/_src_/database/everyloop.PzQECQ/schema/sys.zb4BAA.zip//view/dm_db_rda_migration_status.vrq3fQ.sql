
CREATE VIEW sys.dm_db_rda_migration_status
AS
SELECT * FROM OpenRowset(TABLE DM_DB_RDA_MIGRATION_STATUS)
go

