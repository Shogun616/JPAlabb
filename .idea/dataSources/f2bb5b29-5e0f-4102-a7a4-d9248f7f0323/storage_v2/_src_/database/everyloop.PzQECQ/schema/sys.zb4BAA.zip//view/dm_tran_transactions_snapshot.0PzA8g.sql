CREATE VIEW sys.dm_tran_transactions_snapshot AS
	SELECT *
	FROM OpenRowset(TABLE DM_TRAN_TRANSACTIONS_SNAPSHOT)
go

