CREATE VIEW sys.dm_tran_current_transaction AS
	SELECT *
	FROM OpenRowset(TABLE DM_TRAN_CURRENT_TRANSACTION)
go

