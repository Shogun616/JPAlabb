CREATE VIEW sys.dm_os_waiting_tasks AS
	SELECT *
	FROM OpenRowSet(TABLE SYSWAITS)
go

