CREATE VIEW sys.dm_logpool_stats AS
	SELECT *
	FROM OpenRowSet(TABLE DM_LOGPOOL_STATS)
go

