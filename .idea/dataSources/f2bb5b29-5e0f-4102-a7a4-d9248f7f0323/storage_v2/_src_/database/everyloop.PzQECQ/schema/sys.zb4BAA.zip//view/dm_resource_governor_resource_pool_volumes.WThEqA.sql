CREATE VIEW sys.dm_resource_governor_resource_pool_volumes AS
	SELECT *
	FROM OpenRowSet(TABLE DM_RG_POOL_VOLUMES)
go

