CREATE VIEW sys.http_endpoints AS
	SELECT e.name, e.id AS endpoint_id,
		o.indepid AS principal_id,
		e.protocol, p.name AS protocol_desc,
		e.type, t.name AS type_desc,
		convert(tinyint, e.bstat & 3) AS state,	-- BSTAT_STATEMASK
		s.name AS state_desc,
		sysconv(bit, case when e.affinity = -1 then 1 else 0 end) AS is_admin_endpoint, 
		e.site,
		convert(nvarchar(4000), v.value) collate Latin1_General_CI_AS_KS_WS AS url_path,
		sysconv(bit, e.pstat & 1) AS is_clear_port_enabled,		-- PSTAT_HTTP_CLEARPORT
		e.port1 AS clear_port,
		sysconv(bit, e.pstat & 2) AS is_ssl_port_enabled,		-- PSTAT_HTTP_SSLPORT
		e.port2 AS ssl_port,
		sysconv(bit, 0) AS is_anonymous_enabled,				-- is_anonymous_enabled is always zero.
		sysconv(bit, e.pstat & 8) AS is_basic_auth_enabled,		-- PSTAT_HTTP_BASICAUTH
		sysconv(bit, e.pstat & 16) AS is_digest_auth_enabled,		-- PSTAT_HTTP_DIGESTAUTH
		sysconv(bit, (e.pstat & (32|64))) AS is_kerberos_auth_enabled,	-- PSTAT_HTTP_INTEGAUTH | PSTAT_HTTP_KERBEROS
		sysconv(bit, (e.pstat & (32|256))) AS is_ntlm_auth_enabled,	-- PSTAT_HTTP_INTEGAUTH |PSTAT_HTTP_NTLM
		sysconv(bit, case when (e.pstat & 32) <> 0 or (e.pstat & 320)=320 then 1 else 0 end) AS is_integrated_auth_enabled,	-- PSTAT_HTTP_INTEGAUTH | (PSTAT_HTTP_KERBEROS & PSTAT_HTTP_NTLM)
		e.authrealm AS authorization_realm,
		e.dfltdm AS default_logon_domain,
		sysconv(bit, e.pstat & 128) AS is_compression_enabled 		-- PSTAT_HTTP_COMPRESS
	FROM master.sys.sysendpts e
	LEFT JOIN sys.syssingleobjrefs o ON o.depid = e.id AND o.class = 60 AND o.depsubid = 0	-- SRC_ENDPTLOGINOWNER
	LEFT JOIN sys.sysobjvalues v ON v.valclass = 46 AND v.objid = e.id AND v.subobjid = 0 AND v.valnum = 1	-- SVC_EP_PROPS
	LEFT JOIN sys.syspalvalues p ON p.class = 'EPPR' AND p.value = e.protocol
	LEFT JOIN sys.syspalvalues t ON t.class = 'EPTY' AND t.value = e.type
	LEFT JOIN sys.syspalvalues s ON s.class = 'EPST' AND s.value = e.bstat & 3
	WHERE e.protocol = 1
		AND has_access('HE', e.id) = 1
go

