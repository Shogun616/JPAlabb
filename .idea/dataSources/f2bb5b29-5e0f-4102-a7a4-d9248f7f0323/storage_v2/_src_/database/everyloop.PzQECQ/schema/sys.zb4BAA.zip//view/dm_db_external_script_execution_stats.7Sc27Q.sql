CREATE VIEW sys.dm_db_external_script_execution_stats AS
 	SELECT
		external_language_id,
		counter_name,
		counter_value
	FROM OpenRowSet(TABLE DM_DB_EXTERNAL_SCRIPT_EXECUTION_STATS)
go

