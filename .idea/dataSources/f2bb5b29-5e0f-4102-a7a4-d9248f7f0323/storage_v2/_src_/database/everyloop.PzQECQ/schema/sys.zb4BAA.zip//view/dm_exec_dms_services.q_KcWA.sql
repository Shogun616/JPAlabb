
-- add it
create view sys.dm_exec_dms_services as
select
	B.dms_core_id,
	B.compute_node_id,
	B.status	collate database_default status,
	A.compute_pool_id
from (
	select 0
	union all
	select bdc_pool_id as compute_pool_id
	from OPENROWSET(TABLE DM_EXEC_COMPUTE_POOLS, 0)
	) as A(compute_pool_id)
cross apply
	sys.fn_polybase_dms_services_per_pool(A.compute_pool_id) B
go

