CREATE VIEW sys.server_event_session_targets AS
	SELECT 
		event_session_id = v.objid,
		target_id		 = v.subobjid,
		name			 = convert(sysname, v.value) collate catalog_default,
		package			 = convert(sysname, p.name) collate catalog_default,
		module			 = convert(sysname, m.name) collate catalog_default
	FROM master.sys.sysobjvalues v
	LEFT JOIN master.sys.sysqnames p ON p.nid = v.valnum
	LEFT JOIN master.sys.sysqnames m ON m.nid = p.qid
	WHERE v.valclass = 57			-- SVC_XE_SESSION_TARGET
	AND has_access ('ES', 0) = 1
go

