CREATE VIEW sys.availability_group_listeners AS
	SELECT
		group_id = agl.group_id,
		listener_id = CAST(agl.listener_id AS nvarchar(36)),
		dns_name = CAST(agl.dns_name AS nvarchar(63)),
		port = CAST(agl.port AS int),
		is_conformant = agl.is_conformant,
		ip_configuration_string_from_cluster = agl.ip_configuration_string_from_cluster
	FROM
		sys.dm_hadr_internal_ag_listeners AS agl
go

