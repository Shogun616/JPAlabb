
create view sys.dm_exec_cached_plans as 
	SELECT
		bucketid,
		refcounts,
		usecounts,
		size_in_bytes,
		memory_object_address,
		cacheobjtype,
		objtype,
		plan_handle,
		pool_id,
		parent_plan_handle
	FROM OpenRowset(TABLE SYSDMEXECCACHEDPLANS)
	UNION ALL
	SELECT 
		bucketid,
		refcounts,
		usecounts,
		size_in_bytes,
		memory_object_address,
		cacheobjtype,
		objtype,
		plan_handle,
		pool_id,
		NULL
	FROM OpenRowset(TABLE XTP_CACHED_PLANS)

go

