CREATE VIEW sys.dm_filestream_file_io_requests AS
    SELECT *
    FROM OpenRowset(TABLE DM_FILESTREAM_FILE_IO_REQUESTS)
go

