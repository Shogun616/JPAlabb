CREATE VIEW sys.fulltext_stoplists AS
	SELECT 
		o.id AS stoplist_id,
		o.name AS name,
		o.created AS create_date,
		o.modified AS modify_date,
		p.indepid as principal_id 
	FROM sys.sysclsobjs o 
	LEFT JOIN sys.syssingleobjrefs p ON p.depid = o.id AND p.class = 101 AND p.depsubid = 0	--SRC_FTSTPLIST_OWNER
	where o.class = 33
		AND has_access ('FS', o.id) = 1
go

grant select on sys.fulltext_stoplists to [public]
go

