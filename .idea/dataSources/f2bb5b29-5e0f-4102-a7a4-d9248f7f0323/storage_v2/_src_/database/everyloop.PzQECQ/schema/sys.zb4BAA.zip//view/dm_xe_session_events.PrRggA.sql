CREATE VIEW sys.dm_xe_session_events AS
	SELECT *
	FROM OpenRowset(TABLE DM_XE_SESSION_EVENTS,0)
go

