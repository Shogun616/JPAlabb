CREATE VIEW sys.column_type_usages AS
	SELECT id AS object_id,
		colid AS column_id,
		utype AS user_type_id
	FROM sys.syscolpars
	WHERE number = 0 AND utype > 256
go

grant select on sys.column_type_usages to [public]
go

