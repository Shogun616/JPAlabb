CREATE VIEW sys.foreign_keys AS
	SELECT o.name, o.object_id, o.principal_id, o.schema_id, o.parent_object_id,
		o.type, o.type_desc, o.create_date, o.modify_date,
		o.is_ms_shipped, o.is_published, o.is_schema_published,
		f.indepid AS referenced_object_id,
		f.indepsubid AS key_index_id,
		o.is_disabled, o.is_not_for_replication, o.is_not_trusted,
		o.delete_referential_action,	-- ERefAct
		d.name AS delete_referential_action_desc,
		o.update_referential_action,	-- ERefAct
		u.name AS update_referential_action_desc,
		o.is_system_named
	FROM sys.objects$ o
	LEFT JOIN sys.syssingleobjrefs f ON f.depid = o.object_id AND f.class = 27 AND f.depsubid = 0	-- SRC_FK_REFD_INDEX
	LEFT JOIN sys.syspalvalues d ON d.class = 'FKRA' AND d.value = o.delete_referential_action
	LEFT JOIN sys.syspalvalues u ON u.class = 'FKRA' AND u.value = o.update_referential_action
	WHERE o.type = 'F '
go

grant select on sys.foreign_keys to [public]
go

