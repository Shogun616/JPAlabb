CREATE VIEW sys.dm_io_backup_tapes AS
	SELECT *
	FROM OpenRowset(TABLE TAPE_STATUS)
go

