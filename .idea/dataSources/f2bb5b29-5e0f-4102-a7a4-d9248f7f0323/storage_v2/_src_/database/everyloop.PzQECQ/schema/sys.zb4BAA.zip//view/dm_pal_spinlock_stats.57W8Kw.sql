CREATE VIEW sys.dm_pal_spinlock_stats AS
	SELECT *
	FROM OpenRowset(TABLE DM_PAL_SPINLOCK_STATS)
go

