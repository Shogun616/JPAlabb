CREATE VIEW sys.dm_clr_tasks AS
	SELECT
		task_address,
		sos_task_address,
		appdomain_address,
		state,
		abort_state,
		type,
		affinity_count,
		forced_yield_count
	FROM OpenRowset(TABLE DM_CLR_TASKS)
go

