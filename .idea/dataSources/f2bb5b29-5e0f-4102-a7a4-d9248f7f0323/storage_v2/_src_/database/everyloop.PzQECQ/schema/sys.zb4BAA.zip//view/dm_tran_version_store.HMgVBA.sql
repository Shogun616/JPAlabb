CREATE VIEW sys.dm_tran_version_store AS
	SELECT *
	FROM OpenRowset(TABLE DM_TRAN_VERSION_STORE)
go

