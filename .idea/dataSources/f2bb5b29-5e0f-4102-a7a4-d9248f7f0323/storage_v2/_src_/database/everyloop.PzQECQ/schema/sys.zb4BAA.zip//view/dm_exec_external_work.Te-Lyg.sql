
-- add it
create view sys.dm_exec_external_work as
select
	B.execution_id	collate database_default execution_id,
	B.step_index,
	B.dms_step_index,
	B.work_id,
	B.compute_node_id,
	B.type	collate database_default type,
	B.input_name	 collate database_default input_name,
	B.read_location,
	B.read_command,
	B.bytes_processed,
	B.length,
	B.start_time,
	B.end_time,
	B.total_elapsed_time,
	B.status	collate database_default status,
	A.compute_pool_id
from (
	select 0
	union all
	select bdc_pool_id as compute_pool_id
	from OPENROWSET(TABLE DM_EXEC_COMPUTE_POOLS, 0)
	) as A(compute_pool_id)
cross apply
	sys.fn_polybase_external_work_per_pool(A.compute_pool_id) B
go

