CREATE VIEW sys.service_contract_usages AS
	SELECT service_id = depid,
		service_contract_id = indepid
	FROM sys.sysmultiobjrefs
	WHERE class = 19 AND depsubid = 0 AND indepsubid = 0	--MRC_SVC_CONTRACT_USAGE
go

grant select on sys.service_contract_usages to [public]
go

