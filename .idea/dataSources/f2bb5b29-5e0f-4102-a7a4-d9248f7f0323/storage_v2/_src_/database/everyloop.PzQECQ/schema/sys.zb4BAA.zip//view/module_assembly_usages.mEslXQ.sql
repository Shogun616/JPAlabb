CREATE VIEW sys.module_assembly_usages AS
	SELECT depid AS object_id,
		indepid AS assembly_id
	FROM sys.syssingleobjrefs
	WHERE class = 11 AND depsubid = 0 	-- SRC_MODULETOASM
go

grant select on sys.module_assembly_usages to [public]
go

