CREATE VIEW sys.procedures AS
	SELECT name, object_id, principal_id, schema_id, parent_object_id,
		type, type_desc, create_date, modify_date,
		is_ms_shipped, is_published, is_schema_published,
		is_auto_executed, is_execution_replicated,
		is_repl_serializable_only, skips_repl_constraints
	FROM sys.objects$
	WHERE type IN ('P ', 'X ', 'PC', 'RF')
go

grant select on sys.procedures to [public]
go

